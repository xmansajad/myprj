<?php
// set_webhook.php
// تنظیم webhook برای یک یا همه زیر ربات‌ها
// دسترسی: فقط از طریق CLI یا با secret key

require_once 'config.php';
require_once 'child_botapi.php';

// محافظت ساده
$secret = $_GET['secret'] ?? '';
$master_secret = $adminnumber; // آیدی ادمین اصلی به عنوان secret

if (php_sapi_name() !== 'cli' && $secret !== $master_secret) {
    http_response_code(403);
    die('Unauthorized. Use: ?secret=ADMIN_ID');
}

$bot_token = $_GET['token'] ?? null;

if ($bot_token) {
    // تنظیم یک زیر ربات خاص
    $result = child_set_webhook($bot_token, $domainhosts);
    $ok = $result['ok'] ?? false;
    if ($ok) {
        $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE bot_token=?")->execute([$bot_token]);
        echo "✅ Webhook set for token: $bot_token\n";
        echo "URL: " . rtrim($domainhosts, '/') . "/child_bot.php?token=" . urlencode($bot_token) . "\n";
    } else {
        echo "❌ Failed: " . json_encode($result) . "\n";
    }
} else {
    // تنظیم همه زیر ربات‌های فعال
    $bots = $pdo->query("SELECT * FROM reseller_bot WHERE status IN ('active','pending')")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($bots)) { echo "No bots found.\n"; die(); }
    $ok_count = 0; $fail_count = 0;
    foreach ($bots as $b) {
        $result = child_set_webhook($b['bot_token'], $domainhosts);
        if ($result['ok'] ?? false) {
            $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE bot_token=?")->execute([$b['bot_token']]);
            echo "✅ @{$b['bot_username']} — OK\n";
            $ok_count++;
        } else {
            echo "❌ @{$b['bot_username']} — FAILED: " . ($result['description'] ?? 'unknown') . "\n";
            $fail_count++;
        }
    }
    echo "\nDone. OK: $ok_count | Failed: $fail_count\n";
}
