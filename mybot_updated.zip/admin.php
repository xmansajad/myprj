<?php

#----------------[  admin section  ]------------------#
// ===== نمایندگی - بخش ادمین =====
if (!defined('RESELLER_LOADED')) require_once 'reseller.php';
if (!defined('CHILD_BOTAPI_LOADED')) { define('CHILD_BOTAPI_LOADED', true); require_once 'child_botapi.php'; }

// Define helper function early to avoid undefined function errors
if (!function_exists('_fmt_gb')) {
    function _fmt_gb($gb) {
        return $gb >= 1024 ? round($gb/1024, 2).' TB' : $gb.' GB';
    }
}

// متن و دکمه‌های صفحه‌ی مدیریت یک زیر ربات — مشترک بین cb_manage_ و همه‌ی toggle ها
if (!function_exists('_render_bot_manage')) {
    function _render_bot_manage($b) {
        $bid    = $b['id'];
        $remain = max(0, $b['volume_limit'] - $b['volume_used']);
        $icons  = ['active'=>'✅','pending'=>'⏳','blocked'=>'🚫'];
        $info   = "{$icons[$b['status']]} <b>@{$b['bot_username']}</b>\n\n"
                . "👤 نماینده: <code>{$b['owner_id']}</code>\n"
                . "🌐 پنل: <b>{$b['panel_name']}</b>\n"
                . "💳 کیف پول: <b>" . number_format($b['wallet']) . " تومان</b>\n"
                . "🔗 Webhook: " . ($b['webhook_set'] ? '✅' : '❌') . "\n\n"
                . "📦 حجم: " . _fmt_gb($remain) . "/" . _fmt_gb($b['volume_limit']) . "\n"
                . "🔢 کانفیگ: {$b['config_used']}" . ($b['config_limit']>0 ? "/{$b['config_limit']}" : '') . "\n"
                . "💵 قیمت/گیگ: " . number_format($b['price_per_gb']) . " | 📅 قیمت/ماه: " . number_format($b['price_per_month']) . " تومان\n"
                . "⏳ انقضا: " . (($b['expire_at'] ?? 0) > 0
                    ? (max(0, ceil((($b['expire_at']) - time()) / 86400)) . " روز مانده (" . date('Y/m/d', $b['expire_at']) . ")")
                    : "نامحدود") . "\n"
                . "🔒 نسخه محدود: " . (($b['limited_panel'] ?? 1) ? '✅ فعال' : '🔓 غیرفعال (کامل)') . "\n"
                . "💰 حداقل قیمت اجباری: " . (($b['enforce_min_price'] ?? 1) ? '✅ فعال' : '🔓 غیرفعال') . "\n"
                . "📦 سقف حجم روی محصول: " . (($b['enforce_vol_cap_product'] ?? 0) ? '✅ فعال' : '🔓 غیرفعال');

        $btns = [
            [
                ['text' => '📦 سقف حجم',    'callback_data' => "cb_set_vol_{$bid}"],
                ['text' => '🔢 سقف کانفیگ', 'callback_data' => "cb_set_cfg_{$bid}"],
            ],
            [
                ['text' => '⏳ تمدید زمان (روز)', 'callback_data' => "cb_extend_days_{$bid}"],
            ],
            [
                ['text' => '💵 قیمت/گیگ',   'callback_data' => "cb_set_pgb_{$bid}"],
                ['text' => '📅 قیمت/ماه',   'callback_data' => "cb_set_pm_{$bid}"],
            ],
            [
                ['text' => '💳 شارژ کیف پول',  'callback_data' => "cb_charge_{$bid}"],
                ['text' => '📊 گزارش تفصیلی', 'callback_data' => "cb_report_{$bid}"],
            ],
            [
                ['text' => '🌐 تغییر پنل',     'callback_data' => "cb_change_panel_{$bid}"],
                ['text' => '🔐 تغییر توکن',    'callback_data' => "cb_change_token_{$bid}"],
            ],
            [
                ['text' => '🔗 Webhook',        'callback_data' => "cb_webhook_{$bid}"],
                ['text' => '🗑 حذف',           'callback_data' => "cb_delete_{$bid}"],
            ],
            [
                ['text' => (($b['limited_panel'] ?? 1) ? '🔓 غیرفعال کردن نسخه محدود' : '🔒 فعال کردن نسخه محدود'), 'callback_data' => "cb_toggle_limited_{$bid}"],
            ],
            [
                ['text' => (($b['enforce_min_price'] ?? 1) ? '🔓 غیرفعال کردن حداقل قیمت' : '💰 فعال کردن حداقل قیمت'), 'callback_data' => "cb_toggle_minprice_{$bid}"],
            ],
            [
                ['text' => (($b['enforce_vol_cap_product'] ?? 0) ? '🔓 غیرفعال کردن سقف حجم محصول' : '📦 فعال کردن سقف حجم محصول'), 'callback_data' => "cb_toggle_volcap_{$bid}"],
            ],
            [
                ['text' => ($b['status'] === 'pending' ? '✅ فعال‌سازی' : ($b['status'] === 'active' ? '🚫 بلاک' : '✅ فعال')), 'callback_data' => "cb_toggle_{$bid}"],
            ],
        ];
        return [$info, json_encode(['inline_keyboard' => $btns])];
    }
}

// Initialize $mykeyboard early before it's used
$_admin_role = get_admin_role($from_id);
if ($_admin_role === 'seller') {
    $mykeyboard = $keyboard_seller ?? [];
} elseif ($_admin_role === 'support') {
    $mykeyboard = $keyboard_support ?? [];
} else {
    $mykeyboard = $keyboardadmin ?? [];
}

// سیستم نمایندگی کلاسیک (مدیریت دستی نماینده‌های فروش کانفیگ) غیرفعال شده — فقط پنل نمایندگی اختصاصی فعال است
// if (is_super_admin($from_id) && handle_reseller_admin($from_id, $text, $datain, $user, $mykeyboard)) {
//     return;
// }

$textadmin = ["panel", "/panel", $textbotlang['Admin']['commendadminmanagment'], $textbotlang['Admin']['commendadmin']];
if (!in_array($from_id, $admin_ids))
    return;

if (in_array($text, $textadmin) || $datain == "PANEL") {
    if (!(function_exists('shell_exec') && is_callable('shell_exec'))) {
        $cronCommandsendmessage = "*/1 * * * * curl https://$domainhosts/cron/sendmessage.php";
        sendmessage($from_id, sprintf($textbotlang['Admin']['cron']['active_manual_sendmessage'], $cronCommandsendmessage), null, 'HTML');
    }
    $text_admin = sprintf($textbotlang['Admin']['login-admin'], $version);
    sendmessage($from_id, $text_admin, $mykeyboard, 'HTML');
}
if ($text == $textbotlang['Admin']['Back-Adminment'] || $datain == "back_admin") {
    if (in_array($user['step'], ['cb_reg_token', 'cb_reg_owner', 'cb_reg_panel'])) {
        update("user", "Processing_value", "", "id", $from_id);
    }
    if ($datain == "back_admin")
        deletemessage($from_id, $message_id);
    sendmessage($from_id, $textbotlang['Admin']['Back-Admin'], $mykeyboard, 'HTML');
    step('home', $from_id);
    return;
} elseif ($text == $textbotlang['Admin']['channel']['changechannelbtn']) {
    sendmessage($from_id, $textbotlang['Admin']['channel']['changechannel'] . $channels['link'], $backadmin, 'HTML');
    step('addchannel', $from_id);
} elseif ($user['step'] == "addchannel") {
    sendmessage($from_id, $textbotlang['Admin']['channel']['setchannel'], $channelkeyboard, 'HTML');
    step('home', $from_id);
    $channels_ch = select("channels", "link", null, null, "count");
    $Check_filde = $connect->query("SHOW COLUMNS FROM channels LIKE 'Channel_lock'");
    if (mysqli_num_rows($Check_filde) == 1) {
        $connect->query("ALTER TABLE channels DROP COLUMN Channel_lock;");
        $stmt->execute();
    }
    if ($channels_ch == 0) {
        $stmt = $pdo->prepare("INSERT INTO channels (link) VALUES (?)");
        $stmt->bindParam(1, $text, PDO::PARAM_STR);

        $stmt->execute();
    } else {
        update("channels", "link", $text);
    }
}
if ($text == $textbotlang['Admin']['Addedadmin']) {
    sendmessage($from_id, $textbotlang['Admin']['manageadmin']['getid'], $backadmin, 'HTML');
    step('addadmin', $from_id);
}
if ($user['step'] == "addadmin") {
    // قبول کردن هم آیدی عددی هم یوزرنیم (@username)
    $admin_input = trim($text);
    if (strpos($admin_input, '@') === 0) {
        // یوزرنیم — پیدا کردن آیدی از جدول user
        $uname = ltrim($admin_input, '@');
        $stmt_u = $pdo->prepare("SELECT id FROM user WHERE username = ? LIMIT 1");
        $stmt_u->execute([$uname]);
        $found = $stmt_u->fetch(PDO::FETCH_ASSOC);
        if (!$found) {
            sendmessage($from_id, "❌ کاربری با این یوزرنیم پیدا نشد. آیدی عددی را وارد کنید.", $backadmin, 'HTML');
            return;
        }
        $admin_input = $found['id'];
    }
    if (!is_numeric($admin_input)) {
        sendmessage($from_id, "❌ فرمت نامعتبر. آیدی عددی یا @username وارد کنید.", $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['manageadmin']['addadminset'], $mykeyboard, 'HTML');
    step('home', $from_id);
    $stmt = $pdo->prepare("INSERT INTO admin (id_admin) VALUES (?)");
    $stmt->bindParam(1, $admin_input);
    $stmt->execute();
}
if ($text == $textbotlang['Admin']['Removeedadmin']) {
    sendmessage($from_id, $textbotlang['Admin']['manageadmin']['getid'], $backadmin, 'HTML');
    step('deleteadmin', $from_id);
} elseif ($user['step'] == "deleteadmin") {
    if (intval($text) == $adminnumber) {
        sendmessage($from_id, $textbotlang['Admin']['manageadmin']['InfoAdd'], null, 'HTML');
        return;
    }
    if (!is_numeric($text) || !in_array($text, $admin_ids))
        return;
    sendmessage($from_id, $textbotlang['Admin']['manageadmin']['removedadmin'], $mykeyboard, 'HTML');
    $stmt = $pdo->prepare("DELETE FROM admin WHERE id_admin = ?");
    $stmt->bindParam(1, $text);
    $stmt->execute();
    step('home', $from_id);
}

// ==================== مدیریت نقش ادمین ====================
$backadmin_role = json_encode(['keyboard' => [
    [['text' => $textbotlang['Admin']['Back-Adminment']]]
], 'resize_keyboard' => true]);

// اضافه کردن ادمین فروش
if ($text == '🟡 اضافه کردن ادمین فروش') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, "🟡 <b>اضافه کردن ادمین فروش</b>\n\nآیدی عددی تلگرام ادمین فروش رو بفرست:", $backadmin_role, 'HTML');
    update("user", "Processing_value", "seller", "id", $from_id);
    step('add_role_admin', $from_id);
}

// اضافه کردن ادمین پشتیبانی
if ($text == '🟢 اضافه کردن ادمین پشتیبانی') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, "🟢 <b>اضافه کردن ادمین پشتیبانی</b>\n\nآیدی عددی تلگرام ادمین پشتیبانی رو بفرست:", $backadmin_role, 'HTML');
    update("user", "Processing_value", "support", "id", $from_id);
    step('add_role_admin', $from_id);
}

// step: دریافت آیدی و اضافه کردن ادمین با role مشخص
if ($user['step'] == 'add_role_admin') {
    $role_to_add = $user['Processing_value']; // seller یا support

    if (!is_numeric($text)) {
        sendmessage($from_id, "❌ آیدی باید عددی باشه.", $backadmin_role, 'HTML');
        return;
    }
    if (in_array($text, $admin_ids)) {
        $pdo->prepare("UPDATE admin SET role = ? WHERE id_admin = ?")->execute([$role_to_add, $text]);
    } else {
        $pdo->prepare("INSERT INTO admin (id_admin, role) VALUES (?, ?)")->execute([$text, $role_to_add]);
    }
    $role_fa = ['seller' => '🟡 فروش', 'support' => '🟢 پشتیبانی', 'super' => '🔴 Super'][$role_to_add];
    sendmessage($from_id, "✅ ادمین <code>{$text}</code> با نقش {$role_fa} اضافه شد.", $mykeyboard, 'HTML');
    step('home', $from_id);
}

// لیست ادمین‌ها با نقش
if ($text == '📋 لیست ادمین‌ها با نقش') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $list = '';
    $admins_db = $pdo->query("SELECT id_admin, role FROM admin")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($admins_db as $a) {
        $role_fa = ['super' => '🔴 Super', 'seller' => '🟡 Seller', 'support' => '🟢 Support'][$a['role']] ?? $a['role'];
        $list .= "👤 <code>{$a['id_admin']}</code> — {$role_fa}\n";
    }
    sendmessage($from_id, "📋 <b>لیست ادمین‌ها:</b>\n\n{$list}", $mykeyboard, 'HTML');
}

// تغییر نقش ادمین موجود
if ($text == '🔄 تغییر نقش ادمین') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $list = '';
    $admins_db = $pdo->query("SELECT id_admin, role FROM admin")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($admins_db as $a) {
        $role_fa = ['super' => '🔴 Super', 'seller' => '🟡 Seller', 'support' => '🟢 Support'][$a['role']] ?? $a['role'];
        $list .= "👤 <code>{$a['id_admin']}</code> — {$role_fa}\n";
    }
    sendmessage($from_id, "📋 ادمین‌های فعلی:\n\n{$list}\n✏️ آیدی و نقش جدید رو بفرست:\nمثال: <code>123456789 seller</code>\nنقش‌ها: <code>super</code> | <code>seller</code> | <code>support</code>", $backadmin_role, 'HTML');
    step('set_admin_role', $from_id);
} elseif ($user['step'] == 'set_admin_role') {
    $parts = explode(' ', trim($text));
    if (count($parts) != 2) { sendmessage($from_id, "❌ فرمت اشتباه. مثال: <code>123456789 seller</code>", $backadmin_role, 'HTML'); return; }
    $target_id = $parts[0];
    $new_role  = $parts[1];
    if (!in_array($new_role, ['super', 'seller', 'support'])) {
        sendmessage($from_id, "❌ نقش نامعتبر. باید: super | seller | support", $backadmin_role, 'HTML'); return;
    }
    if (!in_array($target_id, $admin_ids)) {
        sendmessage($from_id, "❌ این آیدی ادمین نیست.", $backadmin_role, 'HTML'); return;
    }
    $pdo->prepare("UPDATE admin SET role = ? WHERE id_admin = ?")->execute([$new_role, $target_id]);
    $role_fa = ['super' => '🔴 Super', 'seller' => '🟡 Seller', 'support' => '🟢 Support'][$new_role];
    sendmessage($from_id, "✅ نقش ادمین <code>{$target_id}</code> به {$role_fa} تغییر یافت.", $mykeyboard, 'HTML');
    step('home', $from_id);
}
// ============================================================

if ($user['step'] == "get_number_limit") {
    sendmessage($from_id, $textbotlang['Admin']['getlimitusertest']['setlimit'], $mykeyboard, 'HTML');
    $id_user_set = $text;
    step('home', $from_id);
    update("user", "limit_usertest", $text, "id", $user['Processing_value']);
}
if ($text == $textbotlang['Admin']['getlimitusertest']['setlimitallbtn']) {
    sendmessage($from_id, $textbotlang['Admin']['getlimitusertest']['limitall'], $backadmin, 'HTML');
    step('limit_usertest_allusers', $from_id);
} elseif ($user['step'] == "limit_usertest_allusers") {
    sendmessage($from_id, $textbotlang['Admin']['getlimitusertest']['setlimitall'], $keyboard_usertest, 'HTML');
    step('home', $from_id);
    update("setting", "limit_usertest_all", $text);
    update("user", "limit_usertest", $text);
}
if ($text == $textbotlang['Admin']['channel']['setting']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $channelkeyboard, 'HTML');
}
#-------------------------#
if ($text == $textbotlang['Admin']['keyboardadmin']['bot_statistics']) {
    $current_date_time = time();
    $datefirst = $current_date_time - 86400;
    $desired_date_time_start = $current_date_time - 3600;
    $month_date_time_start = $current_date_time - 2592000;
    $datefirstday = time() - 86400;
    $dateacc = jdate('Y/m/d');
    $sql = "SELECT * FROM invoice WHERE  (Status = 'active' OR Status = 'end_of_time'  OR Status = 'end_of_volume' OR status = 'sendedwarn') AND name_product != 'usertest'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $dayListSell = $stmt->rowCount();
    $Balanceall = select("user", "SUM(Balance)", null, null, "select");
    $statistics = select("user", "*", null, null, "count");
    $sumpanel = select("marzban_panel", "*", null, null, "count");
    $sqlinvoice = "SELECT *  FROM invoice WHERE (Status = 'active' OR Status = 'end_of_time'  OR Status = 'end_of_volume' OR Status = 'sendedwarn') AND name_product != 'usertest'";
    $stmt = $pdo->prepare($sqlinvoice);
    $stmt->execute();
    $invoice = $stmt->rowCount();
    $sql = "SELECT SUM(price_product)  FROM invoice WHERE (status = 'active' OR status = 'end_of_time'  OR status = 'end_of_volume' OR status = 'sendedwarn') AND name_product != 'usertest'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $invoicesum = $stmt->fetch(PDO::FETCH_ASSOC)['SUM(price_product)'];
    $sql = "SELECT SUM(price_product) FROM invoice WHERE time_sell > :time_sell AND (Status = 'active' OR Status = 'end_of_time'  OR Status = 'end_of_volume' OR status = 'sendedwarn') AND name_product != 'usertest'";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':time_sell', $datefirstday);
    $stmt->execute();
    $dayListSell = $stmt->rowCount();
    $count_usertest = select("invoice", "*", "name_product", "usertest", "count");
    $ping = sys_getloadavg();
    $ping = number_format(floatval($ping[0]), 2);
    $timeacc = jdate('H:i:s', time());
    $statisticsall = sprintf($textbotlang['Admin']['Statistics']['info'], $statistics, $Balanceall['SUM(Balance)'], $ping, $count_usertest, $invoice, $invoicesum, $dayListSell, $sumpanel);
    sendmessage($from_id, $statisticsall, null, 'HTML');
}

if ($text == $textbotlang['Admin']['managepanel']['btnshowconnect']) {
    $marzban_list_get = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($marzban_list_get['type'] == "marzban") {
        $Check_token = token_panel($marzban_list_get['id']);
        if (isset($Check_token['access_token'])) {
            $System_Stats = Get_System_Stats($user['Processing_value']);
            $active_users = $System_Stats['users_active'];
            $total_user = $System_Stats['total_user'];
            $mem_total = formatBytes($System_Stats['mem_total']);
            $mem_used = formatBytes($System_Stats['mem_used']);
            $bandwidth = formatBytes($System_Stats['outgoing_bandwidth'] + $System_Stats['incoming_bandwidth']);
            $Condition_marzban = "";
            $text_marzban = sprintf($textbotlang['Admin']['managepanel']['infomarzban'], $total_user, $active_users, $System_Stats['version'], $mem_total, $mem_used, $bandwidth);
            sendmessage($from_id, $text_marzban, null, 'HTML');
        } elseif (isset($Check_token['detail']) && $Check_token['detail'] == "Incorrect username or password") {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['Incorrectinfo'], null, 'HTML');
        } else {
            $text_marzban = $textbotlang['Admin']['managepanel']['errorstatuspanel'] . json_encode($Check_token);
            sendmessage($from_id, $text_marzban, null, 'HTML');
        }
    } elseif ($marzban_list_get['type'] == "marzneshin") {
        $Check_token = token_panelm($marzban_list_get['url_panel'], $marzban_list_get['username_panel'], $marzban_list_get['password_panel']);
        if (isset($Check_token['access_token'])) {
            $System_Stats = Get_System_Statsm($user['Processing_value']);
            $active_users = $System_Stats['active'];
            $total_user = $System_Stats['total'];
            $text_marzban = sprintf($textbotlang['Admin']['managepanel']['infomarzneshin'], $total_user, $active_users);
            sendmessage($from_id, $text_marzban, null, 'HTML');
        } elseif (isset($Check_token['detail']) && $Check_token['detail'] == "Incorrect username or password") {
            $text_marzban = $textbotlang['Admin']['managepanel']['Incorrectinfo'];
            sendmessage($from_id, $text_marzban, null, 'HTML');
        } else {
            $text_marzban = $textbotlang['Admin']['managepanel']['errorstatuspanel'] . json_encode($Check_token);
            sendmessage($from_id, $text_marzban, null, 'HTML');
        }
    } elseif ($marzban_list_get['type'] == "x-ui_single") {
        $x_ui_check_connect = login($marzban_list_get['id'], false);
        if ($x_ui_check_connect['success']) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['connectx-ui'], null, 'HTML');
        } elseif ($x_ui_check_connect['msg'] == "Invalid username or password.") {
            $text_marzban = $textbotlang['Admin']['managepanel']['Incorrectinfo'];
            sendmessage($from_id, $text_marzban, null, 'HTML');
        } else {
            $text_marzban = $textbotlang['Admin']['managepanel']['errorstatuspanel'];
            sendmessage($from_id, $text_marzban, null, 'HTML');
        }
    } elseif ($marzban_list_get['type'] == "alireza") {
        $x_ui_check_connect = loginalireza($marzban_list_get['url_panel'], $marzban_list_get['username_panel'], $marzban_list_get['password_panel']);
        if ($x_ui_check_connect['success']) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['connectx-ui'], null, 'HTML');
        } elseif ($x_ui_check_connect['msg'] == "Invalid username or password.") {
            $text_marzban = $textbotlang['Admin']['managepanel']['Incorrectinfo'];
            sendmessage($from_id, $text_marzban, null, 'HTML');
        } else {
            $text_marzban = $textbotlang['Admin']['managepanel']['errorstatuspanel'];
            sendmessage($from_id, $text_marzban, null, 'HTML');
        }
    } elseif ($marzban_list_get['type'] == "wgdashboard") {
        sendmessage($from_id, $textbotlang['users']['selectoption'], $optionwgdashboard, 'HTML');
    } elseif ($marzban_list_get['type'] == "mikrotik") {
        $result = login_mikrotik($marzban_list_get['url_panel'], $marzban_list_get['username_panel'], $marzban_list_get['password_panel']);
        if (isset($result['error'])) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['notconnect'], $optionmikrotik, 'HTML');
        } else {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['connectx-ui'], $optionmikrotik, 'HTML');
        }
    } elseif ($marzban_list_get['type'] == "remnawave") {
        $Check_token = token_panel_remna($marzban_list_get['name_panel']);
        if (isset($Check_token['access_token'])) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['connectx-ui'], null, 'HTML');
        } elseif (isset($Check_token['message']) && strpos(strtolower($Check_token['message']), 'unauthorized') !== false) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['Incorrectinfo'], null, 'HTML');
        } else {
            $text_marzban = $textbotlang['Admin']['managepanel']['errorstatuspanel'] . json_encode($Check_token);
            sendmessage($from_id, $text_marzban, null, 'HTML');
        }
    }
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['manageadmin']['showlistbtn']) {
    $List_admin = null;
    $admin_ids = array_filter($admin_ids);
    foreach ($admin_ids as $admin) {
        $List_admin .= "$admin\n";
    }
    $list_admin_text = sprintf($textbotlang['Admin']['manageadmin']['showlist'], $List_admin);
    sendmessage($from_id, $list_admin_text, $admin_section_panel, 'HTML');
}
if ($text == $textbotlang['Admin']['keyboardadmin']['add_panel']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['selecttypepanel'], $typepanel, 'HTML');
} elseif (preg_match('/typepanel%(.*)/', $datain, $dataget)) {
    $type = $dataget[1];
    savedata("clear", "type", $type);
    deletemessage($from_id, $message_id);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['addpanelname'], $backadmin, 'HTML');
    step('add_name_panel', $from_id);
} elseif ($user['step'] == "add_name_panel") {
    if (in_array($text, $marzban_list)) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['Repeatpanel'], $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['addpanelurl'], $backadmin, 'HTML');
    savedata("save", "name", $text);
    step('add_link_panel', $from_id);
} elseif ($user['step'] == "add_link_panel") {
    if (!filter_var($text, FILTER_VALIDATE_URL)) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['Invalid-domain'], $backadmin, 'HTML');
        return;
    }
    savedata("save", "url_panel", $text);
    $userdata = json_decode($user['Processing_value'], true);
    if ($userdata['type'] == "s_ui" || $userdata['type'] == "wgdashboard") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['settoken'], $backadmin, 'HTML');
        step('add_password_panel', $from_id);
        savedata("save", "username_panel", "none");
        return;
    }
    if ($userdata['type'] == "remnawave") {
        sendmessage($from_id, "🔐 یوزرنیم و پسورد Caddy رو وارد کن:\n\nفرمت: <code>username:password</code>\n\nاگه Caddy Basic Auth نداری، بنویس: <code>none</code>", $backadmin, 'HTML');
        step('add_remna_caddy', $from_id);
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['usernameset'], $backadmin, 'HTML');
    step('add_username_panel', $from_id);
} elseif ($user['step'] == "add_remna_caddy") {
    $caddy = trim($text);
    // اگه none بود یا فرمت user:pass نداشت، خالی ذخیره کن
    if ($caddy == "none" || strpos($caddy, ':') === false) {
        $caddy = "0";
    }
    savedata("save", "caddy_auth", $caddy);
    sendmessage($from_id, "🔑 حالا API Token پنل رو وارد کن:\n\n(از داشبورد Settings > API Tokens بگیر)", $backadmin, 'HTML');
    step('add_remna_token', $from_id);
} elseif ($user['step'] == "add_remna_token") {
    $userdata = json_decode($user['Processing_value'], true);
    $caddy_auth = isset($userdata['caddy_auth']) ? $userdata['caddy_auth'] : "0";
    $sublink = "onsublink";
    $config  = "offconfig";
    $valueteststatus = "ontestshowpanel";
    $stauts  = "activepanel";
    $on_hold = "offonhold";
    $stmt = $pdo->prepare("INSERT INTO marzban_panel (name_panel,url_panel,username_panel,password_panel,type,inboundid,sublink,configManual,MethodUsername,statusTest,status,onholdstatus) VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?,?)");
    $stmt->execute([$userdata['name'], $userdata['url_panel'], "remnawave", $text, "remnawave", $caddy_auth, $sublink, $config, $textbotlang['users']['customidAndRandom'], $valueteststatus, $stauts, $on_hold]);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['addedpanel'], $backadmin, 'HTML');
    sendmessage($from_id, "🥳", $mykeyboard, 'HTML');
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['notemarzban'], null, 'HTML');
    step('home', $from_id);
} elseif ($user['step'] == "add_username_panel") {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['getpassword'], $backadmin, 'HTML');
    step('add_password_panel', $from_id);
    savedata("save", "username_panel", $text);
} elseif ($user['step'] == "add_password_panel") {
    $userdata = json_decode($user['Processing_value'], true);
    $inboundid = "0";
    $sublink = "onsublink";
    $config = "offconfig";
    $valueteststatus = "ontestshowpanel";
    $stauts = "activepanel";
    $on_hold = "offonhold";
    $stmt = $pdo->prepare("INSERT INTO marzban_panel (name_panel,url_panel,username_panel,password_panel,type,inboundid,sublink,configManual,MethodUsername,statusTest,status,onholdstatus) VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?,?)");
    $stmt->execute([$userdata['name'], $userdata['url_panel'], $userdata['username_panel'], $text, $userdata['type'], $inboundid, $sublink, $config, $textbotlang['users']['customidAndRandom'], $valueteststatus, $stauts, $on_hold]);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['addedpanel'], $backadmin, 'HTML');
    sendmessage($from_id, "🥳", $mykeyboard, 'HTML');
    if ($userdata['type'] == "x-ui_single" or $userdata['type'] == "alireza") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['notex-ui'], null, 'HTML');
    } elseif ($userdata['type'] == "marzban" || $userdata['type'] == "s_ui" || $userdata['type'] == "marzneshin") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['notemarzban'], null, 'HTML');
    } elseif ($userdata['type'] == "wgdashboard") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['wgdashboard'], null, 'HTML');
    } elseif ($userdata['type'] == "mikrotik") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['mikrotik'], null, 'HTML');
    }
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['keyboardadmin']['send_message']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $sendmessageuser, 'HTML');
} elseif ($text == $textbotlang['Admin']['systemsms']['sendbulkbtn']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['GetText'], $backadmin, 'HTML');
    step('getconfirmsendall', $from_id);
} elseif ($user['step'] == "getconfirmsendall") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['systemsms']['allowsendtext'], $backadmin, 'HTML');
        return;
    }
    savedata("clear", "text", $text);
    savedata("save", "id_admin", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['systemsms']['acceptsend'], $backadmin, 'HTML');
    step("gettextforsendall", $from_id);
} elseif ($user['step'] == "gettextforsendall") {
    $userdata = json_decode($user['Processing_value'], true);
    if ($text == $textbotlang['Admin']['accept']) {
        step('home', $from_id);
        $result = select("user", "id", "User_Status", "Active", "fetchAll");
        $Respuseronse = json_encode([
            'inline_keyboard' => [
                [
                    ['text' => $textbotlang['Admin']['systemsms']['cancelsend'], 'callback_data' => 'cancel_sendmessage'],
                ],
            ]
        ]);
        file_put_contents('cron/users.json', json_encode($result));
        file_put_contents('cron/info', $user['Processing_value']);
        sendmessage($from_id, $textbotlang['Admin']['systemsms']['sendingmessage'], $Respuseronse, 'HTML');
    }
} elseif ($datain == "cancel_sendmessage") {
    unlink('cron/users.json');
    unlink('cron/info');
    deletemessage($from_id, $message_id);
    sendmessage($from_id, $textbotlang['Admin']['systemsms']['canceledmessage'], null, 'HTML');
} elseif ($text == $textbotlang['Admin']['systemsms']['forwardbulkbtn']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ForwardGetext'], $backadmin, 'HTML');
    step('gettextforwardMessage', $from_id);
} elseif ($user['step'] == "gettextforwardMessage") {
    sendmessage($from_id, $textbotlang['Admin']['systemsms']['sendingforward'], $mykeyboard, 'HTML');
    step('home', $from_id);
    $filename = 'user.txt';
    $stmt = $pdo->prepare("SELECT id FROM user");
    $stmt->execute();
    if ($result) {
        $ids = array();
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $ids[] = $row['id'];
        }
        $idsText = implode("\n", $ids);
        file_put_contents($filename, $idsText);
    }
    $file = fopen($filename, 'r');
    if ($file) {
        while (($line = fgets($file)) !== false) {
            $line = trim($line);
            forwardMessage($from_id, $message_id, $line);
            usleep(2000000);
        }
        sendmessage($from_id, $textbotlang['Admin']['systemsms']['sendforwardtousers'], $mykeyboard, 'HTML');
        fclose($file);
    }
    unlink($filename);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['keyboardadmin']['bot_text_settings']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['users']['selectoption'], $textbot, 'HTML');
} elseif ($text == $textbotlang['Admin']['changetext']['textstart']) {
    $textstart = $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_start'];
    sendmessage($from_id, $textstart, $backadmin, 'HTML');
    step('changetextstart', $from_id);
} elseif ($user['step'] == "changetextstart") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_start");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_Purchased_services']) {
    $textstart = $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_Purchased_services'];
    sendmessage($from_id, $textstart, $backadmin, 'HTML');
    step('changetextinfo', $from_id);
} elseif ($user['step'] == "changetextinfo") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_Purchased_services");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_usertest']) {
    $textstart = $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_usertest'];
    sendmessage($from_id, $textstart, $backadmin, 'HTML');
    step('changetextusertest', $from_id);
} elseif ($user['step'] == "changetextusertest") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_usertest");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_help']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_help'], $backadmin, 'HTML');
    step('text_help', $from_id);
} elseif ($user['step'] == "text_help") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_help");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_support']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_support'], $backadmin, 'HTML');
    step('text_support', $from_id);
} elseif ($user['step'] == "text_support") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_support");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_fq']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_fq'], $backadmin, 'HTML');
    step('text_fq', $from_id);
} elseif ($user['step'] == "text_fq") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_fq");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_dec_fq']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_dec_fq'], $backadmin, 'HTML');
    step('text_dec_fq', $from_id);
} elseif ($user['step'] == "text_dec_fq") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_dec_fq");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_channel']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_channel'], $backadmin, 'HTML');
    step('text_channel', $from_id);
} elseif ($user['step'] == "text_channel") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_channel");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_account']) {
    $textstart = $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_account'];
    sendmessage($from_id, $textstart, $backadmin, 'HTML');
    step('text_account', $from_id);
} elseif ($user['step'] == "text_account") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_account");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_Add_Balance']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_Add_Balance'], $backadmin, 'HTML');
    step('text_Add_Balance', $from_id);
} elseif ($user['step'] == "text_Add_Balance") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_Add_Balance");
    step('home', $from_id);
} elseif ($text == $textbotlang['users']['changetext']['buy_subscription_button']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_sell'], $backadmin, 'HTML');
    step('text_sell', $from_id);
} elseif ($user['step'] == "text_sell") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_sell");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_Tariff_list']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_Tariff_list'], $backadmin, 'HTML');
    step('text_Tariff_list', $from_id);
} elseif ($user['step'] == "text_Tariff_list") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_Tariff_list");
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['changetext']['text_dec_Tariff_list']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_dec_Tariff_list'], $backadmin, 'HTML');
    step('text_dec_Tariff_list', $from_id);
} elseif ($user['step'] == "text_dec_Tariff_list") {
    if (!$text) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ErrorText'], $textbot, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_dec_Tariff_list");
    step('home', $from_id);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['systemsms']['sendmessageauser']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['GetText'], $backadmin, 'HTML');
    step('sendmessagetext', $from_id);
} elseif ($user['step'] == "sendmessagetext") {
    update("user", "Processing_value", $text, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['GetIDMessage'], $backadmin, 'HTML');
    step('sendmessagetid', $from_id);
} elseif ($user['step'] == "sendmessagetid") {
    if (!in_array($text, $users_ids)) {
        sendmessage($from_id, $textbotlang['Admin']['not-user'], $backadmin, 'HTML');
        return;
    }
    $textsendadmin = sprintf($textbotlang['Admin']['systemsms']['sendedmessagetouser'], $user['Processing_value']);
    sendmessage($text, $textsendadmin, null, 'HTML');
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['MessageSent'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['Help']['titlebtn']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $keyboardhelpadmin, 'HTML');
} elseif ($text == $textbotlang['Admin']['Help']['addhelp']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['GetAddNameHelp'], $backadmin, 'HTML');
    step('add_name_help', $from_id);
} elseif ($user['step'] == "add_name_help") {
    $stmt = $pdo->prepare("INSERT IGNORE INTO help (name_os) VALUES (?)");
    $stmt->bindParam(1, $text, PDO::PARAM_STR);
    $stmt->execute();
    sendmessage($from_id, $textbotlang['Admin']['Help']['GetAddDecHelp'], $backadmin, 'HTML');
    step('add_dec', $from_id);
    update("user", "Processing_value", $text, "id", $from_id);
} elseif ($user['step'] == "add_dec") {
    if ($photo) {
        update("help", "Media_os", $photoid, "name_os", $user['Processing_value']);
        update("help", "Description_os", $caption, "name_os", $user['Processing_value']);
        update("help", "type_Media_os", "photo", "name_os", $user['Processing_value']);
    } elseif ($text) {
        update("help", "Description_os", $text, "name_os", $user['Processing_value']);
    } elseif ($video) {
        update("help", "Media_os", $videoid, "name_os", $user['Processing_value']);
        update("help", "Description_os", $caption, "name_os", $user['Processing_value']);
        update("help", "type_Media_os", "video", "name_os", $user['Processing_value']);
    }
    sendmessage($from_id, $textbotlang['Admin']['Help']['SaveHelp'], $mykeyboard, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['Help']['removehelpbtn']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['SelectName'], $json_list_help, 'HTML');
    step('remove_help', $from_id);
} elseif ($user['step'] == "remove_help") {
    $stmt = $pdo->prepare("DELETE FROM help WHERE name_os = ?");
    $stmt->execute([$text]);
    sendmessage($from_id, $textbotlang['Admin']['Help']['RemoveHelp'], $keyboardhelpadmin, 'HTML');
    step('home', $from_id);
}
//_________________________________________________
if (preg_match('/Response_(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    update("user", "Processing_value", $iduser, "id", $from_id);
    step('getmessageAsAdmin', $from_id);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['GetTextResponse'], $backadmin, 'HTML');
} elseif ($user['step'] == "getmessageAsAdmin") {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SendMessageuser'], null, 'HTML');
    if ($text) {
        $textSendAdminToUser = sprintf($textbotlang['Admin']['systemsms']['sendedmessagetouser'], $text);
        sendmessage($user['Processing_value'], $textSendAdminToUser, null, 'HTML');
    }
    if ($photo) {
        $textSendAdminToUser = sprintf($textbotlang['Admin']['systemsms']['sendedmessagetouser'], $caption);
        telegram('sendphoto', [
            'chat_id' => $user['Processing_value'],
            'photo' => $photoid,
            'caption' => $textSendAdminToUser,
            'parse_mode' => "HTML",
        ]);
    }
    step('home', $from_id);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['managepanel']['showpanelbtn']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['status'], 'callback_data' => $panel['status']],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['showpaneldec'], $view_Status, 'HTML');
}
if ($datain == "activepanel") {
    update("marzban_panel", "status", "disablepanel", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['status'], 'callback_data' => $panel['status']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['managepanel']['offpanel'], $view_Status);
} elseif ($datain == "disablepanel") {
    update("marzban_panel", "status", "activepanel", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['status'], 'callback_data' => $panel['status']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['managepanel']['onpanel'], $view_Status);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['managepanel']['showpaneltestbtn']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['statusTest'], 'callback_data' => $panel['statusTest']],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['showpaneldec'], $view_Status, 'HTML');
}
if ($datain == "ontestshowpanel") {
    update("marzban_panel", "statusTest", "offtestshowpanel", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['statusTest'], 'callback_data' => $panel['statusTest']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['managepanel']['offpanel'], $view_Status);
} elseif ($datain == "offtestshowpanel") {
    update("marzban_panel", "statusTest", "ontestshowpanel", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $view_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['statusTest'], 'callback_data' => $panel['statusTest']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['managepanel']['onpanel'], $view_Status);
}
//_________________________________________________
elseif (preg_match('/banuserlist_(\w+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $iduser = $dataget[1];
    $userblock = select("user", "*", "id", $iduser, "select");
    if ($userblock['User_Status'] == "block") {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['BlockedUser'], $backadmin, 'HTML');
        return;
    }
    update("user", "Processing_value", $iduser, "id", $from_id);
    update("user", "User_Status", "block", "id", $iduser);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['BlockUser'], $backadmin, 'HTML');
    step('adddecriptionblock', $from_id);
} elseif ($user['step'] == "adddecriptionblock") {
    update("user", "description_blocking", $text, "id", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['DescriptionBlock'], $mykeyboard, 'HTML');
    step('home', $from_id);
} elseif (preg_match('/unbanuserr_(\w+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $iduser = $dataget[1];
    $userunblock = select("user", "*", "id", $iduser, "select");
    if ($userunblock['User_Status'] == "Active") {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['UserNotBlock'], $backadmin, 'HTML');
        return;
    }
    update("user", "User_Status", "Active", "id", $iduser);
    update("user", "description_blocking", "", "id", $iduser);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['UserUnblocked'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
//_________________________________________________
elseif ($text == $textbotlang['Admin']['changetext']['ruletext']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ChangeTextGet'] . $datatextbot['text_roll'], $backadmin, 'HTML');
    step('text_roll', $from_id);
} elseif ($user['step'] == "text_roll") {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SaveText'], $textbot, 'HTML');
    update("textbot", "text", $text, "id_text", "text_roll");
    step('home', $from_id);
}
//_________________________________________________
if ($text == $textbotlang['Admin']['keyboardadmin']['user_services']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $User_Services, 'HTML');
}
#-------------------------#
elseif (preg_match('/confirmnumber_(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    update("user", "number", "confrim number by admin", "id", $iduser);
    step('home', $iduser);
    sendmessage($from_id, $textbotlang['Admin']['phone']['active'], $User_Services, 'HTML');
}
if ($text == $textbotlang['Admin']['channel']['channelreport']) {
    sendmessage($from_id, $textbotlang['Admin']['Channel']['ReportChannel'] . $setting['Channel_Report'], $backadmin, 'HTML');
    step('addchannelid', $from_id);
} elseif ($user['step'] == "addchannelid") {
    sendmessage($from_id, $textbotlang['Admin']['Channel']['SetChannelReport'], $mykeyboard, 'HTML');
    update("setting", "Channel_Report", $text);
    step('home', $from_id);
    sendmessage($setting['Channel_Report'], $textbotlang['Admin']['Channel']['TestChannel'], null, 'HTML');
}
#-------------------------#
if ($text == $textbotlang['Admin']['keyboardadmin']['shop_section']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $shopkeyboard, 'HTML');
} elseif ($text == $textbotlang['Admin']['Product']['addproduct']) {
    $locationproduct = select("marzban_panel", "*", null, null, "count");
    if ($locationproduct == 0) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['nullpaneladmin'], null, 'HTML');
        return;
    }
    // پاکسازی Processing_value قبل از شروع فلو
    update("user", "Processing_value", "", "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Product']['AddProductStepOne'], $backadmin, 'HTML');
    step('get_limit', $from_id);
} elseif ($user['step'] == "get_limit") {
    $randomString = bin2hex(random_bytes(2));
    $stmt = $pdo->prepare("INSERT IGNORE INTO product (name_product, code_product) VALUES (?, ?)");
    $stmt->bindParam(1, $text);
    $stmt->bindParam(2, $randomString);

    $stmt->execute();
    update("user", "Processing_value", $randomString, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Product']['Service_location'], $json_list_marzban_panel, 'HTML');
    step('get_location', $from_id);
} elseif ($user['step'] == "get_location") {
    // Processing_value رو از JSON parse کن اگه JSON باشه
    $pv_gl = $user['Processing_value'];
    $pv_gl_json = json_decode($pv_gl, true);
    $code_product_gl = (is_array($pv_gl_json) && isset($pv_gl_json['code_product'])) ? $pv_gl_json['code_product'] : $pv_gl;
    update("product", "Location", $text, "code_product", $code_product_gl);
    // Processing_value رو به code_product خالص update کن
    update("user", "Processing_value", $code_product_gl, "id", $from_id);
    // اگه پنل انتخاب‌شده remnawave هست، اسکواد رو هم بپرس
    $selected_panel = select("marzban_panel", "*", "name_panel", $text, "select");
    if ($selected_panel && $selected_panel['type'] == "remnawave") {
        $squads = get_squads_remna($selected_panel['name_panel']);
        if (!isset($squads['internalSquads']) || count($squads['internalSquads']) == 0) {
            sendmessage($from_id, "⚠️ هیچ اسکوادی در پنل پیدا نشد. ابتدا از مدیریت پنل اسکواد تنظیم کن.", $backadmin, 'HTML');
            return;
        }
        $buttons = [];
        foreach ($squads['internalSquads'] as $sq) {
            $inbound_tags = array_column($sq['inbounds'], 'tag');
            $tag_list = implode(', ', array_map(fn($t) => str_replace('VLESS_', '', $t), $inbound_tags));
            $buttons[] = [['text' => "🔵 " . $sq['name'] . "\n↳ " . $tag_list, 'callback_data' => "product_squad%" . $sq['uuid']]];
        }
        $buttons[] = [['text' => "✅ همه اسکوادها", 'callback_data' => "product_squad%all"]];
        $buttons[] = [['text' => $textbotlang['Admin']['Back-Adminment'], 'callback_data' => "back_admin"]];
        $squad_keyboard = json_encode(['inline_keyboard' => $buttons]);
        sendmessage($from_id, "🔵 کدوم اسکواد (نود/پروتکل) برای این محصول استفاده بشه؟", $squad_keyboard, 'HTML');
        step('get_product_squad', $from_id);
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Product']['Getcategory'], KeyboardCategory(), 'HTML');
    step('get_category', $from_id);
} elseif (preg_match('/product_squad%(.*)/', $datain, $dataget) && $user['step'] == "get_product_squad") {
    $squad_uuid = $dataget[1];
    deletemessage($from_id, $message_id);
    // Processing_value ممکنه JSON باشه اگه قبلاً savedata زده شده - باید code_product رو از JSON بخونیم
    $pv = $user['Processing_value'];
    $pv_json = json_decode($pv, true);
    $code_product = (is_array($pv_json) && isset($pv_json['code_product'])) ? $pv_json['code_product'] : $pv;
    update("product", "squad_uuid", $squad_uuid, "code_product", $code_product);
    sendmessage($from_id, $textbotlang['Admin']['Product']['Getcategory'], KeyboardCategory(), 'HTML');
    step('get_category', $from_id);
} elseif ($user['step'] == "get_category") {
    $category = select("category", "*", "remark", $text, "select");
    if ($category == false) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['invalidcategory'], $backadmin, 'HTML');
        return;
    }
    update("product", "category", $category['id'], "code_product", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Product']['GetLimit'], $backadmin, 'HTML');
    step('get_time', $from_id);
} elseif ($user['step'] == "get_time") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['Invalidvolume'], $backadmin, 'HTML');
        return;
    }
    update("product", "Volume_constraint", $text, "code_product", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Product']['GettIime'], $backadmin, 'HTML');
    step('get_price', $from_id);
} elseif ($user['step'] == "get_price") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['InvalidTime'], $backadmin, 'HTML');
        return;
    }
    update("product", "Service_time", $text, "code_product", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Product']['GetPrice'], $backadmin, 'HTML');
    step('endstep', $from_id);
} elseif ($user['step'] == "endstep") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['InvalidPrice'], $backadmin, 'HTML');
        return;
    }
    update("product", "price_product", $text, "code_product", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Product']['SaveProduct'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['keyboardadmin']['admin_section']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['users']['selectoption'], $admin_section_panel, 'HTML');
}
#-------------------------#
if ($text == $textbotlang['Admin']['keyboardadmin']['settings']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['users']['selectoption'], $setting_panel, 'HTML');
}
#-------------------------#
if ($text == $textbotlang['Admin']['keyboardadmin']['test_account_settings']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $keyboard_usertest, 'HTML');
}
#-------------------------#
if (preg_match('/Confirm_pay_(\w+)/', $datain, $dataget)) {
    $order_id = $dataget[1];
    $Payment_report = select("Payment_report", "*", "id_order", $order_id, "select");
    $Balance_id = select("user", "*", "id", $Payment_report['id_user'], "select");
    if ($Payment_report['payment_Status'] == "paid" || $Payment_report['payment_Status'] == "reject") {
        telegram(
            'answerCallbackQuery',
            array(
                'callback_query_id' => $callback_query_id,
                'text' => $textbotlang['Admin']['Payment']['reviewedpayment'],
                'show_alert' => true,
                'cache_time' => 5,
            )
        );
        return;
    }
    DirectPayment($order_id);
    $keyboard_accept = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['users']['moeny']['paymentaccepted'], 'callback_data' => "none"],
            ],
        ]
    ]);
    telegram('editMessageCaption',[
        'chat_id' => $from_id,
        'message_id' => $message_id,
        'caption' => $caption,
        'reply_markup' => $keyboard_accept
    ]);
    update("user", "Processing_value", "0", "id", $Balance_id['id']);
    update("user", "Processing_value_one", "0", "id", $Balance_id['id']);
    update("user", "Processing_value_tow", "0", "id", $Balance_id['id']);
    update("Payment_report", "payment_Status", "paid", "id_order", $order_id);
    if (isset($setting['Channel_Report']) && strlen($setting['Channel_Report']) > 0) {
        sendmessage($setting['Channel_Report'], sprintf($textbotlang['Admin']['Report']['acceptcartresid'], $from_id, $Payment_report['price']), null, 'HTML');
    }
}
#-------------------------#
if (preg_match('/reject_pay_(\w+)/', $datain, $datagetr)) {
    $id_order = $datagetr[1];
    $Payment_report = select("Payment_report", "*", "id_order", $id_order, "select");
    update("user", "Processing_value", $Payment_report['id_user'], "id", $from_id);
    update("user", "Processing_value_one", $id_order, "id", $from_id);
    if ($Payment_report['payment_Status'] == "reject" || $Payment_report['payment_Status'] == "paid") {
        telegram(
            'answerCallbackQuery',
            array(
                'callback_query_id' => $callback_query_id,
                'text' => $textbotlang['Admin']['Payment']['reviewedpayment'],
                'show_alert' => true,
                'cache_time' => 5,
            )
        );
        return;
    }
    update("Payment_report", "payment_Status", "reject", "id_order", $id_order);
    sendmessage($from_id, $textbotlang['Admin']['Payment']['Reasonrejecting'], $backadmin, 'HTML');
    step('reject-dec', $from_id);
    Editmessagetext($from_id, $message_id, $text_callback, null);
} elseif ($user['step'] == "reject-dec") {
    update("Payment_report", "dec_not_confirmed", $text, "id_order", $user['Processing_value_one']);
    sendmessage($from_id, $textbotlang['Admin']['Payment']['Rejected'], $mykeyboard, 'HTML');
    sendmessage($user['Processing_value'], sprintf($textbotlang['users']['moeny']['rejectresid'], $text, $user['Processing_value_one']), null, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['titlebtnremove']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['Rmove_location'], $json_list_marzban_panel, 'HTML');
    step('selectloc', $from_id);
} elseif ($user['step'] == "selectloc") {
    update("user", "Processing_value", $text, "id", $from_id);
    step('remove-product', $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Product']['selectRemoveProduct'], $json_list_product_list_admin, 'HTML');
} elseif ($user['step'] == "remove-product") {
    if (!in_array($text, $name_product)) {
        sendmessage($from_id, $textbotlang['users']['sell']['error-product'], null, 'HTML');
        return;
    }
    $ydf = '/all';
    $stmt = $pdo->prepare("DELETE FROM product WHERE name_product = ? AND (Location = ? OR Location = ?)");
    $stmt->execute([$text, $user['Processing_value'], $ydf]);
    sendmessage($from_id, $textbotlang['Admin']['Product']['RemoveedProduct'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['titlebtnedit']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['Rmove_location'], $json_list_marzban_panel, 'HTML');
    step('selectlocedite', $from_id);
} elseif ($user['step'] == "selectlocedite") {
    update("user", "Processing_value_one", $text, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Product']['selectEditProduct'], $json_list_product_list_admin, 'HTML');
    step('change_filde', $from_id);
} elseif ($user['step'] == "change_filde") {
    if (!in_array($text, $name_product)) {
        sendmessage($from_id, $textbotlang['users']['sell']['error-product'], null, 'HTML');
        return;
    }
    update("user", "Processing_value", $text, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Product']['selectfieldProduct'], $change_product, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['editprice']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['sendnewprice'], $backadmin, 'HTML');
    step('change_price', $from_id);
} elseif ($user['step'] == "change_price") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['InvalidPrice'], $backadmin, 'HTML');
        return;
    }
    $location = '/all';
    $stmtFirst = $pdo->prepare("UPDATE product SET price_product = ? WHERE name_product = ? AND (Location = ? OR Location = ?)");
    $stmtFirst->execute([$text, $user['Processing_value'], $user['Processing_value_one'], $location]);
    $stmtSecond = $pdo->prepare("UPDATE invoice SET price_product = ? WHERE name_product = ? AND Service_location = ?");
    $stmtSecond->execute([$text, $user['Processing_value'], $user['Processing_value_one']]);
    sendmessage($from_id, $textbotlang['Admin']['Product']['updatedprice'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['editcategory']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['sendnewcategory'], KeyboardCategory(), 'HTML');
    step('change_category', $from_id);
} elseif ($user['step'] == "change_category") {
    $category = select("category", "*", "remark", $text, "select");
    if ($category == false) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['invalidcategory'], $backadmin, 'HTML');
        return;
    }
    $location = "/all";
    $stmtFirst = $pdo->prepare("UPDATE product SET category = ? WHERE name_product = ? AND (Location = ? OR Location = ?)");
    $stmtFirst->execute([$category['id'], $user['Processing_value'], $user['Processing_value_one'], $location]);
    sendmessage($from_id, $textbotlang['Admin']['Product']['updatedcategory'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['editname']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['sendnewname'], $backadmin, 'HTML');
    step('change_name', $from_id);
} elseif ($user['step'] == "change_name") {
    $value = "/all";
    $stmtFirst = $pdo->prepare("UPDATE product SET name_product = ? WHERE name_product = ? AND (Location = ? OR Location = ?)");
    $stmtFirst->execute([$text, $user['Processing_value'], $user['Processing_value_one'], $value]);
    $sqlSecond = "UPDATE invoice SET name_product = ? WHERE name_product = ? AND Service_location = ?";
    $stmtSecond = $pdo->prepare($sqlSecond);
    $stmtSecond->execute([$text, $user['Processing_value'], $user['Processing_value_one']]);
    sendmessage($from_id, $textbotlang['Admin']['Product']['updatedname'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['editvolume']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['sendnewvolume'], $backadmin, 'HTML');
    step('change_val', $from_id);
} elseif ($user['step'] == "change_val") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['Invalidvolume'], $backadmin, 'HTML');
        return;
    }
    $sqlInvoice = "UPDATE invoice SET Volume = ? WHERE name_product = ? AND Service_location = ?";
    $stmtInvoice = $pdo->prepare($sqlInvoice);
    $stmtInvoice->execute([$text, $user['Processing_value'], $user['Processing_value_one']]);
    $sqlProduct = "UPDATE product SET Volume_constraint = ? WHERE name_product = ? AND Location = ?";
    $stmtProduct = $pdo->prepare($sqlProduct);
    $stmtProduct->execute([$text, $user['Processing_value'], $user['Processing_value_one']]);
    sendmessage($from_id, $textbotlang['Admin']['Product']['updatedvolume'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Product']['edittime']) {
    sendmessage($from_id, $textbotlang['Admin']['Product']['NewTime'], $backadmin, 'HTML');
    step('change_time', $from_id);
} elseif ($user['step'] == "change_time") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['InvalidTime'], $backadmin, 'HTML');
        return;
    }
    $stmtInvoice = $pdo->prepare("UPDATE invoice SET Service_time = ? WHERE name_product = ? AND Service_location = ?");
    $stmtInvoice->bindParam(1, $text);
    $stmtInvoice->bindParam(2, $user['Processing_value']);
    $stmtInvoice->bindParam(3, $user['Processing_value_one']);
    $stmtInvoice->execute();
    $stmtProduct = $pdo->prepare("UPDATE product SET Service_time = ? WHERE name_product = ? AND Location = ?");
    $stmtProduct->bindParam(1, $text);
    $stmtProduct->bindParam(2, $user['Processing_value']);
    $stmtProduct->bindParam(3, $user['Processing_value_one']);
    $stmtProduct->execute();
    sendmessage($from_id, $textbotlang['Admin']['Product']['TimeUpdated'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Usertest']['settimeusertest']) {
    sendmessage($from_id, sprintf($textbotlang['Admin']['Usertest']['sendtimeusertest'], $setting['time_usertest']), $backadmin, 'HTML');
    step('updatetime', $from_id);
} elseif ($user['step'] == "updatetime") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['InvalidTime'], $backadmin, 'HTML');
        return;
    }
    update("setting", "time_usertest", $text);
    sendmessage($from_id, $textbotlang['Admin']['Usertest']['TimeUpdated'], $keyboard_usertest, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Usertest']['setvolumeusertest']) {
    sendmessage($from_id, sprintf($textbotlang['Admin']['Usertest']['sendvoluemusertest'], $setting['val_usertest']), $backadmin, 'HTML');
    step('val_usertest', $from_id);
} elseif ($user['step'] == "val_usertest") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Product']['Invalidvolume'], $backadmin, 'HTML');
        return;
    }
    update("setting", "val_usertest", $text);
    sendmessage($from_id, $textbotlang['Admin']['Usertest']['VolumeUpdated'], $keyboard_usertest, 'HTML');
    step('home', $from_id);
}
#-------------------------#
elseif (preg_match('/addbalanceuser_(\w+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $iduser = $dataget[1];
    update("user", "Processing_value", $iduser, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Balance']['PriceBalance'], $backadmin, 'HTML');
    step('get_price_add', $from_id);
} elseif ($user['step'] == "get_price_add") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    if (intval($text) > 100000000) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['maxpricebalance'], $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Balance']['AddBalanceUser'], $User_Services, 'HTML');
    $Balance_user = select("user", "*", "id", $user['Processing_value'], "select");
    $Balance_add_user = $Balance_user['Balance'] + $text;
    update("user", "Balance", $Balance_add_user, "id", $user['Processing_value']);
    $text = number_format($text);
    sendmessage($user['Processing_value'], sprintf($textbotlang['Admin']['Balance']['AddedBalance'], $text), null, 'HTML');
    step('home', $from_id);
}
#-------------------------#
elseif (preg_match('/lowbalanceuser_(\w+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $iduser = $dataget[1];
    update("user", "Processing_value", $iduser, "id", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['Balance']['PriceBalancek'], $backadmin, 'HTML');
    step('get_price_Negative', $from_id);
} elseif ($user['step'] == "get_price_Negative") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    if (intval($text) > 100000000) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['maxpricebalance'], $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Balance']['NegativeBalanceUser'], $User_Services, 'HTML');
    $Balance_user = select("user", "*", "id", $user['Processing_value'], "select");
    $Balance_Low_user = $Balance_user['Balance'] - $text;
    update("user", "Balance", $Balance_Low_user, "id", $user['Processing_value']);
    $text = number_format($text);
    sendmessage($user['Processing_value'], sprintf($textbotlang['Admin']['Balance']['ReduceBalance'], $text), null, 'HTML');
    step('home', $from_id);
}
#----------[ شارژ/کسر حساب با یوزرنیم یا آیدی - فقط super ]----------#
if ($text == '💳 شارژ/کسر حساب کاربر') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, "💳 <b>شارژ / کسر حساب کاربر</b>\n\nآیدی عددی یا @یوزرنیم کاربر را ارسال کن:", $backadmin, 'HTML');
    step('wallet_find_user', $from_id);
} elseif ($user['step'] == 'wallet_find_user') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $search = trim($text);
    $found_uid = null;
    if (strpos($search, '@') === 0) {
        $uname = ltrim($search, '@');
        $r = $pdo->prepare("SELECT id FROM user WHERE username = ? LIMIT 1");
        $r->execute([$uname]);
        $row = $r->fetch(PDO::FETCH_ASSOC);
        if ($row) $found_uid = $row['id'];
    } elseif (is_numeric($search)) {
        $r = $pdo->prepare("SELECT id FROM user WHERE id = ? LIMIT 1");
        $r->execute([$search]);
        $row = $r->fetch(PDO::FETCH_ASSOC);
        if ($row) $found_uid = $row['id'];
    }
    if (!$found_uid) {
        sendmessage($from_id, "❌ کاربری با این مشخصات پیدا نشد.", $backadmin, 'HTML'); return;
    }
    $wu = select("user", "*", "id", $found_uid, "select");
    $wbal = number_format($wu['Balance']);
    update("user", "Processing_value", json_encode(['wallet_uid' => $found_uid]), "id", $from_id);
    $wallet_kb = json_encode(['inline_keyboard' => [
        [['text' => '➕ شارژ کیف پول', 'callback_data' => "wallet_add_{$found_uid}"], ['text' => '➖ کسر از کیف پول', 'callback_data' => "wallet_sub_{$found_uid}"]],
        [['text' => '🔙 انصراف', 'callback_data' => 'wallet_cancel']],
    ]]);
    sendmessage($from_id, "👤 کاربر: @{$wu['username']} (<code>{$found_uid}</code>)\n💰 موجودی فعلی: <b>{$wbal} تومان</b>\n\nعملیات را انتخاب کن:", $wallet_kb, 'HTML');
    step('home', $from_id);
}
elseif (preg_match('/wallet_add_(\d+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    update("user", "Processing_value", json_encode(['wallet_op' => 'add', 'wallet_uid' => $dataget[1]]), "id", $from_id);
    sendmessage($from_id, "➕ مبلغ شارژ (تومان) را وارد کن:", $backadmin, 'HTML');
    step('wallet_do_op', $from_id);
}
elseif (preg_match('/wallet_sub_(\d+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    update("user", "Processing_value", json_encode(['wallet_op' => 'sub', 'wallet_uid' => $dataget[1]]), "id", $from_id);
    sendmessage($from_id, "➖ مبلغ کسر (تومان) را وارد کن:", $backadmin, 'HTML');
    step('wallet_do_op', $from_id);
}
elseif ($datain == 'wallet_cancel') {
    sendmessage($from_id, "❌ عملیات لغو شد.", $mykeyboard, 'HTML');
    step('home', $from_id);
}
elseif ($user['step'] == 'wallet_do_op') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    if (!ctype_digit($text) || intval($text) <= 0) {
        sendmessage($from_id, "❌ مبلغ باید عدد صحیح مثبت باشه.", $backadmin, 'HTML'); return;
    }
    $wd = json_decode($user['Processing_value'], true);
    $wop = $wd['wallet_op']; $wuid = $wd['wallet_uid'];
    $wu  = select("user", "*", "id", $wuid, "select");
    if ($wop == 'add') {
        $new_bal = $wu['Balance'] + intval($text);
        update("user", "Balance", $new_bal, "id", $wuid);
        sendmessage($from_id, "✅ ".number_format($text)." تومان به حساب @{$wu['username']} اضافه شد.\n💰 موجودی جدید: ".number_format($new_bal)." تومان", $User_Services, 'HTML');
        sendmessage($wuid, "✅ ".number_format($text)." تومان به کیف پول شما اضافه شد.\n💰 موجودی جدید: ".number_format($new_bal)." تومان", null, 'HTML');
    } else {
        if (intval($text) > $wu['Balance']) {
            sendmessage($from_id, "❌ موجودی کاربر کافی نیست (موجودی فعلی: ".number_format($wu['Balance'])." تومان)", $backadmin, 'HTML'); return;
        }
        $new_bal = $wu['Balance'] - intval($text);
        update("user", "Balance", $new_bal, "id", $wuid);
        sendmessage($from_id, "✅ ".number_format($text)." تومان از حساب @{$wu['username']} کسر شد.\n💰 موجودی جدید: ".number_format($new_bal)." تومان", $User_Services, 'HTML');
        sendmessage($wuid, "⚠️ ".number_format($text)." تومان از کیف پول شما کسر شد.\n💰 موجودی جدید: ".number_format($new_bal)." تومان", null, 'HTML');
    }
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Discount']['titlebtn']) {
    sendmessage($from_id, $textbotlang['Admin']['Discount']['GetCode'], $backadmin, 'HTML');
    step('get_code', $from_id);
} elseif ($user['step'] == "get_code") {
    if (!preg_match('/^[A-Za-z]+$/', $text)) {
        sendmessage($from_id, $textbotlang['Admin']['Discount']['ErrorCode'], null, 'HTML');
        return;
    }
    $stmt = $pdo->prepare("INSERT INTO Discount (code) VALUES (?)");
    $stmt->bindParam(1, $text);
    $stmt->execute();

    sendmessage($from_id, $textbotlang['Admin']['Discount']['PriceCode'], null, 'HTML');
    step('get_price_code', $from_id);
    update("user", "Processing_value", $text, "id", $from_id);
} elseif ($user['step'] == "get_price_code") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    update("Discount", "price", $text, "code", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Discount']['SaveCode'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['managepanel']['sublinkstatus']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['sublink'] == null) {
        update("marzban_panel", "sublink", "onsublink", "name_panel", $user['Processing_value']);
    }
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $sublinkkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['sublink'], 'callback_data' => $panel['sublink']],
            ],
        ]
    ]);
    if ($panel['configManual'] == "onconfig") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['checkoffconfig'], null, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Status']['subTitle'], $sublinkkeyboard, 'HTML');
}
if ($datain == "onsublink") {
    update("marzban_panel", "sublink", "offsublink", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $sublinkkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['sublink'], 'callback_data' => $panel['sublink']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['subStatusOff'], $sublinkkeyboard);

} elseif ($datain == "offsublink") {
    update("marzban_panel", "sublink", "onsublink", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $sublinkkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['sublink'], 'callback_data' => $panel['sublink']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['subStatuson'], $sublinkkeyboard);
}
#-------------------------#
if ($text == $textbotlang['Admin']['managepanel']['configstatus']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['configManual'] == null) {
        update("marzban_panel", "configManual", "offconfig", "name_panel", $user['Processing_value']);
    }
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $configkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['configManual'], 'callback_data' => $panel['configManual']],
            ],
        ]
    ]);
    if ($panel['sublink'] == "onsublink") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['notoffsublink'], null, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Status']['configTitle'], $configkeyboard, 'HTML');
}
if ($datain == "onconfig") {
    update("marzban_panel", "configManual", "offconfig", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $configkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['configManual'], 'callback_data' => $panel['configManual']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['configStatusOff'], $configkeyboard);
} elseif ($datain == "offconfig") {
    update("marzban_panel", "configManual", "onconfig", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $configkeyboard = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['configManual'], 'callback_data' => $panel['configManual']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['configStatuson'], $configkeyboard);
}
#----------------[  view order user  ]------------------#
elseif (preg_match('/vieworderall_(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    $OrderUsers = select("invoice", "*", "id_user", $iduser, "fetchAll");
    $super_id = $pdo->query("SELECT id_admin FROM admin WHERE role='super' LIMIT 1")->fetchColumn();
    foreach ($OrderUsers as $OrderUser) {
        // کانفیگ‌هایی که با ID ادمین اصلی ساخته شده از دید seller مخفی باشه
        if (!is_super_admin($from_id) && $OrderUser['id_user'] == $super_id) continue;
        $timeacc = jdate('Y/m/d H:i:s', $OrderUser['time_sell']);
        sendmessage($from_id, sprintf($textbotlang['Admin']['ManageUser']['Datails'], $OrderUser['id_invoice'], $OrderUser['Status'], $OrderUser['id_user'], $OrderUser['username'], $OrderUser['Service_location'], $OrderUser['name_product'], $OrderUser['price_product'], $OrderUser['Volume'], $OrderUser['Service_time'], $timeacc), null, 'HTML');
    }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['SendOrder'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
#----------------[  MANAGE CONFIGS   ]------------------#
elseif (preg_match('/manage_configs_(\d+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    $configs = $pdo->prepare("SELECT * FROM invoice WHERE id_user = ? AND (Status='active' OR Status='end_of_time' OR Status='end_of_volume' OR Status='sendedwarn') ORDER BY time_sell DESC");
    $configs->execute([$iduser]);
    $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
    if (empty($configs)) {
        sendmessage($from_id, "⚠️ هیچ کانفیگ فعالی برای این کاربر وجود نداره.", $mykeyboard, 'HTML');
        return;
    }
    $btns = [];
    foreach ($configs as $cfg) {
        $btns[] = [['text' => "📌 {$cfg['username']} | {$cfg['name_product']}", 'callback_data' => "config_action_{$cfg['username']}_{$iduser}"]];
    }
    $btns[] = [['text' => '🔙 بازگشت', 'callback_data' => "vieworderall_{$iduser}"]];
    sendmessage($from_id, "📦 کانفیگ‌های کاربر <code>{$iduser}</code>:\nروی کانفیگ مورد نظر کلیک کن:", json_encode(['inline_keyboard' => $btns]), 'HTML');
}
elseif (preg_match('/config_action_([\w]+)_(\d+)/', $datain, $dataget)) {
    $cfg_username = $dataget[1];
    $iduser       = $dataget[2];
    $cfg_info     = select("invoice", "*", "username", $cfg_username, "select");
    $panel_info   = select("marzban_panel", "*", "name_panel", $cfg_info['Service_location'], "select");
    $DataUserOut  = $ManagePanel->DataUser($cfg_info['Service_location'], $cfg_username);

    $expire_fa    = isset($DataUserOut['expire']) && $DataUserOut['expire'] ? jdate('Y/m/d H:i', $DataUserOut['expire']) : 'نامحدود';
    $used_gb      = isset($DataUserOut['used_traffic']) ? round($DataUserOut['used_traffic'] / 1073741824, 2) : 0;
    $total_gb     = isset($DataUserOut['data_limit']) && $DataUserOut['data_limit'] ? round($DataUserOut['data_limit'] / 1073741824, 2) : 'نامحدود';
    $status_cfg   = $DataUserOut['status'] ?? $cfg_info['Status'];

    if (is_super_admin($from_id)) {
        $action_btns = [
            [
                ['text' => '➕ اضافه حجم', 'callback_data' => "cfg_add_vol_{$cfg_username}_{$iduser}"],
                ['text' => '⏰ اضافه زمان', 'callback_data' => "cfg_add_time_{$cfg_username}_{$iduser}"],
            ],
            [
                ['text' => '✅ فعال‌سازی', 'callback_data' => "cfg_enable_{$cfg_username}_{$iduser}"],
                ['text' => '⛔ غیرفعال‌سازی', 'callback_data' => "cfg_disable_{$cfg_username}_{$iduser}"],
            ],
            [['text' => '🗑 حذف کانفیگ', 'callback_data' => "cfg_delete_{$cfg_username}_{$iduser}"]],
            [['text' => '🔙 بازگشت', 'callback_data' => "manage_configs_{$iduser}"]],
        ];
    } else {
        // seller/support: فقط مشاهده اطلاعات، بدون عملیات
        $action_btns = [
            [['text' => '🔙 بازگشت', 'callback_data' => "manage_configs_{$iduser}"]],
        ];
    }

    $info_text = "📌 <b>کانفیگ: <code>{$cfg_username}</code></b>\n"
               . "📦 حجم: {$used_gb} GB / {$total_gb} GB\n"
               . "📅 انقضا: {$expire_fa}\n"
               . "⚡ وضعیت: {$status_cfg}\n"
               . "🌐 پنل: {$cfg_info['Service_location']}";
    // برای seller/support: لینک سابسکریپشن نشون نده
    // (sub url اصلاً در این view نیست، فقط reminder)
    sendmessage($from_id, $info_text, json_encode(['inline_keyboard' => $action_btns]), 'HTML');
}
// اضافه حجم
elseif (preg_match('/cfg_add_vol_([\w]+)_(\d+)/', $datain, $dataget)) {
    update("user", "Processing_value", json_encode(['cfg_action' => 'add_vol', 'cfg_user' => $dataget[1], 'uid' => $dataget[2]]), "id", $from_id);
    sendmessage($from_id, "➕ چند GB به این کانفیگ اضافه کنم؟ (عدد صحیح وارد کن)", $backadmin, 'HTML');
    step('cfg_do_action', $from_id);
}
// اضافه زمان
elseif (preg_match('/cfg_add_time_([\w]+)_(\d+)/', $datain, $dataget)) {
    update("user", "Processing_value", json_encode(['cfg_action' => 'add_time', 'cfg_user' => $dataget[1], 'uid' => $dataget[2]]), "id", $from_id);
    sendmessage($from_id, "⏰ چند روز به زمان این کانفیگ اضافه کنم؟ (عدد صحیح وارد کن)", $backadmin, 'HTML');
    step('cfg_do_action', $from_id);
}
// فعال‌سازی
elseif (preg_match('/cfg_enable_([\w]+)_(\d+)/', $datain, $dataget)) {
    $cfg_u  = $dataget[1]; $uid = $dataget[2];
    $ci     = select("invoice", "*", "username", $cfg_u, "select");
    $ManagePanel->Enableuser($ci['Service_location'], $cfg_u);
    sendmessage($from_id, "✅ کانفیگ <code>{$cfg_u}</code> فعال شد.", null, 'HTML');
    sendmessage($uid, "✅ کانفیگ شما فعال شد.", null, 'HTML');
}
// غیرفعال‌سازی
elseif (preg_match('/cfg_disable_([\w]+)_(\d+)/', $datain, $dataget)) {
    $cfg_u  = $dataget[1]; $uid = $dataget[2];
    $ci     = select("invoice", "*", "username", $cfg_u, "select");
    $ManagePanel->Disableuser($ci['Service_location'], $cfg_u);
    sendmessage($from_id, "⛔ کانفیگ <code>{$cfg_u}</code> غیرفعال شد.", null, 'HTML');
    sendmessage($uid, "⚠️ کانفیگ شما توسط ادمین غیرفعال شد.", null, 'HTML');
}
// حذف (فقط super)
elseif (preg_match('/cfg_delete_([\w]+)_(\d+)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ فقط ادمین اصلی می‌تونه حذف کنه.", $mykeyboard, 'HTML'); return; }
    $cfg_u  = $dataget[1]; $uid = $dataget[2];
    $ci     = select("invoice", "*", "username", $cfg_u, "select");
    $du     = $ManagePanel->DataUser($ci['Service_location'], $cfg_u);
    if (isset($du['status'])) { $ManagePanel->RemoveUser($ci['Service_location'], $cfg_u); }
    $pdo->prepare("DELETE FROM invoice WHERE username = ?")->execute([$cfg_u]);
    sendmessage($from_id, "🗑 کانفیگ <code>{$cfg_u}</code> حذف شد.", null, 'HTML');
    sendmessage($uid, "❌ یکی از کانفیگ‌های شما توسط ادمین حذف شد.", null, 'HTML');
}
// اجرای action حجم/زمان
elseif ($user['step'] == 'cfg_do_action') {
    if (!ctype_digit($text) || intval($text) <= 0) {
        sendmessage($from_id, "❌ عدد صحیح مثبت وارد کن.", $backadmin, 'HTML'); return;
    }
    $d   = json_decode($user['Processing_value'], true);
    $act = $d['cfg_action']; $cfg_u = $d['cfg_user']; $uid = $d['uid'];
    $ci  = select("invoice", "*", "username", $cfg_u, "select");
    $du  = $ManagePanel->DataUser($ci['Service_location'], $cfg_u);
    $datam = [];
    if ($act == 'add_vol') {
        $add_bytes = intval($text) * 1073741824;
        $new_limit = ($du['data_limit'] ?? 0) + $add_bytes;
        $datam['data_limit'] = $new_limit;
        update("invoice", "Volume", round($new_limit/1073741824), "username", $cfg_u);
        $ManagePanel->Modifyuser($cfg_u, $ci['Service_location'], $datam);
        sendmessage($from_id, "✅ {$text} GB به کانفیگ <code>{$cfg_u}</code> اضافه شد.", $mykeyboard, 'HTML');
        sendmessage($uid, "✅ {$text} GB به کانفیگ شما اضافه شد.", null, 'HTML');
    } elseif ($act == 'add_time') {
        $cur_expire = $du['expire'] ?? time();
        $new_expire = max($cur_expire, time()) + (intval($text) * 86400);
        $datam['expire'] = $new_expire;
        update("invoice", "Service_time", intval($ci['Service_time']) + intval($text), "username", $cfg_u);
        $ManagePanel->Modifyuser($cfg_u, $ci['Service_location'], $datam);
        sendmessage($from_id, "✅ {$text} روز به کانفیگ <code>{$cfg_u}</code> اضافه شد.", $mykeyboard, 'HTML');
        sendmessage($uid, "✅ {$text} روز به اشتراک شما اضافه شد.", null, 'HTML');
    }
    step('home', $from_id);
}
#----------------[  remove Discount   ]------------------#
if ($text == $textbotlang['Admin']['Discount']['titlebtnremove']) {
    sendmessage($from_id, $textbotlang['Admin']['Discount']['RemoveCode'], $json_list_Discount_list_admin, 'HTML');
    step('remove-Discount', $from_id);
} elseif ($user['step'] == "remove-Discount") {
    if (!in_array($text, $code_Discount)) {
        sendmessage($from_id, $textbotlang['Admin']['Discount']['NotCode'], null, 'HTML');
        return;
    }
    $stmt = $pdo->prepare("DELETE FROM Discount WHERE code = ?");
    $stmt->bindParam(1, $text);
    $stmt->execute();
    sendmessage($from_id, $textbotlang['Admin']['Discount']['RemovedCode'], $shopkeyboard, 'HTML');
}
if ($text == $textbotlang['Admin']['ManageUser']['removeorderbtn']) {
    if (!$is_super) { sendmessage($from_id, "⛔ فقط ادمین اصلی می‌تونه سرویس حذف کنه.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['RemoveService'], $backadmin, 'HTML');
    step('removeservice', $from_id);
} elseif ($user['step'] == "removeservice") {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ فقط ادمین اصلی می‌تونه کانفیگ حذف کنه.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $info_product = select("invoice", "*", "username", $text, "select");
    // کانفیگ‌های ادمین اصلی قابل حذف توسط دیگران نیست
    $super_id = $pdo->query("SELECT id_admin FROM admin WHERE role='super' LIMIT 1")->fetchColumn();
    if ($info_product && $info_product['id_user'] == $super_id && !is_super_admin($from_id)) {
        sendmessage($from_id, "⛔ این کانفیگ متعلق به ادمین اصلیه.", $mykeyboard, 'HTML'); step('home', $from_id); return;
    }
    $marzban_list_get = select("marzban_panel", "*", "name_panel", $info_product['Service_location'], "select");
    $DataUserOut = $ManagePanel->DataUser($marzban_list_get['name_panel'], $text);
    if (isset($DataUserOut['status'])) {
        $ManagePanel->RemoveUser($marzban_list_get['name_panel'], $text);
    }
    $stmt = $pdo->prepare("DELETE FROM invoice WHERE username = ?");
    $stmt->bindParam(1, $text);
    $stmt->execute();
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['RemovedService'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['managepanel']['methodusername']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['decmthodusername'], $MethodUsername, 'HTML');
    step('updatemethodusername', $from_id);
} elseif ($user['step'] == "updatemethodusername") {
    update("marzban_panel", "MethodUsername", $text, "name_panel", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['AlgortimeUsername']['SaveData'], $mykeyboard, 'HTML');
    if ($text == $textbotlang['users']['customtextandrandom']) {
        step('getnamecustom', $from_id);
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['customnamesend'], $backuser, 'HTML');
        return;
    }
    step('home', $from_id);
} elseif ($user['step'] == "getnamecustom") {
    if (!preg_match('/^\w{3,32}$/', $text)) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['invalidname'], $backadmin, 'html');
        return;
    }
    update("setting", "namecustome", $text);
    step('home', $from_id);
    $listpanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    update("user", "Processing_value", $text, "id", $from_id);
    outtypepanel($listpanel['type'], $textbotlang['Admin']['managepanel']['savedname']);
}
#----------------[  MANAGE PAYMENT   ]------------------#

if ($text == $textbotlang['Admin']['keyboardadmin']['finance']) {
    if (!$is_support) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $sqlstatus_cart = select("PaySetting", "ValuePay", "NamePay", "Cartstatus", "select")['ValuePay'];
    $sqlstatus_nowpayment = select("PaySetting", "ValuePay", "NamePay", "nowpaymentstatus", "select")['ValuePay'];
    $sqlstatus_iranpay = select("PaySetting", "ValuePay", "NamePay", "digistatus", "select")['ValuePay'];
    $sqlstatus_aqayepardakht = select("PaySetting", "ValuePay", "NamePay", "statusaqayepardakht", "select")['ValuePay'];
    $sqlstatus_zarinpal = select("PaySetting", "ValuePay", "NamePay", "statuszarinpal", "select")['ValuePay'];
    $status_cart = ['oncard' => $textbotlang['Admin']['turnon'], 'offcard' => $textbotlang['Admin']['turnoff']][$sqlstatus_cart];
    $status_nowpayment = ['onnowpayment' => $textbotlang['Admin']['turnon'], 'offnowpayment' => $textbotlang['Admin']['turnoff']][$sqlstatus_nowpayment];
    $status_iranpay = ['ondigi' => $textbotlang['Admin']['turnon'], 'offdigi' => $textbotlang['Admin']['turnoff']][$sqlstatus_iranpay];
    $status_qayepardakht = ['onaqayepardakht' => $textbotlang['Admin']['turnon'], 'offaqayepardakht' => $textbotlang['Admin']['turnoff']][$sqlstatus_aqayepardakht];
    $status_zarinpal = ['onzarinpal' => $textbotlang['Admin']['turnon'], 'offzarinpal' => $textbotlang['Admin']['turnoff']][$sqlstatus_zarinpal];

    if ($is_super) {
        // ادمین اصلی — همه دکمه‌ها شامل تنظیمات
        $keyboardmoeny = json_encode(['inline_keyboard' => [
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "settingcart"],
                ['text' => $status_cart, 'callback_data' => "editpay-cart-" . $sqlstatus_cart],
                ['text' => $textbotlang['users']['moeny']['cart_to_Cart_btn'], 'callback_data' => "none"],
            ],
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "SettingnowPayment"],
                ['text' => $status_nowpayment, 'callback_data' => "editpay-nowpayment-" . $sqlstatus_nowpayment],
                ['text' => $textbotlang['users']['moeny']['nowpayment_gateway_status'], 'callback_data' => "none"],
            ],
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "Settingaqayepardakht"],
                ['text' => $status_qayepardakht, 'callback_data' => "editpay-aqayepardakht-" . $sqlstatus_aqayepardakht],
                ['text' => $textbotlang['users']['moeny']['mr_payment_gateway'], 'callback_data' => "none"],
            ],
            [
                ['text' => '⚙️ تنظیم', 'callback_data' => "Settingzarinpal"],
                ['text' => $status_zarinpal, 'callback_data' => "editpay-zarinpal-" . $sqlstatus_zarinpal],
                ['text' => '💳 زرین‌پال', 'callback_data' => "none"],
            ],
            [
                ['text' => $status_iranpay, 'callback_data' => "editpay-iranpay-" . $sqlstatus_iranpay],
                ['text' => $textbotlang['users']['moeny']['currency_rial_gateway'], 'callback_data' => "none"],
            ],
        ]]);
    } else {
        // seller — فقط وضعیت، بدون دکمه تنظیمات
        $keyboardmoeny = json_encode(['inline_keyboard' => [
            [['text' => $status_cart, 'callback_data' => "none"], ['text' => $textbotlang['users']['moeny']['cart_to_Cart_btn'], 'callback_data' => "none"]],
            [['text' => $status_nowpayment, 'callback_data' => "none"], ['text' => $textbotlang['users']['moeny']['nowpayment_gateway_status'], 'callback_data' => "none"]],
            [['text' => $status_qayepardakht, 'callback_data' => "none"], ['text' => $textbotlang['users']['moeny']['mr_payment_gateway'], 'callback_data' => "none"]],
            [['text' => $status_zarinpal, 'callback_data' => "none"], ['text' => '💳 زرین‌پال', 'callback_data' => "none"]],
            [['text' => $status_iranpay, 'callback_data' => "none"], ['text' => $textbotlang['users']['moeny']['currency_rial_gateway'], 'callback_data' => "none"]],
        ]]);
    }
    sendmessage($from_id, $textbotlang['users']['moeny']['settingpay'], $keyboardmoeny, 'HTML');
} elseif (preg_match('/^editpay-(.*)-(.*)/', $datain, $dataget)) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $methodpay = $dataget[1];
    $status = $dataget[2];
    if ($methodpay == "cart") {
        if ($status == "oncard") {
            $value = "offcard";
        } else {
            $value = "oncard";
        }
        update("PaySetting", "ValuePay", $value, "NamePay", "Cartstatus");
    } elseif ($methodpay == "nowpayment") {
        if ($status == "onnowpayment") {
            $value = "offnowpayment";
        } else {
            $value = "onnowpayment";
        }
        update("PaySetting", "ValuePay", $value, "NamePay", "nowpaymentstatus");
    } elseif ($methodpay == "iranpay") {
        if ($status == "ondigi") {
            $value = "offdigi";
        } else {
            $value = "ondigi";
        }
        update("PaySetting", "ValuePay", $value, "NamePay", "digistatus");
    } elseif ($methodpay == "aqayepardakht") {
        if ($status == "onaqayepardakht") {
            $value = "offaqayepardakht";
        } else {
            $value = "onaqayepardakht";
        }
        update("PaySetting", "ValuePay", $value, "NamePay", "statusaqayepardakht");
    } elseif ($methodpay == "zarinpal") {
        if ($status == "onzarinpal") {
            $value = "offzarinpal";
        } else {
            $value = "onzarinpal";
        }
        update("PaySetting", "ValuePay", $value, "NamePay", "statuszarinpal");
    }
    $sqlstatus_cart = select("PaySetting", "ValuePay", "NamePay", "Cartstatus", "select")['ValuePay'];
    $sqlstatus_nowpayment = select("PaySetting", "ValuePay", "NamePay", "nowpaymentstatus", "select")['ValuePay'];
    $sqlstatus_iranpay = select("PaySetting", "ValuePay", "NamePay", "digistatus", "select")['ValuePay'];
    $sqlstatus_aqayepardakht = select("PaySetting", "ValuePay", "NamePay", "statusaqayepardakht", "select")['ValuePay'];
    $sqlstatus_zarinpal = select("PaySetting", "ValuePay", "NamePay", "statuszarinpal", "select")['ValuePay'];
    $status_cart = [
        'oncard' => $textbotlang['Admin']['turnon'],
        'offcard' => $textbotlang['Admin']['turnoff'],
    ][$sqlstatus_cart];
    $status_nowpayment = [
        'onnowpayment' => $textbotlang['Admin']['turnon'],
        'offnowpayment' => $textbotlang['Admin']['turnoff'],
    ][$sqlstatus_nowpayment];
    $status_iranpay = [
        'ondigi' => $textbotlang['Admin']['turnon'],
        'offdigi' => $textbotlang['Admin']['turnoff'],
    ][$sqlstatus_iranpay];
    $status_qayepardakht = [
        'onaqayepardakht' => $textbotlang['Admin']['turnon'],
        'offaqayepardakht' => $textbotlang['Admin']['turnoff'],
    ][$sqlstatus_aqayepardakht];
    $status_zarinpal = [
        'onzarinpal' => $textbotlang['Admin']['turnon'],
        'offzarinpal' => $textbotlang['Admin']['turnoff'],
    ][$sqlstatus_zarinpal];
    $keyboardmoeny = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "settingcart"],
                ['text' => $status_cart, 'callback_data' => "editpay-cart-" . $sqlstatus_cart],
                ['text' => $textbotlang['users']['moeny']['cart_to_Cart_btn'], 'callback_data' => "none"],
            ],
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "SettingnowPayment"],
                ['text' => $status_nowpayment, 'callback_data' => "editpay-nowpayment-" . $sqlstatus_nowpayment],
                ['text' => $textbotlang['users']['moeny']['nowpayment_gateway_status'], 'callback_data' => "none"],
            ],
            [
                ['text' => $textbotlang['users']['moeny']['setting'], 'callback_data' => "Settingaqayepardakht"],
                ['text' => $status_qayepardakht, 'callback_data' => "editpay-aqayepardakht-" . $sqlstatus_aqayepardakht],
                ['text' => $textbotlang['users']['moeny']['mr_payment_gateway'], 'callback_data' => "none"],
            ],
            [
                ['text' => '⚙️ تنظیم', 'callback_data' => "Settingzarinpal"],
                ['text' => $status_zarinpal, 'callback_data' => "editpay-zarinpal-" . $sqlstatus_zarinpal],
                ['text' => '💳 زرین‌پال', 'callback_data' => "none"],
            ],
            [
                ['text' => $status_iranpay, 'callback_data' => "editpay-iranpay-" . $sqlstatus_iranpay],
                ['text' => $textbotlang['users']['moeny']['currency_rial_gateway'], 'callback_data' => "none"],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['users']['moeny']['settingpay'], $keyboardmoeny);
} elseif ($datain == "settingcart") {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $CartManage, 'HTML');
}
if ($text == $textbotlang['users']['moeny']['card_number_settings']) {
    $PaySetting = select("PaySetting", "ValuePay", "NamePay", "CartDescription", "select");
    sendmessage($from_id, sprintf($textbotlang['users']['moeny']['sendcart'], $PaySetting['ValuePay']), $backadmin, 'HTML');
    step('changecard', $from_id);
} elseif ($user['step'] == "changecard") {
    sendmessage($from_id, $textbotlang['Admin']['SettingPayment']['Savacard'], $CartManage, 'HTML');
    update("PaySetting", "ValuePay", $text, "NamePay", "CartDescription");
    step('home', $from_id);
}
if ($datain == "SettingnowPayment") {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $NowPaymentsManage, 'HTML');
}
if ($text == $textbotlang['users']['moeny']['nowpayment_api']) {
    $PaySetting = select("PaySetting", "ValuePay", "NamePay", "apinowpayment", "select")['ValuePay'];
    sendmessage($from_id, sprintf($textbotlang['users']['moeny']['getapinowpayment'], $PaySetting), $backadmin, 'HTML');
    step('apinowpayment', $from_id);
} elseif ($user['step'] == "apinowpayment") {
    sendmessage($from_id, $textbotlang['Admin']['SettingnowPayment']['Savaapi'], $NowPaymentsManage, 'HTML');
    update("PaySetting", "ValuePay", $text, "NamePay", "apinowpayment");
    step('home', $from_id);
}
if ($datain == "Settingaqayepardakht") {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $aqayepardakht, 'HTML');
}
if ($text == $textbotlang['users']['moeny']['mr_payment_merchant_settings']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $PaySetting = select("PaySetting", "ValuePay", "NamePay", "merchant_id_aqayepardakht", "select");
    sendmessage($from_id, sprintf($textbotlang['users']['moeny']['getmarchent'], $PaySetting['ValuePay']), $backadmin, 'HTML');
    step('merchant_id_aqayepardakht', $from_id);
} elseif ($user['step'] == "merchant_id_aqayepardakht") {
    sendmessage($from_id, $textbotlang['Admin']['SettingnowPayment']['Savaapi'], $aqayepardakht, 'HTML');
    update("PaySetting", "ValuePay", $text, "NamePay", "merchant_id_aqayepardakht");
    step('home', $from_id);
}
if ($datain == "Settingzarinpal") {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['users']['selectoption'], $zarinpal, 'HTML');
}
if ($text == '🔑 تنظیم مرچنت کد زرین‌پال') {
    $PaySetting = select("PaySetting", "ValuePay", "NamePay", "merchant_id_zarinpal", "select");
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, "🔑 مرچنت کد فعلی زرین‌پال:\n<code>{$PaySetting['ValuePay']}</code>\n\nمرچنت کد جدید را ارسال کنید:", $backadmin, 'HTML');
    step('merchant_id_zarinpal', $from_id);
} elseif ($user['step'] == "merchant_id_zarinpal") {
    update("PaySetting", "ValuePay", $text, "NamePay", "merchant_id_zarinpal");
    sendmessage($from_id, "✅ مرچنت کد زرین‌پال ذخیره شد.", $zarinpal, 'HTML');
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['keyboardadmin']['manage_panel']) {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['getloc'], $json_list_marzban_panel, 'HTML');
    step('GetLocationEdit', $from_id);
} elseif ($user['step'] == "GetLocationEdit") {
    $listpanel = select("marzban_panel", "*", "name_panel", $text, "select");
    update("user", "Processing_value", $text, "id", $from_id);
    outtypepanel($listpanel['type'], $textbotlang['users']['selectoption']);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['namepanel']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['GetNameNew'], $backadmin, 'HTML');
    step('GetNameNew', $from_id);
} elseif ($user['step'] == "GetNameNew") {
    $typepanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    outtypepanel($typepanel['type'], $textbotlang['Admin']['managepanel']['ChangedNmaePanel']);
    update("marzban_panel", "name_panel", $text, "name_panel", $user['Processing_value']);
    update("invoice", "Service_location", $text, "Service_location", $user['Processing_value']);
    update("product", "Location", $text, "Location", $user['Processing_value']);
    update("reseller_bot", "panel_name", $text, "panel_name", $user['Processing_value']);
    update("reseller_bot_plan", "panel_name", $text, "panel_name", $user['Processing_value']);
    update("user", "Processing_value", $text, "id", $from_id);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['editurl']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['geturlnew'], $backadmin, 'HTML');
    step('GeturlNew', $from_id);
} elseif ($user['step'] == "GeturlNew") {
    if (!filter_var($text, FILTER_VALIDATE_URL)) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['Invalid-domain'], $backadmin, 'HTML');
        return;
    }
    $typepanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    outtypepanel($typepanel['type'], $textbotlang['Admin']['managepanel']['ChangedurlPanel']);
    update("marzban_panel", "url_panel", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['editusername']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['getusernamenew'], $backadmin, 'HTML');
    step('GetusernameNew', $from_id);
} elseif ($user['step'] == "GetusernameNew") {
    $typepanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    outtypepanel($typepanel['type'], $textbotlang['Admin']['managepanel']['ChangedusernamePanel']);
    update("marzban_panel", "username_panel", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['editpassword']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['getpasswordnew'], $backadmin, 'HTML');
    step('GetpaawordNew', $from_id);
} elseif ($user['step'] == "GetpaawordNew") {
    $typepanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    outtypepanel($typepanel['type'], $textbotlang['Admin']['managepanel']['ChangedpasswordPanel']);
    update("marzban_panel", "password_panel", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['editinound'] || $text == $textbotlang['Admin']['managepanel']['setgroup']) {
    if ($text == $textbotlang['Admin']['managepanel']['setgroup']) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['keyboardpanel']['getgroup'], $backadmin, 'HTML');
    } else {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['keyboardpanel']['getidinbound'], $backadmin, 'HTML');
    }
    step('getinboundiid', $from_id);
} elseif ($user['step'] == "getinboundiid") {
    $typepanel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    outtypepanel($typepanel['type'], $textbotlang['Admin']['managepanel']['keyboardpanel']['setinbound']);
    update("marzban_panel", "inboundid", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['linksub']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['geturlnew'], $backadmin, 'HTML');
    step('GeturlNewx', $from_id);
} elseif ($user['step'] == "GeturlNewx") {
    if (!filter_var($text, FILTER_VALIDATE_URL)) {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['Invalid-domain'], $backadmin, 'HTML');
        return;
    }
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['type'] == "x-ui_single") {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $text);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode != 200) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['subinvalidDomain'], null, 'HTML');
            return;
        }
        if (curl_error($ch)) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['subinvalidDomain'], null, 'HTML');
            return;
        }
        $protocol = ['vmess', 'vless', 'trojan', 'ss'];
        if (isBase64($response)) {
            $response = base64_decode($response);
        }
        $sub_check = explode('://', $response)[0];
        if (!in_array($sub_check, $protocol)) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['subinvalid'], null, 'HTML');
            return;
        }
        $text = dirname($text);
    }
    outtypepanel($panel['type'], $textbotlang['Admin']['managepanel']['ChangedurlPanel']);
    update("marzban_panel", "linksubx", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
} elseif ($user['step'] == "GetpaawordNew") {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['ChangedpasswordPanel'], $optionMarzban, 'HTML');
    update("marzban_panel", "password_panel", $text, "name_panel", $user['Processing_value']);
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['removepanel']) {
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['RemovedPanel'], $mykeyboard, 'HTML');
    $stmt = $pdo->prepare("DELETE FROM marzban_panel WHERE name_panel = ?");
    $stmt->bindParam(1, $user['Processing_value']);
    $stmt->execute();
}
if ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['setvolume']) {
    sendmessage($from_id, $textbotlang['users']['Extra_volume']['SetPrice'] . $setting['Extra_volume'], $backadmin, 'HTML');
    step('GetPriceExtra', $from_id);
} elseif ($user['step'] == "GetPriceExtra") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    update("setting", "Extra_volume", $text);
    sendmessage($from_id, $textbotlang['users']['Extra_volume']['ChangedPrice'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
#-------------------------#
if ($text == $textbotlang['Admin']['Balance']['SendBalanceAll']) {
    if (!$is_super) { sendmessage($from_id, "⛔ فقط ادمین اصلی می‌تونه شارژ همگانی بده.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['Admin']['Balance']['addallbalance'], $backadmin, 'HTML');
    step('add_Balance_all', $from_id);
} elseif ($user['step'] == "add_Balance_all") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['Balance']['AddBalanceUsers'], $User_Services, 'HTML');
    $stmt = $pdo->prepare("UPDATE user SET Balance = Balance + :balance");
    $stmt->bindParam(':balance', $text, PDO::PARAM_INT);
    $stmt->execute();
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['Discountsell']['create']) {
    sendmessage($from_id, $textbotlang['Admin']['Discountsell']['GetCode'], $backadmin, 'HTML');
    step('get_codesell', $from_id);
} elseif ($user['step'] == "get_codesell") {
    if (in_array($text, $SellDiscount)) {
        sendmessage($from_id, $textbotlang['Admin']['Discount']['Discountused'], $backadmin, 'HTML');
        return;
    }
    if (!preg_match('/^[A-Za-z\d]+$/', $text)) {
        sendmessage($from_id, $textbotlang['Admin']['Discount']['ErrorCode'], null, 'HTML');
        return;
    }
    $values = "0";
    $stmt = $pdo->prepare("INSERT INTO DiscountSell (codeDiscount, usedDiscount, price, limitDiscount, usefirst) VALUES (?, ?, ?, ?,?)");
    $stmt->bindParam(1, $text);
    $stmt->bindParam(2, $values);
    $stmt->bindParam(3, $values);
    $stmt->bindParam(4, $values);
    $stmt->bindParam(5, $values);
    $stmt->execute();

    sendmessage($from_id, $textbotlang['Admin']['Discount']['PriceCodesell'], null, 'HTML');
    step('get_price_codesell', $from_id);
    update("user", "Processing_value", $text, "id", $from_id);
} elseif ($user['step'] == "get_price_codesell") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['Balance']['Invalidprice'], $backadmin, 'HTML');
        return;
    }
    update("DiscountSell", "price", $text, "codeDiscount", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Discountsell']['getlimit'], $backadmin, 'HTML');
    step('getlimitcode', $from_id);
} elseif ($user['step'] == "getlimitcode") {
    update("DiscountSell", "limitDiscount", $text, "codeDiscount", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Discount']['typediscount'], $backadmin, 'HTML');
    step('getusefirst', $from_id);
} elseif ($user['step'] == "getusefirst") {
    update("DiscountSell", "usefirst", $text, "codeDiscount", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Discount']['SaveCode'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['Discountsell']['remove']) {
    sendmessage($from_id, $textbotlang['Admin']['Discount']['RemoveCode'], $json_list_Discount_list_admin_sell, 'HTML');
    step('remove-Discountsell', $from_id);
} elseif ($user['step'] == "remove-Discountsell") {
    if (!in_array($text, $SellDiscount)) {
        sendmessage($from_id, $textbotlang['Admin']['Discount']['NotCode'], null, 'HTML');
        return;
    }
    $stmt = $pdo->prepare("DELETE FROM DiscountSell WHERE codeDiscount = ?");
    $stmt->bindParam(1, $text);
    $stmt->execute();
    sendmessage($from_id, $textbotlang['Admin']['Discount']['RemovedCode'], $shopkeyboard, 'HTML');
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['keyboardadmin']['affiliate_settings']) {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $affiliates, 'HTML');
} elseif ($text == $textbotlang['Admin']['affiliate']['status']) {
    $affiliatesvalue = select("affiliates", "*", null, null, "select")['affiliatesstatus'];
    $keyboardaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $affiliatesvalue, 'callback_data' => $affiliatesvalue],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['Status']['affiliates'], $keyboardaffiliates, 'HTML');
} elseif ($datain == "onaffiliates") {
    update("affiliates", "affiliatesstatus", "offaffiliates");
    $affiliatesvalue = select("affiliates", "*", null, null, "select")['affiliatesstatus'];
    $keyboardaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $affiliatesvalue, 'callback_data' => $affiliatesvalue],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['affiliatesStatusOff'], $keyboardaffiliates);
} elseif ($datain == "offaffiliates") {
    update("affiliates", "affiliatesstatus", "onaffiliates");
    $affiliatesvalue = select("affiliates", "*", null, null, "select")['affiliatesstatus'];
    $keyboardaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $affiliatesvalue, 'callback_data' => $affiliatesvalue],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['affiliatesStatuson'], $keyboardaffiliates);
}
if ($text == $textbotlang['Admin']['affiliate']['Percentageset']) {
    sendmessage($from_id, $textbotlang['users']['affiliates']['setpercentage'], $backadmin, 'HTML');
    step('setpercentage', $from_id);
} elseif ($user['step'] == "setpercentage") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['invalidvalue'], null, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['users']['affiliates']['changedpercentage'], $affiliates, 'HTML');
    update("affiliates", "affiliatespercentage", $text);
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['affiliate']['setbaner']) {
    sendmessage($from_id, $textbotlang['users']['affiliates']['banner'], $backadmin, 'HTML');
    step('setbanner', $from_id);
} elseif ($user['step'] == "setbanner") {
    if (!$photo) {
        sendmessage($from_id, $textbotlang['users']['affiliates']['invalidbanner'], $backadmin, 'HTML');
        return;
    }
    update("affiliates", "description", $caption);
    update("affiliates", "id_media", $photoid);
    sendmessage($from_id, $textbotlang['users']['affiliates']['insertbanner'], $affiliates, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['affiliate']['porsantafterbuy']) {
    $marzbancommission = select("affiliates", "*", null, null, "select");
    $keyboardcommission = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbancommission['status_commission'], 'callback_data' => $marzbancommission['status_commission']],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['Status']['commission'], $keyboardcommission, 'HTML');
} elseif ($datain == "oncommission") {
    update("affiliates", "status_commission", "offcommission");
    $marzbancommission = select("affiliates", "*", null, null, "select");
    $keyboardcommission = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbancommission['status_commission'], 'callback_data' => $marzbancommission['status_commission']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['commissionStatusOff'], $keyboardcommission);
} elseif ($datain == "offcommission") {
    update("affiliates", "status_commission", "oncommission");
    $marzbancommission = select("affiliates", "*", null, null, "select");
    $keyboardcommission = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbancommission['status_commission'], 'callback_data' => $marzbancommission['status_commission']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['commissionStatuson'], $keyboardcommission);
} elseif ($text == $textbotlang['Admin']['affiliate']['gift']) {
    $marzbanDiscountaffiliates = select("affiliates", "*", null, null, "select");
    $keyboardDiscountaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbanDiscountaffiliates['Discount'], 'callback_data' => $marzbanDiscountaffiliates['Discount']],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['Status']['Discountaffiliates'], $keyboardDiscountaffiliates, 'HTML');
} elseif ($datain == "onDiscountaffiliates") {
    update("affiliates", "Discount", "offDiscountaffiliates");
    $marzbanDiscountaffiliates = select("affiliates", "*", null, null, "select");
    $keyboardDiscountaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbanDiscountaffiliates['Discount'], 'callback_data' => $marzbanDiscountaffiliates['Discount']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['DiscountaffiliatesStatusOff'], $keyboardDiscountaffiliates);
} elseif ($datain == "offDiscountaffiliates") {
    update("affiliates", "Discount", "onDiscountaffiliates");
    $marzbanDiscountaffiliates = select("affiliates", "*", null, null, "select");
    $keyboardDiscountaffiliates = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $marzbanDiscountaffiliates['Discount'], 'callback_data' => $marzbanDiscountaffiliates['Discount']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['DiscountaffiliatesStatuson'], $keyboardDiscountaffiliates);
}
if ($text == $textbotlang['Admin']['affiliate']['giftstart']) {
    sendmessage($from_id, $textbotlang['users']['affiliates']['priceDiscount'], $backadmin, 'HTML');
    step('getdiscont', $from_id);
} elseif ($user['step'] == "getdiscont") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['invalidvalue'], null, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['users']['affiliates']['changedpriceDiscount'], $affiliates, 'HTML');
    update("affiliates", "price_Discount", $text);
    step('home', $from_id);
} elseif (preg_match('/rejectremoceserviceadmin-(\w+)/', $datain, $dataget)) {
    $usernamepanel = $dataget[1];
    $requestcheck = select("cancel_service", "*", "username", $usernamepanel, "select");
    if ($requestcheck['status'] == "accept" || $requestcheck['status'] == "reject") {
        telegram(
            'answerCallbackQuery',
            array(
                'callback_query_id' => $callback_query_id,
                'text' => $textbotlang['users']['status']['residaccepted'],
                'show_alert' => true,
                'cache_time' => 5,
            )
        );
        return;
    }
    step("descriptionsrequsts", $from_id);
    update("user", "Processing_value", $usernamepanel, "id", $from_id);
    sendmessage($from_id, $textbotlang['users']['status']['rejectrequest'], $backuser, 'HTML');

} elseif ($user['step'] == "descriptionsrequsts") {
    sendmessage($from_id, $textbotlang['users']['status']['acceptrequestnote'], $mykeyboard, 'HTML');
    $nameloc = select("invoice", "*", "username", $user['Processing_value'], "select");
    update("cancel_service", "status", "reject", "username", $user['Processing_value']);
    update("cancel_service", "description", $text, "username", $user['Processing_value']);
    step("home", $from_id);
    sendmessage($nameloc['id_user'], sprintf($textbotlang['users']['status']['rejectsendtouser'], $user['Processing_value'], $text), null, 'HTML');

} elseif (preg_match('/remoceserviceadmin-(\w+)/', $datain, $dataget)) {
    $username = $dataget[1];
    $requestcheck = select("cancel_service", "*", "username", $username, "select");
    if ($requestcheck['status'] == "accept" || $requestcheck['status'] == "reject") {
        telegram(
            'answerCallbackQuery',
            array(
                'callback_query_id' => $callback_query_id,
                'text' => $textbotlang['users']['status']['residaccepted'],
                'show_alert' => true,
                'cache_time' => 5,
            )
        );
        return;
    }
    step("getpricerequests", $from_id);
    update("user", "Processing_value", $username, "id", $from_id);
    sendmessage($from_id, $textbotlang['users']['status']['getpriceforadd'], $backuser, 'HTML');

} elseif ($user['step'] == "getpricerequests") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['invalidvalue'], null, 'HTML');
    }
    $nameloc = select("invoice", "*", "username", $user['Processing_value'], "select");
    if ($nameloc['price_product'] < $text) {
        sendmessage($from_id, $textbotlang['Admin']['maxvalue'], $backuser, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['users']['status']['acceptrequestnote'], $mykeyboard, 'HTML');
    step("home", $from_id);
    $marzban_list_get = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM marzban_panel WHERE name_panel = '{$nameloc['Service_location']}'"));
    $DataUserOut = $ManagePanel->DataUser($marzban_list_get['name_panel'], $user['Processing_value']);
    if (isset($DataUserOut['status'])) {
        $ManagePanel->RemoveUser($marzban_list_get['name_panel'], $user['Processing_value']);
    }
    update("cancel_service", "status", "accept", "username", $user['Processing_value']);
    update("invoice", "status", "removedbyadmin", "username", $user['Processing_value']);
    step("home", $from_id);
    sendmessage($nameloc['id_user'], sprintf($textbotlang['users']['status']['acceptrequest'], $user['Processing_value']), null, 'HTML');
    $pricecancel = number_format(intval($text));
    if (intval($text) != 0) {
        $Balance_id_cancel = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM user WHERE id = '{$nameloc['id_user']}' LIMIT 1"));
        $Balance_id_cancel_fee = intval($Balance_id_cancel['Balance']) + intval($text);
        update("user", "Balance", $Balance_id_cancel_fee, "id", $nameloc['id_user']);
        sendmessage($nameloc['id_user'], sprintf($textbotlang['users']['status']['addedbalanceremove'], $pricecancel), null, 'HTML');
    }
    if (isset($setting['Channel_Report']) && strlen($setting['Channel_Report']) > 0) {
        sendmessage($setting['Channel_Report'], sprintf($textbotlang['Admin']['Report']['reportremove'], $from_id, $pricecancel, $username, $nameloc['id_user']), null, 'HTML');
    }
}
if ($text == $textbotlang['Admin']['managepanel']['keyboardpanel']['on_hold_status']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['onholdstatus'] == null) {
        update("marzban_panel", "onholdstatus", "offonhold", "name_panel", $user['Processing_value']);
    }
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $onhold_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['onholdstatus'], 'callback_data' => $panel['onholdstatus']],
            ],
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['Status']['onhold'], $onhold_Status, 'HTML');
}
if ($datain == "ononhold") {
    update("marzban_panel", "onholdstatus", "offonhold", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $onhold_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['onholdstatus'], 'callback_data' => $panel['onholdstatus']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['offstatus'], $onhold_Status);
} elseif ($datain == "offonhold") {
    update("marzban_panel", "onholdstatus", "ononhold", "name_panel", $user['Processing_value']);
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    $onhold_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $panel['onholdstatus'], 'callback_data' => $panel['onholdstatus']],
            ],
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['onstatus'], $onhold_Status);
}
if ($text == $textbotlang['Admin']['keyboardadmin']['settingscron']) {
    if (!(function_exists('shell_exec') && is_callable('shell_exec'))) {
        $crontest = "*/15 * * * * curl https://$domainhosts/cron/configtest.php";
        $cronvolume = "*/1 * * * *  curl https://$domainhosts/cron/cronvolume.php";
        $crontime = "*/1 * * * *  curl https://$domainhosts/cron/cronday.php";
        $cronremove = "*/1 * * * *  curl https://$domainhosts/cron/removeexpire.php";
        sendmessage($from_id, sprintf($textbotlang['Admin']['cron']['active_manual'], $crontest, $cronvolume, $crontime, $cronremove), null, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['users']['selectoption'], $keyboardcronjob, 'HTML');
}
if ($text == $textbotlang['Admin']['cron']['test']['active']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['test']['dec'], null, 'HTML');
    $phpFilePath = escapeshellarg("https://$domainhosts/cron/configtest.php");
    $cronCommand = "*/15 * * * * curl $phpFilePath";
    $existingCronCommands = shell_exec('crontab -l');
    if (strpos($existingCronCommands, $cronCommand) === false) {
        $command = "(crontab -l ; echo '$cronCommand') | crontab -";
        shell_exec($command);
    }
}
if ($text == $textbotlang['Admin']['cron']['test']['disable']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['test']['disabled'], null, 'HTML');
    $currentCronJobs = shell_exec("crontab -l");
    $url = escapeshellarg("https://$domainhosts/cron/configtest.php");
    $jobToRemove = "*/15 * * * * curl $url";
    $newCronJobs = preg_replace('/' . preg_quote($jobToRemove, '/') . '/', '', $currentCronJobs);
    file_put_contents('/tmp/crontab.txt', $newCronJobs);
    shell_exec('crontab /tmp/crontab.txt');
    unlink('/tmp/crontab.txt');
}
if ($text == $textbotlang['Admin']['cron']['volume']['active']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['volume']['dec'], null, 'HTML');
    $phpFilePath = escapeshellarg("https://$domainhosts/cron/cronvolume.php");
    $cronCommand = "*/1 * * * * curl $phpFilePath";
    $existingCronCommands = shell_exec('crontab -l');
    if (strpos($existingCronCommands, $cronCommand) === false) {
        $command = "(crontab -l ; echo '$cronCommand') | crontab -";
        shell_exec($command);
    }
}
if ($text == $textbotlang['Admin']['cron']['volume']['disable']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['test']['disabled'], null, 'HTML');
    $currentCronJobs = shell_exec("crontab -l");
    $jobToRemove = "*/1 * * * * curl https://$domainhosts/cron/cronvolume.php";
    $newCronJobs = preg_replace('/' . preg_quote($jobToRemove, '/') . '/', '', $currentCronJobs);
    file_put_contents('/tmp/crontab.txt', $newCronJobs);
    shell_exec('crontab /tmp/crontab.txt');
    unlink('/tmp/crontab.txt');
}
if ($text == $textbotlang['Admin']['cron']['time']['active']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['time']['dec'], null, 'HTML');
    $phpFilePath = escapeshellarg("https://$domainhosts/cron/cronday.php");
    $cronCommand = "*/1 * * * * curl $phpFilePath";
    $existingCronCommands = shell_exec('crontab -l');
    if (strpos($existingCronCommands, $cronCommand) === false) {
        $command = "(crontab -l ; echo '$cronCommand') | crontab -";
        shell_exec($command);
    }
}
if ($text == $textbotlang['Admin']['cron']['time']['disable']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['test']['disabled'], null, 'HTML');
    $currentCronJobs = shell_exec("crontab -l");
    $jobToRemove = "*/1 * * * * curl https://$domainhosts/cron/cronday.php";
    $newCronJobs = preg_replace('/' . preg_quote($jobToRemove, '/') . '/', '', $currentCronJobs);
    file_put_contents('/tmp/crontab.txt', $newCronJobs);
    shell_exec('crontab /tmp/crontab.txt');
    unlink('/tmp/crontab.txt');
}
if ($text == $textbotlang['Admin']['cron']['remove']['active']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['remove']['dec'], null, 'HTML');
    $phpFilePath = "https://$domainhosts/cron/removeexpire.php";
    $cronCommand = "*/1 * * * * curl $phpFilePath";
    $existingCronCommands = shell_exec('crontab -l');
    if (strpos($existingCronCommands, $cronCommand) === false) {
        $command = "(crontab -l ; echo '$cronCommand') | crontab -";
        shell_exec($command);
    }
}
if ($text == $textbotlang['Admin']['cron']['remove']['disable']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['test']['disabled'], null, 'HTML');
    $currentCronJobs = shell_exec("crontab -l");
    $jobToRemove = "*/1 * * * * curl https://$domainhosts/cron/removeexpire.php";
    $newCronJobs = preg_replace('/' . preg_quote($jobToRemove, '/') . '/', '', $currentCronJobs);
    file_put_contents('/tmp/crontab.txt', $newCronJobs);
    shell_exec('crontab /tmp/crontab.txt');
    unlink('/tmp/crontab.txt');
}
if ($text == $textbotlang['Admin']['keyboardadmin']['user_search']) {
    if (get_admin_role($from_id) === 'support') { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['BlockUserId'], $backadmin, 'HTML');
    step('show_infos', $from_id);
} elseif ($user['step'] == "show_infos") {
    $search = trim($text);
    $user_id = null;

    if (strpos($search, '@') === 0) {
        // جستجو با @username تلگرام
        $uname = ltrim($search, '@');
        $stmt_u = $pdo->prepare("SELECT id FROM user WHERE username = ? LIMIT 1");
        $stmt_u->execute([$uname]);
        $found = $stmt_u->fetch(PDO::FETCH_ASSOC);
        if ($found) $user_id = $found['id'];
    } elseif (is_numeric($search)) {
        $user_id = $search;
    }

    if (!$user_id || !in_array($user_id, $users_ids)) {
        sendmessage($from_id, $textbotlang['Admin']['not-user'], $backadmin, 'HTML');
        return;
    }
    // ادمین‌های غیر super نمی‌تونن آیدی ادمین اصلی رو سرچ کنن
    if (!is_super_admin($from_id)) {
        $super_id_check = $pdo->query("SELECT id_admin FROM admin WHERE role='super' LIMIT 1")->fetchColumn();
        if ($user_id == $super_id_check) {
            sendmessage($from_id, "⛔ دسترسی به اطلاعات ادمین اصلی مجاز نیست.", $backadmin, 'HTML');
            return;
        }
    }
    $text = $user_id;
    $date = date("Y-m-d");
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM invoice WHERE (status = 'active' OR status = 'end_of_time'  OR status = 'end_of_volume' OR status = 'sendedwarn') AND id_user = :id_user");
    $stmt->bindParam(':id_user', $text);
    $stmt->execute();
    $dayListSell = $stmt->rowCount();
    $stmt = $pdo->prepare("SELECT SUM(price) FROM Payment_report WHERE payment_Status = 'paid' AND id_user = :id_user");
    $stmt->bindParam(':id_user', $text);
    $stmt->execute();
    $balanceall = $stmt->fetch(PDO::FETCH_ASSOC)['SUM(price)'];
    $stmt = $pdo->prepare("SELECT SUM(price_product) FROM invoice WHERE (status = 'active' OR status = 'end_of_time'  OR status = 'end_of_volume' OR status = 'sendedwarn') AND id_user = :id_user");
    $stmt->bindParam(':id_user', $text);
    $stmt->execute();
    $subbuyuser = $stmt->fetch(PDO::FETCH_ASSOC)['SUM(price_product)'];
    $user = select("user", "*", "id", $text, "select");
    $roll_Status = [
        '1' => $textbotlang['Admin']['ManageUser']['Acceptedphone'],
        '0' => $textbotlang['Admin']['ManageUser']['Failedphone'],
    ][$user['roll_Status']];
    if ($subbuyuser == null)
        $subbuyuser = 0;
    if (is_super_admin($from_id)) {
        // super: همه دسترسی‌ها
        $keyboardmanage = [
            'inline_keyboard' => [
                [['text' => $textbotlang['Admin']['ManageUser']['addbalanceuser'], 'callback_data' => "addbalanceuser_" . $text], ['text' => $textbotlang['Admin']['ManageUser']['lowbalanceuser'], 'callback_data' => "lowbalanceuser_" . $text]],
                [['text' => $textbotlang['Admin']['ManageUser']['banuserlist'], 'callback_data' => "banuserlist_" . $text], ['text' => $textbotlang['Admin']['ManageUser']['unbanuserlist'], 'callback_data' => "unbanuserr_" . $text]],
                [['text' => $textbotlang['Admin']['ManageUser']['confirmnumber'], 'callback_data' => "confirmnumber_" . $text]],
                [['text' => $textbotlang['Admin']['getlimitusertest']['setlimitbtn'], 'callback_data' => "limitusertest_" . $text]],
                [['text' => $textbotlang['Admin']['ManageUser']['verify'], 'callback_data' => "verify_" . $text], ['text' => $textbotlang['Admin']['ManageUser']['removeverify'], 'callback_data' => "verifyun_" . $text]],
                [['text' => $textbotlang['Admin']['ManageUser']['vieworderuser'], 'callback_data' => "vieworderall_" . $text], ['text' => $textbotlang['Admin']['ManageUser']['addorder'], 'callback_data' => "addordermanualـ" . $text]],
                [['text' => '📦 مدیریت کانفیگ‌های کاربر', 'callback_data' => "manage_configs_" . $text]],
            ]
        ];
    } else {
        // seller/support: فقط مشاهده سفارشات
        $keyboardmanage = [
            'inline_keyboard' => [
                [['text' => $textbotlang['Admin']['ManageUser']['vieworderuser'], 'callback_data' => "vieworderall_" . $text]],
            ]
        ];
    }
    $keyboardmanage = json_encode($keyboardmanage);
    $user['Balance'] = number_format($user['Balance']);
    $lastmessage = jdate('Y/m/d H:i:s', $user['last_message_time']);
    sendmessage($from_id, sprintf($textbotlang['Admin']['ManageUser']['infouser'], $user['User_Status'], $user['username'], $text, $text, $lastmessage, $user['limit_usertest'], $roll_Status, $user['number'], $user['Balance'], $dayListSell, $balanceall, $subbuyuser, $user['affiliatescount'], $user['affiliates'], $user['verify']), $keyboardmanage, 'HTML');
    sendmessage($from_id, $textbotlang['users']['selectoption'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
if ($text == $textbotlang['Admin']['cron']['remove']['timeset']) {
    sendmessage($from_id, $textbotlang['Admin']['cron']['remove']['dectime'], $backadmin, 'HTML');
    step("gettimeremove", $from_id);
} elseif ($user['step'] == "gettimeremove") {
    if (!ctype_digit($text)) {
        sendmessage($from_id, $textbotlang['Admin']['cron']['remove']['invalidtime'], $backadmin, 'HTML');
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['cron']['remove']['timeseted'], $keyboardcronjob, 'HTML');
    step("home", $from_id);
    update("setting", "removedayc", $text, null, null);
}
if ($text == $textbotlang['users']['status']['manageService']) {
    sendmessage($from_id, $textbotlang['users']['status']['manageServicedec'], $backadmin, 'HTML');
    step('getservceid', $from_id);
} elseif ($user['step'] == "getservceid") {
    $userdata = getuserm($text, $user['Processing_value']);
    if (isset($userdata['detail']) and $userdata['detail'] == "User not found") {
        sendmessage($from_id, $textbotlang['Admin']['managepanel']['keyboardpanel']['usernotfount'], null, 'HTML');
        return;
    }
    update("marzban_panel", "proxies", json_encode($userdata['service_ids']), "name_panel", $user['Processing_value']);
    step("home", $from_id);
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['setsetting'], $optionMarzneshin, 'HTML');
} elseif ($text == $textbotlang['Admin']['Help']['edithelp']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['selecthelpforedit'], $json_list_help, 'HTML');
    step("getnameforedite", $from_id);
} elseif ($user['step'] == "getnameforedite") {
    sendmessage($from_id, $textbotlang['users']['selectoption'], $helpedit, 'HTML');
    update("user", "Processing_value", $text, "id", $from_id);
    step("home", $from_id);

} elseif ($text == $textbotlang['Admin']['Help']['change']['name']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['sendnewname'], $backadmin, 'HTML');
    step('changenamehelp', $from_id);
} elseif ($user['step'] == "changenamehelp") {
    if (strlen($text) >= 150) {
        sendmessage($from_id, $textbotlang['Admin']['Help']['change']['namemax'], null, 'HTML');
        return;
    }
    update("help", "name_os", $text, "name_os", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['updated'], $json_list_helpkey, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['Help']['change']['dec']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['newdec'], $backadmin, 'HTML');
    step('changedeshelp', $from_id);
} elseif ($user['step'] == "changedeshelp") {
    update("help", "Description_os", $text, "name_os", $user['Processing_value']);
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['updated'], $helpedit, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['Help']['change']['editmedia']) {
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['editmedianew'], $backadmin, 'HTML');
    step('changemedia', $from_id);
} elseif ($user['step'] == "changemedia") {
    if ($photo) {
        if (isset($photoid))
            update("help", "Media_os", $photoid, "name_os", $user['Processing_value']);
        update("help", "type_Media_os", "photo", "name_os", $user['Processing_value']);
    } elseif ($video) {
        if (isset($videoid))
            update("help", "Media_os", $videoid, "name_os", $user['Processing_value']);
        update("help", "type_Media_os", "video", "name_os", $user['Processing_value']);
    }
    sendmessage($from_id, $textbotlang['Admin']['Help']['change']['updated'], $helpedit, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['managepanel']['setinbound']) {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['type'] == "remnawave") {
        // برای remnawave اسکوادها رو از API بگیر و نشون بده
        $squads = get_squads_remna($panel['name_panel']);
        if (isset($squads['error']) || !isset($squads['internalSquads'])) {
            sendmessage($from_id, "❌ خطا در دریافت اسکوادها: " . json_encode($squads), $backadmin, 'HTML');
            return;
        }
        // ذخیره لیست اسکوادها در Processing_value
        $current_data = json_decode($user['Processing_value_extra'] ?? '{}', true) ?: [];
        $squad_list = [];
        foreach ($squads['internalSquads'] as $sq) {
            $squad_list[] = ['uuid' => $sq['uuid'], 'name' => $sq['name']];
        }
        savedata("save", "remna_squads", json_encode($squad_list));
        savedata("save", "remna_panel_name", $panel['name_panel']); // ذخیره name_panel
        // ساخت کیبورد اسکوادها
        $buttons = [];
        foreach ($squads['internalSquads'] as $sq) {
            $inbound_names = implode(', ', array_column($sq['inbounds'], 'tag'));
            $buttons[] = [['text' => "🔵 " . $sq['name'] . " (" . count($sq['inbounds']) . " inbound)", 'callback_data' => "remna_squad_main%" . $sq['uuid']]];
        }
        $buttons[] = [['text' => $textbotlang['Admin']['Back-Adminment'], 'callback_data' => "back_admin"]];
        $squad_keyboard = json_encode(['inline_keyboard' => $buttons]);
        sendmessage($from_id, "🔵 <b>اسکواد اصلی (خرید)</b> رو انتخاب کن:\n\nکاربران خریدار به این اسکواد وصل میشن", $squad_keyboard, 'HTML');
        step("remna_select_main_squad", $from_id);
        return;
    }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['setinbounddec'], $backadmin, 'HTML');
    step("setinboundandprotocol", $from_id);
} elseif (preg_match('/remna_squad_main%(.*)/', $datain, $dataget) && $user['step'] == "remna_select_main_squad") {
    $main_squad_uuid = $dataget[1];
    savedata("save", "remna_main_squad", $main_squad_uuid);
    deletemessage($from_id, $message_id);
    // حالا اسکواد تست رو بپرس
    $squad_data = json_decode($user['Processing_value'], true);
    $raw_squads = $squad_data['remna_squads'] ?? [];
    $squad_list = is_string($raw_squads) ? json_decode($raw_squads, true) : $raw_squads;
    $squad_list = $squad_list ?: [];
    $buttons = [];
    foreach ($squad_list as $sq) {
        $buttons[] = [['text' => "🟢 " . $sq['name'], 'callback_data' => "remna_squad_test%" . $sq['uuid']]];
    }
    $buttons[] = [['text' => "❌ بدون اسکواد تست (همون خرید)", 'callback_data' => "remna_squad_test%same"]];
    $buttons[] = [['text' => $textbotlang['Admin']['Back-Adminment'], 'callback_data' => "back_admin"]];
    $squad_keyboard = json_encode(['inline_keyboard' => $buttons]);
    sendmessage($from_id, "🟢 <b>اسکواد تست</b> رو انتخاب کن:\n\nکاربران اکانت تست به این اسکواد وصل میشن", $squad_keyboard, 'HTML');
    step("remna_select_test_squad", $from_id);

} elseif (preg_match('/remna_squad_test%(.*)/', $datain, $dataget) && $user['step'] == "remna_select_test_squad") {
    $test_squad_uuid = $dataget[1];
    deletemessage($from_id, $message_id);
    $squad_data = json_decode($user['Processing_value'], true);
    $main_squad_uuid = $squad_data['remna_main_squad'] ?? '';
    // خوندن name_panel از داده‌های ذخیره‌شده
    $panel_name = $squad_data['remna_panel_name'] ?? '';
    $panel = select("marzban_panel", "*", "name_panel", $panel_name, "select");
    // inboundid فعلی رو parse کن
    $current_inboundid = $panel['inboundid'] ?? '0';
    $parts = explode('|', $current_inboundid);
    $caddy_auth = $parts[0]; // caddy:pass یا 0
    // فرمت جدید: caddy_auth|main_squad_uuid|test_squad_uuid
    $test_val = ($test_squad_uuid === 'same') ? $main_squad_uuid : $test_squad_uuid;
    $new_inboundid = $caddy_auth . '|' . $main_squad_uuid . '|' . $test_val;
    update("marzban_panel", "inboundid", $new_inboundid, "name_panel", $panel['name_panel']);
    // نمایش خلاصه
    $raw_squads2 = $squad_data['remna_squads'] ?? [];
    $squad_list = is_string($raw_squads2) ? json_decode($raw_squads2, true) : $raw_squads2;
    $squad_list = $squad_list ?: [];
    $main_name = $main_squad_uuid;
    $test_name = $test_val;
    foreach ($squad_list as $sq) {
        if ($sq['uuid'] === $main_squad_uuid) $main_name = $sq['name'];
        if ($sq['uuid'] === $test_val) $test_name = $sq['name'];
    }
    sendmessage($from_id, "✅ تنظیمات اسکواد ذخیره شد:\n\n🔵 خرید: <b>$main_name</b>\n🟢 تست: <b>$test_name</b>", $optionRemnawave, 'HTML');
    step("home", $from_id);

} elseif ($user['step'] == "setinboundandprotocol") {
    $panel = select("marzban_panel", "*", "name_panel", $user['Processing_value'], "select");
    if ($panel['type'] == "marzban") {
        $DataUserOut = getuser($text, $user['Processing_value']);
        if ((isset($DataUserOut['msg']) && $DataUserOut['msg'] == "User not found") or !isset($DataUserOut['proxies'])) {
            sendmessage($from_id, $textbotlang['users']['status']['usernotfound'], null, 'html');
            return;
        }
        foreach ($DataUserOut['proxies'] as $key => &$value) {
            if ($key == "shadowsocks") {
                unset($DataUserOut['proxies'][$key]['password']);
            } elseif ($key == "trojan") {
                unset($DataUserOut['proxies'][$key]['password']);
            } else {
                unset($DataUserOut['proxies'][$key]['id']);
            }
            if (count($DataUserOut['proxies'][$key]) == 0) {
                $DataUserOut['proxies'][$key] = new stdClass();
            }
        }
        update("marzban_panel", "inbounds", json_encode($DataUserOut['inbounds']), "name_panel", $user['Processing_value']);
        update("marzban_panel", "proxies", json_encode($DataUserOut['proxies']), "name_panel", $user['Processing_value']);
    } else {
        $data = GetClientsS_UI($text, $panel['name_panel']);
        if (count($data) == 0) {
            sendmessage($from_id, $textbotlang['Admin']['managepanel']['keyboardpanel']['usernotfount'], $options_ui, 'HTML');
            return;
        }
        $servies = [];
        foreach ($data['inbounds'] as $service) {
            $servies[] = $service;
        }
        update("marzban_panel", "proxies", json_encode($servies, true), "name_panel", $user['Processing_value']);
    }
    sendmessage($from_id, $textbotlang['Admin']['managepanel']['setedinbound'], $optionMarzban, 'HTML');
    step("home", $from_id);
} elseif ($text == $textbotlang['Admin']['keyboardadmin']['seetingstatus']) {
    if ($setting['Bot_Status'] == "✅  ربات روشن است") {
        update("setting", "Bot_Status", "1");
    } elseif ($setting['Bot_Status'] == "❌ ربات خاموش است") {
        update("setting", "Bot_Status", "0");
    }

    if ($setting['roll_Status'] == "✅ تایید قانون روشن است") {
        update("setting", "roll_Status", "1");
    } elseif ($setting['roll_Status'] == "❌ تایید قوانین خاموش است") {
        update("setting", "roll_Status", "0");
    }

    if ($setting['NotUser'] == "onnotuser") {
        update("setting", "NotUser", "1");
    } elseif ($setting['NotUser'] == "offnotuser") {
        update("setting", "NotUser", "0");
    }

    if ($setting['help_Status'] == "✅ آموزش فعال است") {
        update("setting", "help_Status", "1");
    } elseif ($setting['help_Status'] == "❌ آموزش غیرفعال است") {
        update("setting", "help_Status", "0");
    }

    if ($setting['get_number'] == "✅ تایید شماره موبایل روشن است") {
        update("setting", "get_number", "1");
    } elseif ($setting['get_number'] == "❌ احرازهویت شماره تماس غیرفعال است") {
        update("setting", "get_number", "0");
    }

    if ($setting['iran_number'] == "✅ احرازشماره ایرانی روشن است") {
        update("setting", "iran_number", "1");
    } elseif ($setting['iran_number'] == "❌ بررسی شماره ایرانی غیرفعال است") {
        update("setting", "iran_number", "0");
    }
    if (!(function_exists('shell_exec') && is_callable('shell_exec'))) {
        $cronstatus = 1;
        $cronCommand = "*/4 * * * * curl https://$domainhosts/cron/croncard.php";
        sendmessage($from_id, sprintf($textbotlang['Admin']['cron']['active_manual_card'], $cronCommand), null, 'HTML');
    } else {
        $cronCommand = "*/4 * * * * curl https://$domainhosts/cron/croncard.php";
        $existingCronCommands = shell_exec('crontab -l');
        if (strpos($existingCronCommands, $cronCommand) === false) {
            $cronstatus = 0;
        } else {
            $cronstatus = 1;
        }
    }
    $setting = select("setting", "*");
    $name_status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['Bot_Status']];
    $roll_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['roll_Status']];
    $NotUser_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['NotUser']];
    $help_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['help_Status']];
    $get_number_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['get_number']];
    $get_number_iran = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['iran_number']];
    $statusv_verify = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['status_verify']];
    $statusv_category = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['statuscategory']];
    $status_Automatic_confirmation = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$cronstatus];
    $status_copy_cart = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['copy_cart']];
    $Bot_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['Admin']['Status']['statussubject'], 'callback_data' => "subjectde"],
                ['text' => $textbotlang['Admin']['Status']['subject'], 'callback_data' => "subject"],
            ],
            [
                ['text' => $name_status, 'callback_data' => "editstsuts-statusbot-{$setting['Bot_Status']}"],
                ['text' => $textbotlang['Admin']['Status']['stautsbot'], 'callback_data' => "statusbot"],
            ],
            [
                ['text' => $roll_Status, 'callback_data' => "editstsuts-roll_Status-{$setting['roll_Status']}"],
                ['text' => $textbotlang['users']['Rulesbtn'], 'callback_data' => "roll_Status"],
            ],
            [
                ['text' => $NotUser_Status, 'callback_data' => "editstsuts-NotUser-{$setting['NotUser']}"],
                ['text' => $textbotlang['users']['maangeuser'], 'callback_data' => "NotUser"],
            ],
            [
                ['text' => $help_Status, 'callback_data' => "editstsuts-help_Status-{$setting['help_Status']}"],
                ['text' => $textbotlang['Admin']['Help']['statushelp'], 'callback_data' => "help_Status"],
            ],
            [
                ['text' => $get_number_Status, 'callback_data' => "editstsuts-get_number-{$setting['get_number']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verifynumber'], 'callback_data' => "get_number"],
            ],
            [
                ['text' => $get_number_iran, 'callback_data' => "editstsuts-iran_number-{$setting['iran_number']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verifynumberirani'], 'callback_data' => "iran_number"],
            ],
            [
                ['text' => $statusv_verify, 'callback_data' => "editstsuts-verify-{$setting['status_verify']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verify'], 'callback_data' => "status_verify"],
            ],
            [
                ['text' => $statusv_category, 'callback_data' => "editstsuts-category-{$setting['statuscategory']}"],
                ['text' => $textbotlang['Admin']['category']['status'], 'callback_data' => "statuscategory"],
            ],
            [
                ['text' => $status_Automatic_confirmation, 'callback_data' => "editstsuts-Automatic_confirmation-$cronstatus"],
                ['text' => $textbotlang['Admin']['Automatic_confirmation']['title'], 'callback_data' => "Automatic_confirmation"],
            ],
            [
                ['text' => $status_copy_cart, 'callback_data' => "editstsuts-copycart-{$setting['copy_cart']}"],
                ['text' => $textbotlang['users']['moeny']['copy_cart_status'], 'callback_data' => "copycart"],
            ]
        ]
    ]);
    sendmessage($from_id, $textbotlang['Admin']['Status']['BotTitle'], $Bot_Status, 'HTML');
} elseif (preg_match('/^editstsuts-(.*)-(.*)/', $datain, $dataget)) {
    $type = $dataget[1];
    $value = $dataget[2];
    if ($type == "statusbot") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "Bot_Status", $valuenew);
    } elseif ($type == "roll_Status") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "roll_Status", $valuenew);
    } elseif ($type == "NotUser") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "NotUser", $valuenew);
    } elseif ($type == "help_Status") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "help_Status", $valuenew);
    } elseif ($type == "get_number") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "get_number", $valuenew);
    } elseif ($type == "iran_number") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "iran_number", $valuenew);
    } elseif ($type == "verify") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "status_verify", $valuenew);
    } elseif ($type == "category") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "statuscategory", $valuenew);
    } elseif ($type == "copycart") {
        if ($value == "1") {
            $valuenew = "0";
        } else {
            $valuenew = "1";
        }
        update("setting", "copy_cart", $valuenew);
    } elseif ($type == "Automatic_confirmation") {
        if (!(function_exists('shell_exec') && is_callable('shell_exec'))) {
            $cronstatus = 1;
            $cronCommand = "*/4 * * * * curl https://$domainhosts/cron/croncard.php";
            sendmessage($from_id, sprintf($textbotlang['Admin']['cron']['active_manual_card'], $cronCommand), null, 'HTML');
        } else {
            if ($value == "1") {
                $currentCronJobs = shell_exec("crontab -l");
                $jobToRemove = "*/4 * * * * curl https://$domainhosts/cron/croncard.php";
                $newCronJobs = preg_replace('/' . preg_quote($jobToRemove, '/') . '/', '', $currentCronJobs);
                file_put_contents('/tmp/crontab.txt', $newCronJobs);
                shell_exec('crontab /tmp/crontab.txt');
                unlink('/tmp/crontab.txt');
            } else {
                $existingCronCommands = shell_exec('crontab -l');
                $phpFilePath = escapeshellarg("https://$domainhosts/cron/croncard.php");
                $cronCommand = "*/4 * * * * curl $phpFilePath";
                if (strpos($existingCronCommands, $cronCommand) === false) {
                    $command = "(crontab -l;  echo '$cronCommand') | crontab -";
                    error_log($command);
                    shell_exec($command);
                }
            }
        }
    }
    $cronCommand = "*/4 * * * * curl https://$domainhosts/cron/croncard.php";
    if (!(function_exists('shell_exec') && is_callable('shell_exec'))) {
        $cronstatus = 1;
    } else {
        $existingCronCommands = shell_exec('crontab -l');
        if (strpos($existingCronCommands, $cronCommand) === false) {
            $cronstatus = 0;
        } else {
            $cronstatus = 1;
        }
    }
    $setting = select("setting", "*");
    $name_status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['Bot_Status']];
    $roll_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['roll_Status']];
    $NotUser_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['NotUser']];
    $help_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['help_Status']];
    $get_number_Status = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['get_number']];
    $get_number_iran = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['iran_number']];
    $statusv_verify = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['status_verify']];
    $statusv_category = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['statuscategory']];
    $status_Automatic_confirmation = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$cronstatus];
    $status_copy_cart = [
        '1' => $textbotlang['Admin']['Status']['statuson'],
        '0' => $textbotlang['Admin']['Status']['statusoff']
    ][$setting['copy_cart']];
    $Bot_Status = json_encode([
        'inline_keyboard' => [
            [
                ['text' => $textbotlang['Admin']['Status']['statussubject'], 'callback_data' => "subjectde"],
                ['text' => $textbotlang['Admin']['Status']['subject'], 'callback_data' => "subject"],
            ],
            [
                ['text' => $name_status, 'callback_data' => "editstsuts-statusbot-{$setting['Bot_Status']}"],
                ['text' => $textbotlang['Admin']['Status']['stautsbot'], 'callback_data' => "statusbot"],
            ],
            [
                ['text' => $roll_Status, 'callback_data' => "editstsuts-roll_Status-{$setting['roll_Status']}"],
                ['text' => $textbotlang['users']['Rulesbtn'], 'callback_data' => "roll_Status"],
            ],
            [
                ['text' => $NotUser_Status, 'callback_data' => "editstsuts-NotUser-{$setting['NotUser']}"],
                ['text' => $textbotlang['users']['maangeuser'], 'callback_data' => "NotUser"],
            ],
            [
                ['text' => $help_Status, 'callback_data' => "editstsuts-help_Status-{$setting['help_Status']}"],
                ['text' => $textbotlang['Admin']['Help']['statushelp'], 'callback_data' => "help_Status"],
            ],
            [
                ['text' => $get_number_Status, 'callback_data' => "editstsuts-get_number-{$setting['get_number']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verifynumber'], 'callback_data' => "get_number"],
            ],
            [
                ['text' => $get_number_iran, 'callback_data' => "editstsuts-iran_number-{$setting['iran_number']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verifynumberirani'], 'callback_data' => "iran_number"],
            ],
            [
                ['text' => $statusv_verify, 'callback_data' => "editstsuts-verify-{$setting['status_verify']}"],
                ['text' => $textbotlang['Admin']['ManageUser']['verify'], 'callback_data' => "status_verify"],
            ],
            [
                ['text' => $statusv_category, 'callback_data' => "editstsuts-category-{$setting['statuscategory']}"],
                ['text' => $textbotlang['Admin']['category']['status'], 'callback_data' => "statuscategory"],
            ],
            [
                ['text' => $status_Automatic_confirmation, 'callback_data' => "editstsuts-Automatic_confirmation-$cronstatus"],
                ['text' => $textbotlang['Admin']['Automatic_confirmation']['title'], 'callback_data' => "Automatic_confirmation"],
            ],
            [
                ['text' => $status_copy_cart, 'callback_data' => "editstsuts-copycart-{$setting['copy_cart']}"],
                ['text' => $textbotlang['users']['moeny']['copy_cart_status'], 'callback_data' => "copycart"],
            ]
        ]
    ]);
    Editmessagetext($from_id, $message_id, $textbotlang['Admin']['Status']['BotTitle'], $Bot_Status);
} elseif (preg_match('/verify_(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    $userunverify = select("user", "*", "id", $iduser, "select");
    if ($userunverify['verify'] == "1") {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['verifyeduser'], $backadmin, 'HTML');
        return;
    }
    update("user", "verify", "1", "id", $iduser);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['verifyeduser'], $mykeyboard, 'HTML');
    step('home', $from_id);
} elseif (preg_match('/verifyun_(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    $userunverify = select("user", "*", "id", $iduser, "select");
    if ($userunblock['verify'] == "0") {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['verifyed'], $backadmin, 'HTML');
        return;
    }
    update("user", "verify", "0", "id", $iduser);
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['unverifyed'], $mykeyboard, 'HTML');
    step('home', $from_id);
} elseif ($text == $textbotlang['Admin']['category']['add']) {
    sendmessage($from_id, $textbotlang['Admin']['category']['getname'], $backadmin, 'HTML');
    step("getremarkcategory", $from_id);
} elseif ($user['step'] == "getremarkcategory") {
    sendmessage($from_id, $textbotlang['Admin']['category']['addedcategry'], $shopkeyboard, 'HTML');
    step("home", $from_id);
    $stmt = $pdo->prepare("INSERT INTO category (remark) VALUES (?)");
    $stmt->bindParam(1, $text);
    $stmt->execute();
} elseif ($text == $textbotlang['Admin']['category']['remove']) {
    sendmessage($from_id, $textbotlang['Admin']['category']['getcatgory'], KeyboardCategory(), 'HTML');
    step("removecategory", $from_id);
} elseif ($user['step'] == "removecategory") {
    sendmessage($from_id, $textbotlang['Admin']['category']['removedcategory'], $shopkeyboard, 'HTML');
    step("home", $from_id);
    $stmt = $pdo->prepare("DELETE FROM category WHERE remark = :remark ");
    $stmt->bindParam(':remark', $text);
    $stmt->execute();
} elseif ($text == $textbotlang['Admin']['ManageUser']['searchorder']) {
    sendmessage($from_id, $textbotlang['Admin']['ManageUser']['ViewOrder'], $backadmin, 'HTML');
    step("getidfororder", $from_id);

// سرچ اشتراک مشتری - مخصوص support (فقط شماره سفارش یا یوزرنیم کانفیگ)
} elseif ($text == '🔍 سرچ اشتراک مشتری') {
    sendmessage($from_id, "🔍 <b>سرچ اشتراک مشتری</b>\n\nشماره سفارش یا یوزرنیم کانفیگ مشتری را ارسال کنید:", $backadmin, 'HTML');
    step('support_search_order', $from_id);

} elseif ($user['step'] == 'support_search_order') {
    $search = trim($text);
    $OrderUser = null;
    // فقط شماره سفارش یا یوزرنیم کانفیگ - آیدی عددی یا @username تلگرام قبول نیست
    if (is_numeric($search) && strlen($search) < 10) {
        // شماره‌های کوتاه احتمالاً شماره سفارش هستن
        $OrderUser = select("invoice", "*", "id_invoice", $search, "select");
    } else {
        $OrderUser = select("invoice", "*", "username", $search, "select");
        if (!$OrderUser) {
            $OrderUser = select("invoice", "*", "id_invoice", $search, "select");
        }
    }

    if (!$OrderUser) {
        sendmessage($from_id, "❌ اشتراکی با این مشخصات پیدا نشد.", $backadmin, 'HTML');
        return;
    }

    // دریافت اطلاعات از پنل
    $panel_data = $ManagePanel->DataUser($OrderUser['Service_location'], $OrderUser['username']);
    $used = isset($panel_data['used_traffic']) ? round($panel_data['used_traffic'] / 1073741824, 2) . " GB" : '—';
    $limit = isset($panel_data['data_limit']) && $panel_data['data_limit'] > 0 ? round($panel_data['data_limit'] / 1073741824, 2) . " GB" : 'نامحدود';
    $expire = isset($panel_data['expire']) && $panel_data['expire'] > 0 ? jdate('Y/m/d', $panel_data['expire']) : 'ندارد';
    $status_map = ['active' => '✅ فعال', 'disabled' => '🔴 غیرفعال', 'expired' => '⏰ منقضی', 'limited' => '⚠️ محدود', 'ACTIVE' => '✅ فعال', 'DISABLED' => '🔴 غیرفعال', 'EXPIRED' => '⏰ منقضی'];
    $status = isset($panel_data['status']) ? ($status_map[$panel_data['status']] ?? $panel_data['status']) : '—';
    $timeacc = jdate('Y/m/d H:i', $OrderUser['time_sell']);

    // اطلاعات محدود بدون sub_url
    $out = "📋 <b>اطلاعات اشتراک</b>\n\n"
         . "📦 <b>شماره سفارش:</b> <code>{$OrderUser['id_invoice']}</code>\n"
         . "👤 <b>یوزرنیم کانفیگ:</b> <code>{$OrderUser['username']}</code>\n"
         . "🛒 <b>محصول:</b> {$OrderUser['name_product']}\n"
         . "🌍 <b>پنل:</b> {$OrderUser['Service_location']}\n"
         . "📅 <b>تاریخ خرید:</b> $timeacc\n\n"
         . "━━━━━━━━━━━━━━\n"
         . "⚡ <b>وضعیت:</b> $status\n"
         . "📶 <b>مصرف:</b> $used از $limit\n"
         . "⏳ <b>انقضا:</b> $expire";

    sendmessage($from_id, $out, $backadmin, 'HTML');
    step('home', $from_id);

} elseif ($text == "📋 لیست اشتراک‌ها") {
    if (get_admin_role($from_id) === 'support') { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $page = 1;
    $per_page = 10;
    $offset = ($page - 1) * $per_page;
    // کانفیگ‌های ادمین اصلی از دید seller مخفیه
    $super_id_val = $pdo->query("SELECT id_admin FROM admin WHERE role='super' LIMIT 1")->fetchColumn();
    $hide_clause = is_super_admin($from_id) ? "" : "AND i.id_user != " . intval($super_id_val);
    $stmt = $pdo->prepare("SELECT i.*, u.username as tg_username FROM invoice i LEFT JOIN user u ON i.id_user = u.id WHERE 1=1 {$hide_clause} ORDER BY i.time_sell DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total = $pdo->query("SELECT COUNT(*) FROM invoice WHERE 1=1 {$hide_clause}")->fetchColumn();
    $total_pages = ceil($total / $per_page);

    $buttons = [];
    foreach ($orders as $order) {
        $tg = $order['tg_username'] ? "@" . $order['tg_username'] : $order['id_user'];
        $buttons[] = [['text' => "👤 " . $order['username'] . " | " . $tg, 'callback_data' => "orderinfo_" . $order['id_invoice']]];
    }
    $nav = [];
    if ($page < $total_pages) $nav[] = ['text' => "بعدی ›", 'callback_data' => "orderlist_page_2"];
    $nav[] = ['text' => "صفحه $page از $total_pages", 'callback_data' => "none"];
    if (!empty($nav)) $buttons[] = $nav;
    $buttons[] = [['text' => "❌ بستن", 'callback_data' => "closelist"]];
    sendmessage($from_id, "📋 <b>لیست اشتراک‌ها</b> (کل: $total)", json_encode(['inline_keyboard' => $buttons]), 'HTML');
    step('home', $from_id);

} elseif (preg_match('/^orderlist_page_(\d+)$/', $datain, $m)) {
    $page = (int)$m[1];
    $per_page = 10;
    $offset = ($page - 1) * $per_page;
    $stmt = $pdo->prepare("SELECT i.*, u.username as tg_username FROM invoice i LEFT JOIN user u ON i.id_user = u.id ORDER BY i.time_sell DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total = $pdo->query("SELECT COUNT(*) FROM invoice")->fetchColumn();
    $total_pages = ceil($total / $per_page);

    $buttons = [];
    foreach ($orders as $order) {
        $tg = $order['tg_username'] ? "@" . $order['tg_username'] : $order['id_user'];
        $buttons[] = [['text' => "👤 " . $order['username'] . " | " . $tg, 'callback_data' => "orderinfo_" . $order['id_invoice']]];
    }
    $nav = [];
    if ($page > 1) $nav[] = ['text' => "‹ قبلی", 'callback_data' => "orderlist_page_" . ($page - 1)];
    $nav[] = ['text' => "صفحه $page از $total_pages", 'callback_data' => "none"];
    if ($page < $total_pages) $nav[] = ['text' => "بعدی ›", 'callback_data' => "orderlist_page_" . ($page + 1)];
    $buttons[] = $nav;
    $buttons[] = [['text' => "❌ بستن", 'callback_data' => "closelist"]];
    Editmessagetext($from_id, $message_id, "📋 <b>لیست اشتراک‌ها</b> (کل: $total)", json_encode(['inline_keyboard' => $buttons]), 'HTML');

} elseif (preg_match('/^orderinfo_([a-z0-9]+)$/', $datain, $m)) {
    $invoice_id = $m[1];
    $stmt = $pdo->prepare("SELECT i.*, u.username as tg_username FROM invoice i LEFT JOIN user u ON i.id_user = u.id WHERE i.id_invoice = :id LIMIT 1");
    $stmt->execute([':id' => $invoice_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$order) { telegram('answerCallbackQuery', ['callback_query_id' => $callback_query_id, 'text' => 'سفارش پیدا نشد']); return; }

    $tg_username = $order['tg_username'] ? "@" . $order['tg_username'] : "ندارد";
    $sell_date = jdate('Y/m/d H:i', $order['time_sell']);

    // دریافت اطلاعات کامل از پنل
    $panel_data = $ManagePanel->DataUser($order['Service_location'], $order['username']);
    $sub_url = isset($panel_data['subscription_url']) ? $panel_data['subscription_url'] : '—';
    $used = isset($panel_data['used_traffic']) ? round($panel_data['used_traffic'] / 1073741824, 2) . " GB" : '—';
    $limit = isset($panel_data['data_limit']) && $panel_data['data_limit'] > 0 ? round($panel_data['data_limit'] / 1073741824, 2) . " GB" : 'نامحدود';
    $expire = isset($panel_data['expire']) && $panel_data['expire'] > 0 ? jdate('Y/m/d', $panel_data['expire']) : 'ندارد';
    $status_map = ['active' => '✅ فعال', 'disabled' => '🔴 غیرفعال', 'expired' => '⏰ منقضی', 'limited' => '⚠️ محدود'];
    $status = isset($panel_data['status']) ? ($status_map[$panel_data['status']] ?? $panel_data['status']) : '—';
    $online = isset($panel_data['online_at']) && $panel_data['online_at'] ? jdate('Y/m/d H:i', strtotime($panel_data['online_at'])) : 'آنلاین نبوده';

    $text_out = "📋 <b>اطلاعات اشتراک</b>\n\n";
    $text_out .= "👤 <b>نام کاربری:</b> <code>{$order['username']}</code>\n";
    $text_out .= "🆔 <b>آیدی تلگرام:</b> <a href='tg://user?id={$order['id_user']}'>{$order['id_user']}</a>\n";
    $text_out .= "📱 <b>یوزرنیم تلگرام:</b> $tg_username\n";
    $text_out .= "📦 <b>شماره سفارش:</b> <code>{$order['id_invoice']}</code>\n";
    $text_out .= "🛒 <b>محصول:</b> {$order['name_product']}\n";
    $text_out .= "🌍 <b>پنل:</b> {$order['Service_location']}\n";
    $text_out .= "💰 <b>قیمت:</b> {$order['price_product']} تومان\n";
    $text_out .= "📅 <b>تاریخ خرید:</b> $sell_date\n\n";
    $text_out .= "━━━━━━━━━━━━━━\n";
    $text_out .= "📊 <b>وضعیت:</b> $status\n";
    $text_out .= "📶 <b>مصرف:</b> $used از $limit\n";
    $text_out .= "⏳ <b>انقضا:</b> $expire\n";
    $text_out .= "🕐 <b>آخرین اتصال:</b> $online\n\n";
    // لینک سابسکریپشن فقط برای super
    if (is_super_admin($from_id)) {
        $text_out .= "🔗 <b>لینک سابسکریپشن:</b>\n<code>$sub_url</code>";
    }

    $inline = json_encode(['inline_keyboard' => [
        [['text' => "🔙 برگشت به لیست", 'callback_data' => "orderlist_page_1"]],
        [['text' => "❌ بستن", 'callback_data' => "closelist"]]
    ]]);
    Editmessagetext($from_id, $message_id, $text_out, $inline, 'HTML');
} elseif ($user['step'] == "getidfororder") {
    $search = trim($text);
    $OrderUser = null;

    if (strpos($search, '@') === 0) {
        // جستجو با @username تلگرام
        $uname = ltrim($search, '@');
        $stmt_s = $pdo->prepare("SELECT i.* FROM invoice i JOIN user u ON i.id_user = u.id WHERE u.username = ? ORDER BY i.time_sell DESC LIMIT 1");
        $stmt_s->execute([$uname]);
        $OrderUser = $stmt_s->fetch(PDO::FETCH_ASSOC);
    } elseif (is_numeric($search)) {
        // جستجو با آیدی عددی تلگرام
        $stmt_s = $pdo->prepare("SELECT * FROM invoice WHERE id_user = ? ORDER BY time_sell DESC LIMIT 1");
        $stmt_s->execute([$search]);
        $OrderUser = $stmt_s->fetch(PDO::FETCH_ASSOC);
    } else {
        // جستجو با username اکانت یا شماره سفارش
        $OrderUser = select("invoice", "*", "username", $search, "select");
        if (!$OrderUser) {
            $OrderUser = select("invoice", "*", "id_invoice", $search, "select");
        }
    }

    if (!$OrderUser) {
        sendmessage($from_id, $textbotlang['Admin']['ManageUser']['OrderNotFound'], null, 'HTML');
        return;
    }
    $timeacc = jdate('Y/m/d H:i:s', $OrderUser['time_sell']);
    sendmessage($from_id, sprintf($textbotlang['Admin']['ManageUser']['Datails'], $OrderUser['id_invoice'], $OrderUser['Status'], $OrderUser['id_user'], $OrderUser['username'], $OrderUser['Service_location'], $OrderUser['name_product'], $OrderUser['price_product'], $OrderUser['Volume'], $OrderUser['Service_time'], $timeacc), $User_Services, 'HTML');
    step('home', $from_id);
} elseif (preg_match('/addordermanualـ(\w+)/', $datain, $dataget)) {
    $iduser = $dataget[1];
    savedata("clear", "userid", $iduser);
    sendmessage($from_id, $textbotlang['Admin']['addorder']['onestep'], $backadmin, 'HTML');
    step('getusernameconfig', $from_id);
} elseif ($user['step'] == "getusernameconfig") {
    $text = strtolower($text);
    if (!preg_match('/^\w{3,32}$/', $text)) {
        sendmessage($from_id, $textbotlang['users']['status']['Invalidusername'], $backuser, 'html');
        return;
    }
    if (in_array($text, $usernameinvoice)) {
        sendmessage($from_id, $textbotlang['Admin']['addorder']['user_exits'], null, 'HTML');
        return;
    }
    savedata("save", "username", $text);
    sendmessage($from_id, $textbotlang['Admin']['addorder']['getname_panel'], $json_list_marzban_panel, 'HTML');
    step('getnamepanelconfig', $from_id);
} elseif ($user['step'] == "getnamepanelconfig") {
    savedata("save", "name_panel", $text);
    sendmessage($from_id, $textbotlang['Admin']['addorder']['get_product'], $json_list_product_list_admin, 'HTML');
    step('stependforaddorder', $from_id);
} elseif ($user['step'] == "stependforaddorder") {
    $userdata = json_decode($user['Processing_value'], true);
    $sql = "SELECT * FROM product  WHERE name_product = :name_product AND (Location = :location OR Location = '/all') LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':name_product', $text, PDO::PARAM_STR);
    $stmt->bindParam(':location', $userdata['name_panel'], PDO::PARAM_STR);
    $stmt->execute();
    $info_product = $stmt->fetch(PDO::FETCH_ASSOC);
    $panel = select("marzban_panel", "*", "name_panel", $userdata['name_panel'], "select");
    $date = time();
    $randomString = bin2hex(random_bytes(2));
    $stmt = $pdo->prepare("INSERT IGNORE INTO invoice (id_user, id_invoice, username, time_sell, Service_location, name_product, price_product, Volume, Service_time, Status) VALUES (:id_user, :id_invoice, :username, :time_sell, :Service_location, :name_product, :price_product, :Volume, :Service_time, :Status)");
    $Status = "active";
    $stmt->bindParam(':id_user', $userdata['userid'], PDO::PARAM_STR);
    $stmt->bindParam(':id_invoice', $randomString, PDO::PARAM_STR);
    $stmt->bindParam(':username', $userdata['username'], PDO::PARAM_STR);
    $stmt->bindParam(':time_sell', $date, PDO::PARAM_STR);
    $stmt->bindParam(':Service_location', $userdata['name_panel'], PDO::PARAM_STR);
    $stmt->bindParam(':name_product', $info_product['name_product'], PDO::PARAM_STR);
    $stmt->bindParam(':price_product', $info_product['price_product'], PDO::PARAM_STR);
    $stmt->bindParam(':Volume', $info_product['Volume_constraint'], PDO::PARAM_STR);
    $stmt->bindParam(':Service_time', $info_product['Service_time'], PDO::PARAM_STR);
    $stmt->bindParam(':Status', $Status, PDO::PARAM_STR);
    $stmt->execute();
    sendmessage($from_id, $textbotlang['Admin']['addorder']['added_order'], $mykeyboard, 'HTML');
    step('home', $from_id);
}
// ================================================================
// مدیریت زیر ربات‌ها از ربات مادر
// ================================================================

if ($text == '🤖 مدیریت زیر ربات‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $kb_childbot = json_encode(['keyboard' => [
        [['text' => '📋 لیست زیر ربات‌ها'], ['text' => '➕ ثبت زیر ربات جدید']],
        [['text' => '📨 درخواست‌های زیر ربات‌ها'], ['text' => '📊 گزارش کل زیر ربات‌ها']],
        [['text' => $textbotlang['Admin']['Back-Adminment']]],
    ], 'resize_keyboard' => true]);
    sendmessage($from_id, "🤖 <b>مدیریت زیر ربات‌ها</b>", $kb_childbot, 'HTML');
    step('home', $from_id);
    return;
}

// ----------------------------------------------------------------
// لیست زیر ربات‌ها
// ----------------------------------------------------------------
if ($text == '📋 لیست زیر ربات‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $bots = $pdo->query("SELECT * FROM reseller_bot ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($bots)) {
        sendmessage($from_id, "📋 هیچ زیر ربات‌ی ثبت نشده.", $mykeyboard, 'HTML');
        return;
    }
    $msg = "📋 <b>لیست زیر ربات‌ها:</b>\n\n";
    $btns = [];
    foreach ($bots as $b) {
        $icons = ['active'=>'✅','pending'=>'⏳','blocked'=>'🚫','deleted'=>'🗑'];
        $icon  = $icons[$b['status']] ?? '❓';
        $remain = max(0, $b['volume_limit'] - $b['volume_used']);
        $msg .= "{$icon} @{$b['bot_username']} (<code>{$b['owner_id']}</code>)\n";
        $msg .= "   📦 " . _fmt_gb($remain) . "/" . _fmt_gb($b['volume_limit']);
        $msg .= " | 🔢 {$b['config_used']}/" . ($b['config_limit']>0?$b['config_limit']:'∞');
        $msg .= " | 💳 " . number_format($b['wallet']) . " تومان\n\n";
        $btns[] = [['text' => "{$icon} @{$b['bot_username']}", 'callback_data' => "cb_manage_{$b['id']}"]];
    }
    sendmessage($from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
    return;
}

// ----------------------------------------------------------------
// ثبت زیر ربات جدید
// ----------------------------------------------------------------
if ($text == '➕ ثبت زیر ربات جدید') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    sendmessage($from_id, "➕ <b>ثبت زیر ربات جدید</b>\n\nتوکن ربات نماینده را ارسال کنید:\n(از @BotFather دریافت کنید)", $backadmin, 'HTML');
    step('cb_reg_token', $from_id);
}

if ($user['step'] == 'cb_reg_token') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $token = trim($text);
    // چک فرمت توکن
    if (!preg_match('/^\d+:[A-Za-z0-9_-]{35,}$/', $token)) {
        sendmessage($from_id, "❌ فرمت توکن نامعتبر است.\nتوکن باید به شکل <code>123456:ABC...</code> باشد.", $backadmin, 'HTML');
        return;
    }
    // چک تکراری نبودن
    $exist = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=?");
    $exist->execute([$token]);
    if ($exist->fetch()) {
        sendmessage($from_id, "❌ این توکن قبلاً ثبت شده.", $backadmin, 'HTML');
        return;
    }
    // دریافت اطلاعات ربات از تلگرام
    $bot_data = child_get_bot_info($token);
    if (!$bot_data) {
        sendmessage($from_id, "❌ توکن نامعتبر است یا دسترسی به تلگرام ممکن نیست.", $backadmin, 'HTML');
        return;
    }
    $bot_username = $bot_data['username'];
    $bot_name     = $bot_data['first_name'];
    update("user", "Processing_value", json_encode(['cb_token' => $token, 'cb_uname' => $bot_username, 'cb_name' => $bot_name]), "id", $from_id);
    sendmessage($from_id,
        "✅ ربات <b>@{$bot_username}</b> پیدا شد!\nنام: <b>" . htmlspecialchars($bot_name) . "</b>\n\nآیدی عددی مالک (نماینده) را ارسال کنید:",
        $backadmin, 'HTML');
    step('cb_reg_owner', $from_id);
}

if ($user['step'] == 'cb_reg_owner') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    if (!is_numeric($text)) {
        sendmessage($from_id, "❌ آیدی باید عدد باشد.", $backadmin, 'HTML');
        return;
    }
    $d = json_decode($user['Processing_value'], true);
    $d['cb_owner'] = $text;
    update("user", "Processing_value", json_encode($d), "id", $from_id);
    // نمایش لیست پنل‌ها
    $panels = $pdo->query("SELECT id, name_panel, type FROM marzban_panel WHERE status='activepanel'")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($panels)) {
        sendmessage($from_id, "❌ هیچ پنل فعالی برای انتخاب وجود ندارد. ابتدا یک پنل فعال در بخش مدیریت پنل‌ها اضافه کنید.", $backadmin, 'HTML');
        update("user", "Processing_value", "", "id", $from_id);
        step('home', $from_id);
        return;
    }
    $btns = [];
    foreach ($panels as $p) {
        $btns[] = [['text' => "📌 {$p['name_panel']} [{$p['type']}]", 'callback_data' => "cb_reg_panel_" . $p['id']]];
    }
    $btns[] = [['text' => '❌ انصراف', 'callback_data' => 'cb_reg_restart']];
    sendmessage($from_id, "🌐 پنل اختصاصی این زیر ربات را انتخاب کنید:", json_encode(['inline_keyboard' => $btns]), 'HTML');
    step('cb_reg_panel', $from_id);
}

// ----------------------------------------------------------------
// درخواست‌های زیر ربات‌ها (از child_bot_request)
// ----------------------------------------------------------------
if ($text == '📨 درخواست‌های زیر ربات‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $reqs = $pdo->query("SELECT cr.*, rb.bot_username, rb.owner_id FROM child_bot_request cr JOIN reseller_bot rb ON cr.bot_token = rb.bot_token WHERE cr.status='pending' ORDER BY cr.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($reqs)) {
        sendmessage($from_id, "📨 درخواستی در انتظار وجود ندارد.", $mykeyboard, 'HTML');
        return;
    }
    foreach ($reqs as $req) {
        $type_fa = $req['request_type'] === 'volume'
            ? "📦 حجم: <b>" . _fmt_gb($req['amount']) . "</b>"
            : "🔢 کانفیگ: <b>{$req['amount']} عدد</b>";
        $msg = "📨 <b>درخواست از زیر ربات</b>\n\n"
             . "🤖 ربات: @{$req['bot_username']}\n"
             . "👤 نماینده: <code>{$req['owner_id']}</code>\n"
             . "$type_fa\n"
             . ($req['total_price'] > 0 ? "💰 پرداختی: <b>" . number_format($req['total_price']) . " تومان</b>" : "");
        $kb = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید', 'callback_data' => "cbreq_approve_{$req['id']}"],
            ['text' => '❌ رد' . ($req['total_price']>0?' + برگشت وجه':''), 'callback_data' => "cbreq_reject_{$req['id']}"],
        ]]]);
        sendmessage($from_id, $msg, $kb, 'HTML');
    }
}

// ----------------------------------------------------------------
// گزارش کل زیر ربات‌ها
// ----------------------------------------------------------------
if ($text == '📊 گزارش کل زیر ربات‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $bots = $pdo->query("
        SELECT rb.*,
               (SELECT COUNT(*) FROM child_bot_invoice ci WHERE ci.bot_token=rb.bot_token AND ci.status='active') as active_cfgs,
               (SELECT COUNT(*) FROM child_bot_user cu WHERE cu.bot_token=rb.bot_token) as total_users,
               (SELECT SUM(ci.price) FROM child_bot_invoice ci WHERE ci.bot_token=rb.bot_token) as total_income
        FROM reseller_bot rb WHERE rb.status='active' ORDER BY rb.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    if (empty($bots)) { sendmessage($from_id, "📊 هیچ زیر ربات فعالی وجود ندارد.", $mykeyboard, 'HTML'); return; }

    $grand_income = 0;
    $grand_users  = 0;
    $grand_cfgs   = 0;
    $msg = "📊 <b>گزارش کل زیر ربات‌ها</b>\n\n";
    foreach ($bots as $b) {
        $remain = max(0, $b['volume_limit'] - $b['volume_used']);
        $income = $b['total_income'] ?? 0;
        $grand_income += $income;
        $grand_users  += $b['total_users'];
        $grand_cfgs   += $b['active_cfgs'];
        $msg .= "🤖 @{$b['bot_username']}\n"
             . "   👥 کاربران: {$b['total_users']} | ✅ کانفیگ: {$b['active_cfgs']}\n"
             . "   📦 " . _fmt_gb($remain) . "/" . _fmt_gb($b['volume_limit'])
             . " | 💰 " . number_format($income) . " تومان\n\n";
    }
    $msg .= "━━━━━━━━━━━━━━\n";
    $msg .= "📊 <b>جمع کل:</b>\n";
    $msg .= "👥 کاربران: <b>{$grand_users}</b> | ✅ کانفیگ: <b>{$grand_cfgs}</b>\n";
    $msg .= "💰 درآمد کل: <b>" . number_format($grand_income) . " تومان</b>";
    sendmessage($from_id, $msg, $mykeyboard, 'HTML');
}

// ================================================================
// Callbacks مدیریت زیر ربات (inline)
// ================================================================

// انتخاب پنل موقع ثبت
if (preg_match('/^cb_reg_panel_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    if ($user['step'] !== 'cb_reg_panel') {
        AnswerCallbackQuery($callback_query_id, '⛔ مرحله ثبت نام منقضی شده است. لطفاً دوباره شروع کنید.', true);
        return;
    }

    $panel_id = intval($m[1]);
    AnswerCallbackQuery($callback_query_id);
    $d = json_decode($user['Processing_value'] ?: '{}', true);
    if (!is_array($d) || empty($d['cb_token']) || empty($d['cb_uname']) || empty($d['cb_owner'])) {
        Editmessagetext($from_id, $message_id,
            "❌ خطا در ثبت زیر ربات. لطفاً دوباره شروع کنید.",
            json_encode(['inline_keyboard' => []]));
        update("user", "Processing_value", "", "id", $from_id);
        step('home', $from_id);
        return;
    }

    $panel_stmt = $pdo->prepare("SELECT name_panel FROM marzban_panel WHERE id = ? AND status='activepanel' LIMIT 1");
    $panel_stmt->execute([$panel_id]);
    $panel = $panel_stmt->fetch(PDO::FETCH_ASSOC);
    if (!$panel || empty($panel['name_panel'])) {
        Editmessagetext($from_id, $message_id,
            "❌ پنل انتخاب شده دیگر معتبر نیست. لطفاً دوباره ثبت زیر ربات را شروع کنید.",
            json_encode(['inline_keyboard' => []]));
        update("user", "Processing_value", "", "id", $from_id);
        step('home', $from_id);
        return;
    }

    $panel_name = $panel['name_panel'];
    $d['cb_panel'] = $panel_name;
    update("user", "Processing_value", json_encode($d), "id", $from_id);

    // ensure panel_id column exists for older installations
    try {
        $col_exists = $pdo->query("SHOW COLUMNS FROM reseller_bot LIKE 'panel_id'")->fetch(PDO::FETCH_ASSOC);
        if (!$col_exists) {
            $pdo->exec("ALTER TABLE reseller_bot ADD panel_id INT UNSIGNED NULL");
        }
    } catch (PDOException $e) {
        // ignore schema update failures, fallback insert below
    }

    // ثبت زیر ربات در دیتابیس
    try {
        $stmt = $pdo->prepare("INSERT INTO reseller_bot (bot_token, bot_username, bot_name, owner_id, panel_id, panel_name, status, created_at) VALUES (?,?,?,?,?,?,'active',?)");
        $stmt->execute([$d['cb_token'], $d['cb_uname'], $d['cb_name'], $d['cb_owner'], $panel_id, $panel_name, time()]);
    } catch (PDOException $e) {
        if (stripos($e->getMessage(), 'unknown column') !== false) {
            $stmt = $pdo->prepare("INSERT INTO reseller_bot (bot_token, bot_username, bot_name, owner_id, panel_name, status, created_at) VALUES (?,?,?,?,?,'active',?)");
            $stmt->execute([$d['cb_token'], $d['cb_uname'], $d['cb_name'], $d['cb_owner'], $panel_name, time()]);
        } else {
            throw $e;
        }
    }

    // تنظیم webhook
    $wh = child_set_webhook($d['cb_token'], $domainhosts);
    $wh_ok = $wh['ok'] ?? false;
    if ($wh_ok) {
        $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE bot_token=?")->execute([$d['cb_token']]);
    }

    Editmessagetext($from_id, $message_id,
        "✅ <b>زیر ربات ثبت و فعال شد!</b>\n\n"
        . "🤖 ربات: @{$d['cb_uname']}\n"
        . "👤 نماینده: <code>{$d['cb_owner']}</code>\n"
        . "🌐 پنل: <b>{$panel_name}</b>\n"
        . "⚡ وضعیت: ✅ فعال\n"
        . "🔗 Webhook: " . ($wh_ok ? '✅ تنظیم شد' : '❌ خطا - دستی اجرا کنید') . "\n\n"
        . "⚙️ برای تنظیم قیمت و سقف از لیست زیر ربات‌ها استفاده کنید.",
        json_encode(['inline_keyboard' => []]));
    update("user", "Processing_value", "", "id", $from_id);
    step('home', $from_id);
}

if ($datain === 'cb_reg_restart') {
    if (!is_super_admin($from_id)) return;
    update("user", "Processing_value", "", "id", $from_id);
    step('cb_reg_token', $from_id);
    sendmessage($from_id, "🔁 ثبت زیر ربات ریست شد. لطفاً دوباره توکن را ارسال کنید:", $backadmin, 'HTML');
    AnswerCallbackQuery($callback_query_id, '✅ ثبت ریست شد', true);
    return;
}

// مشاهده و مدیریت یک زیر ربات
if (preg_match('/^cb_manage_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    AnswerCallbackQuery($callback_query_id);
    $bid = $m[1];
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;

    [$info, $kb] = _render_bot_manage($b);
    Editmessagetext($from_id, $message_id, $info, $kb);
}

// toggle حداقل قیمت اجباری برای محصولات زیر ربات
if (preg_match('/^cb_toggle_minprice_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$m[1]]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;
    $new_val = ($b['enforce_min_price'] ?? 1) ? 0 : 1;
    $pdo->prepare("UPDATE reseller_bot SET enforce_min_price=? WHERE id=?")->execute([$new_val, $m[1]]);
    $msg_owner = $new_val
        ? "💰 از این پس برای محصولات شما <b>حداقل قیمت اجباری</b> دوباره اعمال می‌شود."
        : "🔓 محدودیت <b>حداقل قیمت</b> برای محصولات شما غیرفعال شد؛ هر قیمتی می‌توانید تعیین کنید.";
    child_sendmessage($b['bot_token'], $b['owner_id'], $msg_owner, null, 'HTML');
    AnswerCallbackQuery($callback_query_id, $new_val ? '💰 حداقل قیمت فعال شد' : '🔓 حداقل قیمت غیرفعال شد', true);

    $b2 = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b2->execute([$m[1]]);
    $b2 = $b2->fetch(PDO::FETCH_ASSOC);
    if ($b2) { [$info2, $kb2] = _render_bot_manage($b2); Editmessagetext($from_id, $message_id, $info2, $kb2); }
}

// ----------------------------------------------------------------
// سینک دستی مصرف پنل توسط ادمین
// ----------------------------------------------------------------
if (preg_match('/^cb_sync_pvc_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    AnswerCallbackQuery($callback_query_id, '🔄 در حال sync...', false);
    $bid_s = intval($m[1]);
    $b_s   = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b_s->execute([$bid_s]);
    $b_s   = $b_s->fetch(PDO::FETCH_ASSOC);
    if (!$b_s || empty($b_s['panel_name'])) {
        AnswerCallbackQuery($callback_query_id, '❌ پنل تنظیم نشده', true);
        return;
    }

    // گرفتن همه کانفیگ‌های این ربات
    $cfgs_s = $pdo->prepare("SELECT username_config FROM child_bot_invoice WHERE bot_token=? AND status IN ('active','expired','disabled')");
    $cfgs_s->execute([$b_s['bot_token']]);
    $cfgs_s = $cfgs_s->fetchAll(PDO::FETCH_ASSOC);

    $total_bytes = 0;
    $err_count   = 0;
    foreach ($cfgs_s as $cfg_s) {
        $du_s = $ManagePanel->DataUser($b_s['panel_name'], $cfg_s['username_config']);
        if (isset($du_s['used_traffic']) && is_numeric($du_s['used_traffic'])) {
            $total_bytes += $du_s['used_traffic'];
        } else {
            $err_count++;
        }
    }
    $total_gb_s = round($total_bytes / 1073741824, 3);
    $pdo->prepare("UPDATE reseller_bot SET panel_vol_used=?, panel_vol_last_sync=? WHERE id=?")
        ->execute([$total_gb_s, time(), $bid_s]);

    // نمایش نتیجه در پیام
    $cap_s = $b_s['panel_vol_cap'];
    $pct_s = $cap_s > 0 ? round(($total_gb_s / $cap_s) * 100, 1) : 0;
    $result_msg = "🔄 <b>Sync انجام شد</b>\n\n"
        . "📊 مصرف واقعی: <b>" . number_format($total_gb_s, 2) . " GB</b>\n"
        . ($cap_s > 0 ? "📦 سقف: <b>" . number_format($cap_s, 2) . " GB</b> ({$pct_s}% مصرف)\n" : "📦 سقف: بدون محدودیت\n")
        . "📋 تعداد کانفیگ‌های بررسی شده: <b>" . count($cfgs_s) . "</b>\n"
        . ($err_count > 0 ? "⚠️ خطا در {$err_count} کانفیگ\n" : "")
        . "⏰ زمان: " . jdate('Y/m/d H:i', time());
    sendmessage($from_id, $result_msg, null, 'HTML');
}

// toggle سقف حجم روی محصول هنگام ساخت توسط نماینده
if (preg_match('/^cb_toggle_volcap_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$m[1]]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;
    $new_val = ($b['enforce_vol_cap_product'] ?? 0) ? 0 : 1;
    $pdo->prepare("UPDATE reseller_bot SET enforce_vol_cap_product=? WHERE id=?")->execute([$new_val, $m[1]]);
    $msg_owner = $new_val
        ? "📦 از این پس حجم محصولات شما نمی‌تواند بیشتر از سقف حجم کل ربات‌تان باشد."
        : "🔓 محدودیت سقف حجم روی محصولات شما غیرفعال شد؛ هر حجمی می‌توانید برای محصول تعیین کنید.";
    child_sendmessage($b['bot_token'], $b['owner_id'], $msg_owner, null, 'HTML');
    AnswerCallbackQuery($callback_query_id, $new_val ? '📦 سقف حجم محصول فعال شد' : '🔓 سقف حجم محصول غیرفعال شد', true);

    $b2 = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b2->execute([$m[1]]);
    $b2 = $b2->fetch(PDO::FETCH_ASSOC);
    if ($b2) { [$info2, $kb2] = _render_bot_manage($b2); Editmessagetext($from_id, $message_id, $info2, $kb2); }
}


// toggle نسخه محدود زیر ربات
if (preg_match('/^cb_toggle_limited_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$m[1]]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;
    $new_limited = ($b['limited_panel'] ?? 1) ? 0 : 1;
    $pdo->prepare("UPDATE reseller_bot SET limited_panel=? WHERE id=?")->execute([$new_limited, $m[1]]);
    $msg_owner = $new_limited
        ? "🔒 ربات شما به حالت <b>نسخه محدود</b> تغییر کرد.\nبعضی بخش‌های پنل در دسترس نیستند."
        : "🔓 ربات شما به حالت <b>نسخه کامل</b> تغییر کرد.\nهمه بخش‌های پنل در دسترس هستند.";
    child_sendmessage($b['bot_token'], $b['owner_id'], $msg_owner, null, 'HTML');
    AnswerCallbackQuery($callback_query_id, $new_limited ? '🔒 نسخه محدود فعال شد' : '🔓 نسخه کامل فعال شد', true);
    // رفرش پیام
    $b2 = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b2->execute([$m[1]]);
    $b2 = $b2->fetch(PDO::FETCH_ASSOC);
    if ($b2) {
        [$info2, $kb2] = _render_bot_manage($b2);
        Editmessagetext($from_id, $message_id, $info2, $kb2);
    }
}

// تنظیم webhook از inline
if (preg_match('/^cb_webhook_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$m[1]]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;
    $wh = child_set_webhook($b['bot_token'], $domainhosts);
    if ($wh['ok'] ?? false) {
        $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE id=?")->execute([$m[1]]);
        AnswerCallbackQuery($callback_query_id, '✅ Webhook تنظیم شد', true);
    } else {
        AnswerCallbackQuery($callback_query_id, '❌ خطا: ' . ($wh['description']??''), true);
    }
}

// فعال/بلاک toggle
if (preg_match('/^cb_toggle_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$m[1]]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;
    // pending -> active | active -> blocked | blocked -> active
    if ($b['status'] === 'pending') {
        $new_status = 'active';
    } elseif ($b['status'] === 'active') {
        $new_status = 'blocked';
    } else {
        $new_status = 'active';
    }
    $pdo->prepare("UPDATE reseller_bot SET status=? WHERE id=?")->execute([$new_status, $m[1]]);
    $msg = $new_status === 'active'
        ? "✅ زیر ربات شما فعال شد.\nبرای شروع دوباره /start را بزنید."
        : "🚫 زیر ربات شما بلاک شد.";
    child_sendmessage($b['bot_token'], $b['owner_id'], $msg, null, 'HTML');
    // آپدیت پیام inline
    $bid_t = $m[1];
    $b_updated = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b_updated->execute([$bid_t]);
    $b_updated = $b_updated->fetch(PDO::FETCH_ASSOC);
    if ($b_updated) {
        $remain_t = max(0, $b_updated['volume_limit'] - $b_updated['volume_used']);
        $icons_t  = ['active'=>'✅','pending'=>'⏳','blocked'=>'🚫'];
        $info_t   = "{$icons_t[$b_updated['status']]} <b>@{$b_updated['bot_username']}</b>\n\n"
                  . "👤 نماینده: <code>{$b_updated['owner_id']}</code>\n"
                  . "🌐 پنل: <b>{$b_updated['panel_name']}</b>\n"
                  . "💳 کیف پول: <b>" . number_format($b_updated['wallet']) . " تومان</b>\n"
                  . "🔗 Webhook: " . ($b_updated['webhook_set'] ? '✅' : '❌') . "\n\n"
                  . "📦 حجم: " . _fmt_gb($remain_t) . "/" . _fmt_gb($b_updated['volume_limit']) . "\n"
                  . "🔢 کانفیگ: {$b_updated['config_used']}" . ($b_updated['config_limit']>0 ? "/{$b_updated['config_limit']}" : '');
        $btns_t = [
            [['text' => ($b_updated['status']==='active'?'🚫 بلاک':'✅ فعال'), 'callback_data' => "cb_toggle_{$bid_t}"],
             ['text' => '🗑 حذف', 'callback_data' => "cb_delete_{$bid_t}"]],
        ];
        Editmessagetext($from_id, $message_id, $info_t, json_encode(['inline_keyboard' => $btns_t]));
    }
    AnswerCallbackQuery($callback_query_id, $new_status === 'active' ? '✅ فعال شد' : '🚫 بلاک شد', true);
}

// تغییر توکن زیر ربات
if (preg_match('/^cb_change_token_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { AnswerCallbackQuery($callback_query_id, '❌ زیر ربات پیدا نشد', true); return; }
    update("user", "Processing_value", json_encode(['cb_change_token_id' => $bid]), "id", $from_id);
    sendmessage($from_id, "🔐 لطفاً توکن جدید زیر ربات را ارسال کنید:", $backadmin, 'HTML');
    step('cb_do_change_token', $from_id);
    AnswerCallbackQuery($callback_query_id, '✅ آماده دریافت توکن جدید', true);
    return;
}

// حذف زیر ربات
if (preg_match('/^cb_delete_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) {
        AnswerCallbackQuery($callback_query_id, '❌ زیر ربات پیدا نشد', true);
        return;
    }
    child_delete_webhook($b['bot_token']);
    if (!empty($b['panel_pool_id'])) {
        $pdo->prepare("UPDATE reseller_panel_pool SET status='available', assigned_to=NULL WHERE id=?")->execute([$b['panel_pool_id']]);
    }
    $pdo->prepare("UPDATE reseller_bot SET status='deleted', webhook_set=0 WHERE id=?")->execute([$bid]);
    child_sendmessage($b['bot_token'], $b['owner_id'], "❌ ربات شما توسط مدیر غیرفعال شده است.", null, 'HTML');
    Editmessagetext($from_id, $message_id, "🗑 زیر ربات @{$b['bot_username']} حذف شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ حذف شد', true);
}

// شارژ کیف پول از inline
if (preg_match('/^cb_charge_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    AnswerCallbackQuery($callback_query_id);
    update("user", "Processing_value", json_encode(['cb_charge_id' => $m[1]]), "id", $from_id);
    sendmessage($from_id, "💳 مبلغ شارژ (تومان) را وارد کنید:\n(برای کسر، عدد منفی مثل -50000):", $backadmin, 'HTML');
    step('cb_do_charge', $from_id);
}

if ($user['step'] == 'cb_do_charge') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $amount = intval(str_replace([',','،'], '', $text));
    if ($amount == 0) { sendmessage($from_id, "❌ مبلغ نامعتبر.", $backadmin, 'HTML'); return; }
    $d  = json_decode($user['Processing_value'], true);
    $bid = $d['cb_charge_id'];
    $b  = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b  = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { sendmessage($from_id, "❌ ربات پیدا نشد.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $new_wallet = $b['wallet'] + $amount;
    if ($new_wallet < 0) { sendmessage($from_id, "❌ موجودی کافی نیست (موجودی: " . number_format($b['wallet']) . " تومان).", $backadmin, 'HTML'); return; }
    $pdo->prepare("UPDATE reseller_bot SET wallet=? WHERE id=?")->execute([$new_wallet, $bid]);
    $action = $amount > 0 ? "+" . number_format($amount) : number_format($amount);
    sendmessage($from_id, "✅ کیف پول @{$b['bot_username']}: {$action} تومان\nموجودی جدید: <b>" . number_format($new_wallet) . " تومان</b>", $mykeyboard, 'HTML');
    child_sendmessage($b['bot_token'], $b['owner_id'],
        $amount > 0
            ? "💳 کیف پول شما <b>+" . number_format($amount) . " تومان</b> شارژ شد.\nموجودی: <b>" . number_format($new_wallet) . " تومان</b>"
            : "💳 <b>" . number_format(abs($amount)) . " تومان</b> از کیف پول کسر شد.\nموجودی: <b>" . number_format($new_wallet) . " تومان</b>",
        null, 'HTML');
    step('home', $from_id);
}

if ($user['step'] == 'cb_do_change_token') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $d = json_decode($user['Processing_value'] ?? '{}', true);
    $bid = intval($d['cb_change_token_id'] ?? 0);
    if (!$bid) { sendmessage($from_id, "❌ اطلاعات توکن ذخیره نشده است.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $new_token = trim($text);
    if (!preg_match('/^\d+:[A-Za-z0-9_-]{35,}$/', $new_token)) {
        sendmessage($from_id, "❌ فرمت توکن نامعتبر است. لطفاً توکن صحیح را ارسال کنید:", $backadmin, 'HTML');
        return;
    }
    $exists = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=? AND id<>?");
    $exists->execute([$new_token, $bid]);
    if ($exists->fetch()) {
        sendmessage($from_id, "❌ این توکن قبلاً برای یک زیر ربات دیگر ثبت شده.", $backadmin, 'HTML');
        return;
    }
    require_once 'child_botapi.php';
    $bot_info = child_get_bot_info($new_token);
    if (!$bot_info) {
        sendmessage($from_id, "❌ توکن جدید نامعتبر است یا دسترسی به تلگرام ممکن نیست.", $backadmin, 'HTML');
        return;
    }
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { sendmessage($from_id, "❌ زیر ربات پیدا نشد.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    $old_token = $b['bot_token'];
    $new_username = $bot_info['username'] ?? '';
    $new_name = $bot_info['first_name'] ?? $new_username;
    $pdo->prepare("UPDATE reseller_bot SET bot_token=?, bot_username=?, bot_name=?, webhook_set=0 WHERE id=?")
        ->execute([$new_token, $new_username, $new_name, $bid]);
    $pdo->prepare("UPDATE reseller_bot_invoice SET bot_token=?, bot_username=? WHERE bot_token=?")
        ->execute([$new_token, $new_username, $old_token]);
    $pdo->prepare("UPDATE reseller_panel_pool SET assigned_to=? WHERE assigned_to=?")
        ->execute([$new_token, $old_token]);
    foreach (['child_bot_request', 'child_bot_user', 'child_bot_invoice'] as $table) {
        $pdo->prepare("UPDATE {$table} SET bot_token=? WHERE bot_token=?")
            ->execute([$new_token, $old_token]);
    }
    child_delete_webhook($old_token);
    $wh = child_set_webhook($new_token, $domainhosts);
    if ($wh['ok'] ?? false) {
        $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE id=?")->execute([$bid]);
    }
    child_sendmessage($new_token, $b['owner_id'], "🔐 توکن ربات شما با موفقیت به‌روز شد.", null, 'HTML');
    sendmessage($from_id, "✅ توکن زیر ربات @{$new_username} به‌روز شد.", $mykeyboard, 'HTML');
    update("user", "Processing_value", json_encode([]), "id", $from_id);
    step('home', $from_id);
    return;
}

// تنظیم سقف حجم/کانفیگ/قیمت از inline
if ($datain) {
    $cb_set_map = [
        'cb_set_vol' => ['volume_limit', 'سقف حجم (گیگابایت)'],
        'cb_set_pvc' => ['panel_vol_cap', 'سقف مصرف واقعی پنل (گیگابایت) - 0 = بدون محدودیت'],
        'cb_set_cfg' => ['config_limit', 'سقف کانفیگ (۰=نامحدود)'],
        'cb_set_pgb' => ['price_per_gb', 'قیمت/گیگ (تومان)'],
        'cb_set_pm'  => ['price_per_month', 'قیمت/ماه (تومان)'],
    ];
    foreach ($cb_set_map as $cb => [$field, $label]) {
        if (preg_match('/^' . $cb . '_(\d+)$/', $datain, $m)) {
            if (!is_super_admin($from_id)) return;
            update("user", "Processing_value", json_encode(['cb_set_field' => $field, 'cb_set_id' => $m[1]]), "id", $from_id);
            sendmessage($from_id, "✏️ مقدار <b>{$label}</b> را وارد کنید:", $backadmin, 'HTML');
            step('cb_do_set', $from_id);
            break;
        }
    }
}

if ($user['step'] == 'cb_do_set') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    if (!ctype_digit(ltrim($text, '-')) || (intval($text) < 0 && $text !== '0')) {
        sendmessage($from_id, "❌ عدد معتبر وارد کنید.", $backadmin, 'HTML'); return;
    }
    $d = json_decode($user['Processing_value'], true);
    $pdo->prepare("UPDATE reseller_bot SET {$d['cb_set_field']}=? WHERE id=?")->execute([intval($text), $d['cb_set_id']]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$d['cb_set_id']]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    sendmessage($from_id, "✅ تنظیم شد.", $mykeyboard, 'HTML');
    child_sendmessage($b['bot_token'], $b['owner_id'], "⚙️ تنظیمات ربات شما توسط مدیر آپدیت شد.", null, 'HTML');
    step('home', $from_id);
}

// ---- تمدید زمان (روز) پنل نمایندگی — افزایشی روی expire_at فعلی ----
if (preg_match('/^cb_extend_days_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    update("user", "Processing_value", json_encode(['cb_extend_id' => $m[1]]), "id", $from_id);
    sendmessage($from_id, "✏️ تعداد روزی که می‌خواهید اضافه شود را وارد کنید (برای کسر، عدد منفی وارد کنید):", $backadmin, 'HTML');
    step('cb_do_extend_days', $from_id);
    AnswerCallbackQuery($callback_query_id);
}

if ($user['step'] == 'cb_do_extend_days') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); step('home', $from_id); return; }
    if (!ctype_digit(ltrim($text, '-')) || intval($text) === 0) {
        sendmessage($from_id, "❌ عدد صحیح غیرصفر وارد کنید (مثبت برای افزایش، منفی برای کاهش).", $backadmin, 'HTML'); return;
    }
    $d   = json_decode($user['Processing_value'], true);
    $bid = $d['cb_extend_id'];
    $days = intval($text);

    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { sendmessage($from_id, "❌ یافت نشد.", $mykeyboard, 'HTML'); step('home', $from_id); return; }

    $base = max(time(), (int)$b['expire_at']); // اگر منقضی شده، تمدید از همین لحظه حساب می‌شود
    $new_expire = $base + ($days * 86400);
    if ($new_expire <= time()) $new_expire = time(); // جلوگیری از تاریخ منفی/گذشته نامعقول

    $pdo->prepare("UPDATE reseller_bot SET expire_at=?, expire_warned=0 WHERE id=?")->execute([$new_expire, $bid]);

    $expire_txt = date('Y/m/d', $new_expire);
    sendmessage($from_id, "✅ مدت اعتبار پنل تنظیم شد.\n⏳ تاریخ انقضای جدید: <b>{$expire_txt}</b>", $mykeyboard, 'HTML');
    child_sendmessage($b['bot_token'], $b['owner_id'],
        ($days > 0
            ? "⏳ مدت اعتبار پنل نمایندگی شما <b>{$days} روز</b> افزایش یافت."
            : "⏳ مدت اعتبار پنل نمایندگی شما " . abs($days) . " روز کاهش یافت.")
        . "\nتاریخ انقضای جدید: <b>{$expire_txt}</b>",
        null, 'HTML');
    step('home', $from_id);
}

// ===================== [ فاز ۲ — تنظیمات فروش پنل — ادمین ] =====================

// نمایش منوی تنظیمات فروش پنل
if ($text === '⚙️ تنظیمات فروش پنل') {
    if (!is_super_admin($from_id)) return;
    $s   = select('setting', '*');
    $status_txt = ($s['bot_sale_status'] ?? 'off') === 'on' ? '✅ فعال' : '🔴 غیرفعال';
    $card       = $s['bot_sale_card_num']  ?? '—';
    $cname      = $s['bot_sale_card_name'] ?? '—';
    $msg  = "⚙️ <b>تنظیمات فروش پنل نمایندگی</b>\n\n";
    $msg .= "🔘 وضعیت: <b>{$status_txt}</b>\n";
    $msg .= "💳 شماره کارت: <code>{$card}</code>\n";
    $msg .= "👤 نام صاحب کارت: <b>{$cname}</b>\n";
    $kb = json_encode(['inline_keyboard' => [
        [['text' => ($s['bot_sale_status'] ?? 'off') === 'on' ? '🔴 غیرفعال کردن فروش' : '✅ فعال کردن فروش',
          'callback_data' => 'admin_botsale_toggle']],
        [['text' => '💳 تنظیم شماره کارت',    'callback_data' => 'admin_botsale_set_card']],
        [['text' => '👤 تنظیم نام صاحب کارت', 'callback_data' => 'admin_botsale_set_cname']],
        [['text' => '🤖 مدیریت پلن‌ها',        'callback_data' => 'admin_bplan_list']],
        [['text' => '📋 سفارش‌های خرید پنل',  'callback_data' => 'admin_botsale_orders']],
    ]]);
    sendmessage($from_id, $msg, $kb, 'HTML');
}

// step: دریافت شماره کارت
if ($user['step'] === 'admin_botsale_card') {
    if (!is_super_admin($from_id)) return;
    $card = preg_replace('/\D/', '', $text);
    if (strlen($card) !== 16) {
        sendmessage($from_id, "❌ شماره کارت باید ۱۶ رقم باشد. دوباره وارد کنید:", null, 'HTML');
        return;
    }
    update('setting', 'bot_sale_card_num', $card);
    sendmessage($from_id, "✅ شماره کارت ثبت شد: <code>{$card}</code>", $mykeyboard, 'HTML');
    step('home', $from_id);
}

// step: دریافت نام صاحب کارت
if ($user['step'] === 'admin_botsale_cname') {
    if (!is_super_admin($from_id)) return;
    update('setting', 'bot_sale_card_name', $text);
    sendmessage($from_id, "✅ نام صاحب کارت ثبت شد: <b>{$text}</b>", $mykeyboard, 'HTML');
    step('home', $from_id);
}

// Callbacks تنظیمات فروش پنل
if ($datain === 'admin_botsale_toggle') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $s   = select('setting', 'bot_sale_status');
    $new = ($s['bot_sale_status'] ?? 'off') === 'on' ? 'off' : 'on';
    update('setting', 'bot_sale_status', $new);
    AnswerCallbackQuery($callback_query_id, $new === 'on' ? '✅ فروش فعال شد' : '🔴 فروش غیرفعال شد', true);
}
if ($datain === 'admin_botsale_set_card') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    sendmessage($from_id, "💳 شماره کارت ۱۶ رقمی را وارد کنید:", null, 'HTML');
    step('admin_botsale_card', $from_id);
    AnswerCallbackQuery($callback_query_id);
}
if ($datain === 'admin_botsale_set_cname') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    sendmessage($from_id, "👤 نام صاحب کارت را وارد کنید:", null, 'HTML');
    step('admin_botsale_cname', $from_id);
    AnswerCallbackQuery($callback_query_id);
}
if ($datain === 'admin_bplan_list') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $plans = $pdo->query("SELECT * FROM reseller_bot_plan ORDER BY price ASC")->fetchAll(PDO::FETCH_ASSOC);
    $msg   = "🤖 <b>پلن‌های فروش پنل</b>\n\n";
    $rows  = [];
    foreach ($plans as $p) {
        $st   = $p['status'] === 'active' ? '✅' : '🔴';
        $vol  = $p['volume_gb'] >= 1024 ? round($p['volume_gb']/1024,1).'TB' : $p['volume_gb'].'GB';
        $rows[] = [['text' => "{$st} {$p['name']} | {$vol} | ".number_format($p['price'])."ت",
                     'callback_data' => "admin_bplan_edit_{$p['id']}"]];
    }
    $rows[] = [['text' => '➕ افزودن پلن', 'callback_data' => 'admin_bplan_add']];
    $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'backadmin']];
    Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}
if ($datain === 'admin_botsale_orders') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $orders = $pdo->query(
        "SELECT * FROM reseller_bot_invoice ORDER BY created_at DESC LIMIT 15"
    )->fetchAll(PDO::FETCH_ASSOC);
    $msg = "📋 <b>سفارش‌های اخیر پنل نمایندگی</b>\n\n";
    if (empty($orders)) {
        $msg .= "هنوز سفارشی ثبت نشده.";
    }
    foreach ($orders as $o) {
        $st  = match($o['payment_status']) {
            'paid'         => '✅ پرداخت شده',
            'pending'      => '⏳ در انتظار',
            'waiting'      => '🕐 در حال پرداخت',
            'waiting_admin'=> '🔔 منتظر تایید ادمین',
            'rejected'     => '❌ رد شده',
            default        => $o['payment_status']
        };
        $date = date('m/d H:i', $o['created_at']);
        $msg .= "📌 <code>{$o['order_id']}</code>\n";
        $msg .= "👤 {$o['buyer_id']} | 🤖 @{$o['bot_username']}\n";
        $msg .= "📋 {$o['plan_name']} | {$st} | {$date}\n\n";
    }
    $rows = [];
    // سفارش‌های منتظر تایید ادمین (کارت به کارت)
    foreach ($orders as $o) {
        if ($o['payment_status'] === 'waiting_admin') {
            $rows[] = [
                ['text' => "✅ تایید #{$o['order_id']}", 'callback_data' => "bot_sale_approve_{$o['order_id']}"],
                ['text' => "❌ رد",                       'callback_data' => "bot_sale_reject_{$o['order_id']}"],
            ];
        }
    }
    $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'backadmin']];
    Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}


// ================================================================
// فاز ۳ — callbacks تایید/رد درخواست‌های زیر ربات
// ================================================================

// تایید درخواست حجم یا کانفیگ از زیر ربات
if (preg_match('/^cbreq_approve_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $req_id = intval($m[1]);
    $req = $pdo->prepare("SELECT cr.*, rb.bot_username, rb.owner_id, rb.wallet FROM child_bot_request cr JOIN reseller_bot rb ON cr.bot_token = rb.bot_token WHERE cr.id=?");
    $req->execute([$req_id]);
    $req = $req->fetch(PDO::FETCH_ASSOC);
    if (!$req) { AnswerCallbackQuery($callback_query_id, '❌ درخواست پیدا نشد', true); return; }
    if ($req['status'] !== 'pending') { AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true); return; }

    if ($req['request_type'] === 'volume') {
        $pdo->prepare("UPDATE reseller_bot SET volume_limit = volume_limit + ? WHERE bot_token = ?")->execute([$req['amount'], $req['bot_token']]);
        $msg_owner = "✅ <b>درخواست حجم تایید شد!</b>\n\n📦 " . _fmt_gb($req['amount']) . " به سقف شما اضافه شد.";
        $msg_admin_confirm = "✅ درخواست حجم @{$req['bot_username']} تایید شد. +" . _fmt_gb($req['amount']);
    } elseif ($req['request_type'] === 'config') {
        $pdo->prepare("UPDATE reseller_bot SET config_limit = config_limit + ? WHERE bot_token = ?")->execute([$req['amount'], $req['bot_token']]);
        $msg_owner = "✅ <b>درخواست کانفیگ تایید شد!</b>\n\n🔢 {$req['amount']} کانفیگ به سقف شما اضافه شد.";
        $msg_admin_confirm = "✅ درخواست کانفیگ @{$req['bot_username']} تایید شد. +{$req['amount']} عدد";
    } else {
        AnswerCallbackQuery($callback_query_id, '❌ نوع درخواست نامشخص', true); return;
    }

    $pdo->prepare("UPDATE child_bot_request SET status='approved', reviewed_at=? WHERE id=?")->execute([time(), $req_id]);
    child_sendmessage($req['bot_token'], $req['owner_id'], $msg_owner, null, 'HTML');
    Editmessagetext($from_id, $message_id, $msg_admin_confirm, json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ تایید شد', true);
}

// رد درخواست حجم یا کانفیگ از زیر ربات + برگشت وجه اگه پول کسر شده بود
if (preg_match('/^cbreq_reject_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $req_id = intval($m[1]);
    $req = $pdo->prepare("SELECT cr.*, rb.bot_username, rb.owner_id, rb.wallet FROM child_bot_request cr JOIN reseller_bot rb ON cr.bot_token = rb.bot_token WHERE cr.id=?");
    $req->execute([$req_id]);
    $req = $req->fetch(PDO::FETCH_ASSOC);
    if (!$req) { AnswerCallbackQuery($callback_query_id, '❌ درخواست پیدا نشد', true); return; }
    if ($req['status'] !== 'pending') { AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true); return; }

    $pdo->prepare("UPDATE child_bot_request SET status='rejected', reviewed_at=? WHERE id=?")->execute([time(), $req_id]);

    $msg_owner = "❌ <b>درخواست شما رد شد.</b>\n\n";
    // برگشت وجه اگه پرداخت کرده بود
    if ($req['total_price'] > 0) {
        $pdo->prepare("UPDATE reseller_bot SET wallet = wallet + ? WHERE bot_token = ?")->execute([$req['total_price'], $req['bot_token']]);
        $msg_owner .= "💰 مبلغ <b>" . number_format($req['total_price']) . " تومان</b> به کیف پول شما برگشت داده شد.";
    } else {
        $msg_owner .= "برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.";
    }

    child_sendmessage($req['bot_token'], $req['owner_id'], $msg_owner, null, 'HTML');
    Editmessagetext($from_id, $message_id, "❌ درخواست @{$req['bot_username']} رد شد." . ($req['total_price'] > 0 ? "\n💰 " . number_format($req['total_price']) . " تومان برگشت داده شد." : ""), json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '❌ رد شد', true);
}

// ================================================================
// فاز ۳ — تنظیم اینباندهای مجاز برای زیر ربات
// ================================================================

if (preg_match('/^cb_set_inbound_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { AnswerCallbackQuery($callback_query_id, '❌ یافت نشد'); return; }

    $panel = select("marzban_panel", "*", "name_panel", $b['panel_name'], "select");
    if (!$panel) { AnswerCallbackQuery($callback_query_id, '❌ پنل پیدا نشد', true); return; }

    $all_inbounds = json_decode($panel['inbounds'] ?? '[]', true);
    if (empty($all_inbounds)) { AnswerCallbackQuery($callback_query_id, '❌ اینباندی روی این پنل ثبت نشده', true); return; }

    $allowed = json_decode($b['allowed_inbounds'] ?? '[]', true) ?: [];
    $rows = [];
    foreach ($all_inbounds as $inb) {
        $tag = is_array($inb) ? ($inb['tag'] ?? (string)$inb) : (string)$inb;
        $checked = in_array($tag, $allowed) ? '✅' : '⬜';
        $tag_enc = base64_encode($tag . '|' . $bid);
        $rows[] = [['text' => "$checked $tag", 'callback_data' => "cb_inb_toggle_{$tag_enc}"]];
    }
    $rows[] = [['text' => '💾 ذخیره و بازگشت', 'callback_data' => "cb_inb_save_{$bid}"]];
    Editmessagetext($from_id, $message_id,
        "📡 <b>اینباندهای مجاز</b>\n🤖 @{$b['bot_username']}\n\nانتخاب کنید:",
        json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}

// toggle یک اینباند
if (preg_match('/^cb_inb_toggle_(.+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $decoded = base64_decode($m[1]);
    [$tag, $bid] = explode('|', $decoded, 2);
    $bid = intval($bid);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { AnswerCallbackQuery($callback_query_id, '❌'); return; }

    $allowed = json_decode($b['allowed_inbounds'] ?? '[]', true) ?: [];
    if (in_array($tag, $allowed)) {
        $allowed = array_values(array_filter($allowed, fn($t) => $t !== $tag));
        AnswerCallbackQuery($callback_query_id, "⬜ $tag حذف شد");
    } else {
        $allowed[] = $tag;
        AnswerCallbackQuery($callback_query_id, "✅ $tag اضافه شد");
    }
    $pdo->prepare("UPDATE reseller_bot SET allowed_inbounds=? WHERE id=?")->execute([json_encode($allowed), $bid]);

    // آپدیت inline keyboard
    $panel = select("marzban_panel", "*", "name_panel", $b['panel_name'], "select");
    $all_inbounds = json_decode($panel['inbounds'] ?? '[]', true);
    $rows = [];
    foreach ($all_inbounds as $inb) {
        $t = is_array($inb) ? ($inb['tag'] ?? (string)$inb) : (string)$inb;
        $c = in_array($t, $allowed) ? '✅' : '⬜';
        $te = base64_encode($t . '|' . $bid);
        $rows[] = [['text' => "$c $t", 'callback_data' => "cb_inb_toggle_{$te}"]];
    }
    $rows[] = [['text' => '💾 ذخیره و بازگشت', 'callback_data' => "cb_inb_save_{$bid}"]];
    Editmessagetext($from_id, $message_id,
        "📡 <b>اینباندهای مجاز</b>\n🤖 @{$b['bot_username']}\n\nانتخاب کنید:",
        json_encode(['inline_keyboard' => $rows]));
}

// ذخیره اینباندها
if (preg_match('/^cb_inb_save_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    $allowed = json_decode($b['allowed_inbounds'] ?? '[]', true) ?: [];
    $list_txt = empty($allowed) ? 'همه اینباندها' : implode(', ', $allowed);
    Editmessagetext($from_id, $message_id,
        "✅ اینباندهای مجاز ذخیره شد:\n<code>{$list_txt}</code>",
        json_encode(['inline_keyboard' => []]));
    child_sendmessage($b['bot_token'], $b['owner_id'], "📡 اینباندهای مجاز ربات شما توسط ادمین آپدیت شد.", null, 'HTML');
    AnswerCallbackQuery($callback_query_id, '✅ ذخیره شد', true);
}

// ================================================================
// فاز ۳ — گزارش تفصیلی یک زیر ربات خاص
// ================================================================

if (preg_match('/^cb_report_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { AnswerCallbackQuery($callback_query_id, '❌'); return; }

    $total_cfgs   = $pdo->prepare("SELECT COUNT(*) FROM child_bot_invoice WHERE bot_token=?"); $total_cfgs->execute([$b['bot_token']]); $total_cfgs = $total_cfgs->fetchColumn();
    $active_cfgs  = $pdo->prepare("SELECT COUNT(*) FROM child_bot_invoice WHERE bot_token=? AND status='active'"); $active_cfgs->execute([$b['bot_token']]); $active_cfgs = $active_cfgs->fetchColumn();
    $total_users  = $pdo->prepare("SELECT COUNT(*) FROM child_bot_user WHERE bot_token=?"); $total_users->execute([$b['bot_token']]); $total_users = $total_users->fetchColumn();
    $total_income = $pdo->prepare("SELECT COALESCE(SUM(price),0) FROM child_bot_invoice WHERE bot_token=?"); $total_income->execute([$b['bot_token']]); $total_income = $total_income->fetchColumn();
    $pending_reqs = $pdo->prepare("SELECT COUNT(*) FROM child_bot_request WHERE bot_token=? AND status='pending'"); $pending_reqs->execute([$b['bot_token']]); $pending_reqs = $pending_reqs->fetchColumn();

    // ۱۰ کانفیگ آخر
    $last_cfgs = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE bot_token=? ORDER BY created_at DESC LIMIT 10");
    $last_cfgs->execute([$b['bot_token']]);
    $last_cfgs = $last_cfgs->fetchAll(PDO::FETCH_ASSOC);

    $remain = max(0, $b['volume_limit'] - $b['volume_used']);
    $icons = ['active'=>'✅','pending'=>'⏳','blocked'=>'🚫'];
    $status_txt = $icons[$b['status']] ?? '❓';

    $msg  = "📊 <b>گزارش تفصیلی: @{$b['bot_username']}</b>\n\n";
    $msg .= "{$status_txt} وضعیت | 👤 نماینده: <code>{$b['owner_id']}</code>\n";
    $msg .= "🌐 پنل: <b>{$b['panel_name']}</b>\n\n";
    $msg .= "━━━━━━━━━━━━━━\n";
    $msg .= "👥 کاربران: <b>{$total_users}</b>\n";
    $msg .= "📦 کل کانفیگ: <b>{$total_cfgs}</b> | ✅ فعال: <b>{$active_cfgs}</b>\n";
    $msg .= "💰 درآمد کل: <b>" . number_format($total_income) . " تومان</b>\n";
    $msg .= "📨 درخواست‌های در انتظار: <b>{$pending_reqs}</b>\n\n";
    $msg .= "━━━━━━━━━━━━━━\n";
    $msg .= "📦 حجم: " . _fmt_gb($b['volume_used']) . "/" . _fmt_gb($b['volume_limit']) . " | باقی: <b>" . _fmt_gb($remain) . "</b>\n";
    $msg .= "🔢 کانفیگ: {$b['config_used']}" . ($b['config_limit']>0 ? "/{$b['config_limit']}" : '') . "\n";
    $msg .= "💳 کیف پول: <b>" . number_format($b['wallet']) . " تومان</b>\n";
    $msg .= "💵 قیمت/گیگ: " . number_format($b['price_per_gb']) . " | 📅 قیمت/ماه: " . number_format($b['price_per_month']) . " تومان\n\n";

    if (!empty($last_cfgs)) {
        $msg .= "━━━━━━━━━━━━━━\n";
        $msg .= "📋 <b>۱۰ کانفیگ آخر:</b>\n";
        foreach ($last_cfgs as $c) {
            $exp = $c['expire_at'] > 0 ? date('m/d', $c['expire_at']) : '—';
            $icons2 = ['active'=>'✅','disabled'=>'🔴','expired'=>'⏰','removed'=>'🗑'];
            $ic = $icons2[$c['status']] ?? '❓';
            $msg .= "{$ic} <code>{$c['username_config']}</code> | {$c['volume_gb']}GB | {$exp}\n";
        }
    }

    $btns = [
        [
            ['text' => '💳 شارژ کیف پول', 'callback_data' => "cb_charge_{$b['id']}"],
            ['text' => '📡 تنظیم اینباند', 'callback_data' => "cb_set_inbound_{$b['id']}"],
        ],
        [['text' => '🔙 بستن', 'callback_data' => 'cb_close_report']],
    ];
    Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $btns]));
    AnswerCallbackQuery($callback_query_id);
}

if ($datain === 'cb_close_report') {
    Editmessagetext($from_id, $message_id, "🔙 بسته شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id);
}

// ================================================================
// فاز ۳ — ارسال پیام همگانی به نماینده‌ها از ربات مادر
// ================================================================

if ($text === '📢 پیام به نماینده‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $kb_bcast = json_encode(['keyboard' => [
        [['text' => '📢 پیام به همه نماینده‌ها'], ['text' => '✅ پیام به نماینده‌های فعال']],
        [['text' => $textbotlang['Admin']['Back-Adminment']]],
    ], 'resize_keyboard' => true]);
    sendmessage($from_id, "📢 <b>ارسال پیام به نماینده‌ها</b>\n\nنوع ارسال را انتخاب کنید:", $kb_bcast, 'HTML');
}

if ($text === '📢 پیام به همه نماینده‌ها') {
    if (!is_super_admin($from_id)) return;
    sendmessage($from_id, "📢 متن پیام را ارسال کنید:\n(به همه نماینده‌ها ارسال می‌شود)", $backadmin, 'HTML');
    step('cb_broadcast_all', $from_id);
}

if ($text === '✅ پیام به نماینده‌های فعال') {
    if (!is_super_admin($from_id)) return;
    sendmessage($from_id, "✅ متن پیام را ارسال کنید:\n(فقط به نماینده‌های فعال ارسال می‌شود)", $backadmin, 'HTML');
    step('cb_broadcast_active', $from_id);
}

if (in_array($user['step'], ['cb_broadcast_all', 'cb_broadcast_active'])) {
    if (!is_super_admin($from_id)) { step('home', $from_id); return; }
    $where_status = $user['step'] === 'cb_broadcast_active' ? "WHERE status='active'" : "";
    $bots = $pdo->query("SELECT bot_token, owner_id, bot_username FROM reseller_bot {$where_status}")->fetchAll(PDO::FETCH_ASSOC);

    $sent = 0; $failed = 0;
    foreach ($bots as $b) {
        $r = child_sendmessage($b['bot_token'], $b['owner_id'], $text, null, 'HTML');
        if ($r) $sent++; else $failed++;
        usleep(100000); // 100ms بین هر پیام
    }
    sendmessage($from_id,
        "📢 <b>ارسال پیام همگانی به نماینده‌ها:</b>\n\n✅ موفق: <b>{$sent}</b>\n❌ ناموفق: <b>{$failed}</b>",
        $mykeyboard, 'HTML');
    step('home', $from_id);
}

// ================================================================
// فاز ۳ — آپدیت cb_manage برای اضافه کردن دکمه‌های جدید
// ================================================================
// (دکمه گزارش و اینباند به callback موجود cb_manage اضافه شده‌اند)
// cb_manage_{id} → نمایش منوی مدیریت با دکمه‌های کامل

// آپدیت cb_manage با دکمه‌های کامل‌تر
if (preg_match('/^cb_manage_full_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) return;
    $bid = intval($m[1]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) return;

    $remain = max(0, $b['volume_limit'] - $b['volume_used']);
    $icons = ['active'=>'✅','pending'=>'⏳','blocked'=>'🚫'];
    $info  = "{$icons[$b['status']]} <b>@{$b['bot_username']}</b>\n\n"
           . "👤 نماینده: <code>{$b['owner_id']}</code>\n"
           . "🌐 پنل: <b>{$b['panel_name']}</b>\n"
           . "💳 کیف پول: <b>" . number_format($b['wallet']) . " تومان</b>\n"
           . "🔗 Webhook: " . ($b['webhook_set'] ? '✅' : '❌') . "\n\n"
           . "📦 حجم: " . _fmt_gb($remain) . "/" . _fmt_gb($b['volume_limit']) . "\n"
           . "🔢 کانفیگ: {$b['config_used']}" . ($b['config_limit']>0 ? "/{$b['config_limit']}" : '') . "\n"
           . "💵 قیمت/گیگ: " . number_format($b['price_per_gb']) . " | 📅 قیمت/ماه: " . number_format($b['price_per_month']) . " تومان";

    $bot_expire_at = (int)($b['expire_at'] ?? 0);
    if ($bot_expire_at > 0) {
        $days_left = ceil(($bot_expire_at - time()) / 86400);
        $info .= "\n⏳ انقضا: " . ($days_left > 0 ? "<b>{$days_left} روز مانده</b>" : "<b>منقضی شده</b>") . " (" . date('Y/m/d', $bot_expire_at) . ")";
    } else {
        $info .= "\n⏳ انقضا: <b>نامحدود</b>";
    }

    // نمایش سقف مصرف پنل
    $pvc_cap  = $b['panel_vol_cap']  ?? 0;
    $pvc_used = $b['panel_vol_used'] ?? 0;
    $pvc_sync = $b['panel_vol_last_sync'] ?? 0;
    if ($pvc_cap > 0) {
        $pvc_pct  = $pvc_cap > 0 ? round(($pvc_used / $pvc_cap) * 100, 1) : 0;
        $pvc_bar  = str_repeat('█', min(10, (int)($pvc_pct/10))) . str_repeat('░', max(0, 10 - (int)($pvc_pct/10)));
        $info .= "\n\n📊 <b>مصرف واقعی پنل:</b>\n"
               . "   [{$pvc_bar}] {$pvc_pct}%\n"
               . "   مصرف: <b>" . number_format($pvc_used, 2) . " GB</b> از <b>" . number_format($pvc_cap, 2) . " GB</b>\n"
               . "   آخرین sync: " . ($pvc_sync ? jdate('Y/m/d H:i', $pvc_sync) : '—');
    } else {
        $info .= "\n\n📊 سقف مصرف پنل: <b>تعریف نشده</b>";
    }

    $btns = [
        [
            ['text' => '📦 سقف حجم',    'callback_data' => "cb_set_vol_{$bid}"],
            ['text' => '🔢 سقف کانفیگ', 'callback_data' => "cb_set_cfg_{$bid}"],
        ],
        [
            ['text' => '⏳ تمدید زمان (روز)', 'callback_data' => "cb_extend_days_{$bid}"],
        ],
        [
            ['text' => '📊 سقف مصرف پنل', 'callback_data' => "cb_set_pvc_{$bid}"],
            ['text' => '🔄 سینک مصرف پنل', 'callback_data' => "cb_sync_pvc_{$bid}"],
        ],
        [
            ['text' => '💵 قیمت/گیگ',   'callback_data' => "cb_set_pgb_{$bid}"],
            ['text' => '📅 قیمت/ماه',   'callback_data' => "cb_set_pm_{$bid}"],
        ],
        [
            ['text' => '💳 شارژ کیف پول',  'callback_data' => "cb_charge_{$bid}"],
            ['text' => '📡 تنظیم اینباند', 'callback_data' => "cb_set_inbound_{$bid}"],
        ],
        [
            ['text' => '📊 گزارش تفصیلی', 'callback_data' => "cb_report_{$bid}"],
            ['text' => '🔗 Webhook',        'callback_data' => "cb_webhook_{$bid}"],
        ],
        [
            ['text' => '🗑 حذف', 'callback_data' => "cb_delete_{$bid}"],
        ],
        [
            ['text' => ($b['status'] === 'pending' ? '✅ فعال‌سازی' : ($b['status'] === 'active' ? '🚫 بلاک' : '✅ فعال')), 'callback_data' => "cb_toggle_{$bid}"],
        ],
    ];
    Editmessagetext($from_id, $message_id, $info, json_encode(['inline_keyboard' => $btns]));
    AnswerCallbackQuery($callback_query_id);
}

// ================================================================
// فاز ۳ — تغییر پنل یک زیر ربات
// ================================================================

if (preg_match('/^cb_change_panel_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $panels = $pdo->query("SELECT name_panel, type FROM marzban_panel WHERE status='activepanel'")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($panels)) { AnswerCallbackQuery($callback_query_id, '❌ پنلی ثبت نشده', true); return; }
    $rows = [];
    foreach ($panels as $p) {
        $rows[] = [['text' => "📌 {$p['name_panel']} [{$p['type']}]", 'callback_data' => "cb_setpanel_{$bid}_" . base64_encode($p['name_panel'])]];
    }
    $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => "cb_manage_{$bid}"]];
    Editmessagetext($from_id, $message_id, "🌐 پنل جدید را انتخاب کنید:", json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}

if (preg_match('/^cb_setpanel_(\d+)_(.+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $bid = intval($m[1]);
    $panel_name = base64_decode($m[2]);
    $b = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=?");
    $b->execute([$bid]);
    $b = $b->fetch(PDO::FETCH_ASSOC);
    if (!$b) { AnswerCallbackQuery($callback_query_id, '❌'); return; }
    $pdo->prepare("UPDATE reseller_bot SET panel_name=?, allowed_inbounds=NULL WHERE id=?")->execute([$panel_name, $bid]);
    child_sendmessage($b['bot_token'], $b['owner_id'],
        "⚙️ پنل ربات شما به <b>{$panel_name}</b> تغییر یافت.",
        null, 'HTML');
    Editmessagetext($from_id, $message_id,
        "✅ پنل @{$b['bot_username']} به <b>{$panel_name}</b> تغییر یافت.\n⚠️ اینباندهای مجاز ریست شدند.",
        json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ پنل تغییر کرد', true);
}



// ================================================================
// مدیریت Pool پنل‌های نمایندگی
// ================================================================

if ($text === '🖥 Pool پنل‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $pools = $pdo->query("SELECT rpp.*, rb.bot_username FROM reseller_panel_pool rpp LEFT JOIN reseller_bot rb ON rpp.assigned_to = rb.bot_token ORDER BY rpp.id DESC")->fetchAll(PDO::FETCH_ASSOC);
    $total     = count($pools);
    $available = count(array_filter($pools, fn($p) => $p['status'] === 'available'));
    $assigned  = count(array_filter($pools, fn($p) => $p['status'] === 'assigned'));

    $msg  = "🖥 <b>Pool پنل‌های نمایندگی</b>

";
    $msg .= "✅ موجود: <b>{$available}</b> | 📌 اختصاص‌یافته: <b>{$assigned}</b> | 🔢 کل: <b>{$total}</b>

";
    $btns = [];
    foreach ($pools as $p) {
        $st_icon = ['available' => '✅', 'assigned' => '📌', 'disabled' => '🔴'][$p['status']] ?? '❓';
        $assigned_txt = $p['bot_username'] ? " → @{$p['bot_username']}" : '';
        $msg .= "{$st_icon} <b>{$p['name_panel']}</b>{$assigned_txt}
";
        $msg .= "   {$p['description']}

";
        $btns[] = [['text' => "{$st_icon} {$p['name_panel']}", 'callback_data' => "pool_manage_{$p['id']}"]];
    }
    $btns[] = [['text' => '➕ افزودن پنل به Pool', 'callback_data' => 'pool_add']];
    sendmessage($from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
}

// callback: افزودن پنل به pool
if ($datain === 'pool_add') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $panels = $pdo->query("SELECT name_panel FROM marzban_panel WHERE status='activepanel'")->fetchAll(PDO::FETCH_ASSOC);
    if (empty($panels)) { AnswerCallbackQuery($callback_query_id, '❌ پنلی ثبت نشده', true); return; }
    $rows = [];
    foreach ($panels as $p) {
        $rows[] = [['text' => "📌 {$p['name_panel']}", 'callback_data' => "pool_add_panel_" . base64_encode($p['name_panel'])]];
    }
    $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'pool_close']];
    Editmessagetext($from_id, $message_id, "➕ پنل مورد نظر را انتخاب کنید:", json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}

if (preg_match('/^pool_add_panel_(.+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $panel_name = base64_decode($m[1]);
    // بررسی تکراری نبودن
    $exists = $pdo->prepare("SELECT id FROM reseller_panel_pool WHERE name_panel=? AND status != 'disabled'");
    $exists->execute([$panel_name]);
    if ($exists->fetch()) {
        AnswerCallbackQuery($callback_query_id, '⚠️ این پنل قبلاً در pool هست', true); return;
    }
    $pdo->prepare("INSERT INTO reseller_panel_pool (name_panel, status, created_at) VALUES (?, 'available', ?)")->execute([$panel_name, time()]);
    Editmessagetext($from_id, $message_id, "✅ پنل <b>{$panel_name}</b> به pool اضافه شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ اضافه شد', true);
}

// مدیریت یه پنل از pool
if (preg_match('/^pool_manage_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pid = intval($m[1]);
    $p = $pdo->prepare("SELECT rpp.*, rb.bot_username FROM reseller_panel_pool rpp LEFT JOIN reseller_bot rb ON rpp.assigned_to = rb.bot_token WHERE rpp.id=?");
    $p->execute([$pid]);
    $p = $p->fetch(PDO::FETCH_ASSOC);
    if (!$p) { AnswerCallbackQuery($callback_query_id, '❌'); return; }

    $st_labels = ['available' => '✅ موجود', 'assigned' => '📌 اختصاص‌یافته', 'disabled' => '🔴 غیرفعال'];
    $msg  = "🖥 <b>پنل: {$p['name_panel']}</b>

";
    $msg .= "وضعیت: <b>" . ($st_labels[$p['status']] ?? $p['status']) . "</b>
";
    if ($p['bot_username']) $msg .= "اختصاص به: @{$p['bot_username']}
";
    $msg .= "توضیح: " . ($p['description'] ?: '—');

    $rows = [];
    if ($p['status'] === 'assigned') {
        $rows[] = [['text' => '🔓 آزاد کردن (برگشت به pool)', 'callback_data' => "pool_free_{$pid}"]];
    }
    if ($p['status'] !== 'disabled') {
        $rows[] = [['text' => '🔴 غیرفعال کردن', 'callback_data' => "pool_disable_{$pid}"]];
    } else {
        $rows[] = [['text' => '✅ فعال کردن', 'callback_data' => "pool_enable_{$pid}"]];
    }
    $rows[] = [['text' => '🗑 حذف از pool', 'callback_data' => "pool_delete_{$pid}"]];
    $rows[] = [['text' => '🔙 بستن', 'callback_data' => 'pool_close']];
    Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}

if (preg_match('/^pool_free_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_panel_pool SET status='available', assigned_to=NULL WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "✅ پنل آزاد شد و به pool برگشت.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ آزاد شد', true);
}

if (preg_match('/^pool_disable_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_panel_pool SET status='disabled' WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "🔴 پنل غیرفعال شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '🔴 غیرفعال شد', true);
}

if (preg_match('/^pool_enable_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_panel_pool SET status='available' WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "✅ پنل فعال شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ فعال شد', true);
}

if (preg_match('/^pool_delete_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("DELETE FROM reseller_panel_pool WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "🗑 پنل از pool حذف شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '🗑 حذف شد', true);
}

if ($datain === 'pool_close') {
    Editmessagetext($from_id, $message_id, "🔙 بسته شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id);
}

// ================================================================
// مدیریت Pool توکن ربات‌های زیرمجموعه (پنل نمایندگی)
// ================================================================

if ($text === '🤖 Pool ربات‌ها') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $tokens = $pdo->query("SELECT * FROM reseller_bot_token_pool ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    $total     = count($tokens);
    $available = count(array_filter($tokens, fn($t) => $t['status'] === 'available'));
    $assigned  = count(array_filter($tokens, fn($t) => $t['status'] === 'assigned'));

    $msg  = "🤖 <b>Pool توکن ربات‌های زیرمجموعه</b>\n\n";
    $msg .= "✅ موجود: <b>{$available}</b> | 📌 اختصاص‌یافته: <b>{$assigned}</b> | 🔢 کل: <b>{$total}</b>\n\n";
    $btns = [];
    foreach ($tokens as $t) {
        $st_icon = ['available' => '✅', 'assigned' => '📌', 'disabled' => '🔴'][$t['status']] ?? '❓';
        $msg .= "{$st_icon} <b>@{$t['bot_username']}</b> ({$t['bot_name']})\n";
        $msg .= "   👤 مدیر: <code>{$t['owner_admin_id']}</code>\n\n";
        $btns[] = [['text' => "{$st_icon} @{$t['bot_username']}", 'callback_data' => "btoken_manage_{$t['id']}"]];
    }
    $btns[] = [['text' => '➕ افزودن ربات به Pool', 'callback_data' => 'btoken_add']];
    sendmessage($from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
}

if ($datain === 'btoken_add') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    Editmessagetext($from_id, $message_id,
        "🔑 توکن ربات جدید را ارسال کنید (دریافت‌شده از @BotFather):\n\n<code>123456789:ABCdefGHIjklMNOpqrsTUVwxyz12345678</code>",
        json_encode(['inline_keyboard' => []]));
    step('admin_btoken_add_token', $from_id);
    AnswerCallbackQuery($callback_query_id);
}

if ($user['step'] === 'admin_btoken_add_token') {
    if (!is_super_admin($from_id)) return;
    $token = trim($text);
    if (!preg_match('/^\d{8,12}:[A-Za-z0-9_-]{35}$/', $token)) {
        sendmessage($from_id, "❌ توکن نامعتبر است. دوباره ارسال کنید:", null, 'HTML');
        return;
    }
    $exists = $pdo->prepare("SELECT id FROM reseller_bot_token_pool WHERE bot_token=?");
    $exists->execute([$token]);
    if ($exists->fetch()) {
        sendmessage($from_id, "❌ این توکن قبلاً در pool ثبت شده.", $mykeyboard, 'HTML');
        step('home', $from_id);
        return;
    }
    require_once 'child_botapi.php';
    $bot_info = child_get_bot_info($token);
    if (!$bot_info) {
        sendmessage($from_id, "❌ توکن نامعتبر است یا ربات در دسترس نیست. دوباره ارسال کنید:", null, 'HTML');
        return;
    }
    update("user", "Processing_value", json_encode([
        'bot_token'    => $token,
        'bot_username' => $bot_info['username'] ?? '',
        'bot_name'     => $bot_info['first_name'] ?? '',
    ]), "id", $from_id);
    sendmessage($from_id, "👤 آیدی عددی مدیر این ربات را ارسال کنید (آیدی عددی تلگرام):", null, 'HTML');
    step('admin_btoken_add_owner', $from_id);
}

if ($user['step'] === 'admin_btoken_add_owner') {
    if (!is_super_admin($from_id)) return;
    $owner_id = trim(preg_replace('/\D/', '', $text));
    if ($owner_id === '') {
        sendmessage($from_id, "❌ آیدی عددی نامعتبر است. دوباره ارسال کنید:", null, 'HTML');
        return;
    }
    $pv = json_decode($user['Processing_value'] ?? '{}', true);
    if (empty($pv['bot_token'])) { step('home', $from_id); return; }

    $pdo->prepare(
        "INSERT INTO reseller_bot_token_pool (bot_token, bot_username, bot_name, owner_admin_id, status, created_at)
         VALUES (?,?,?,?,'available',?)"
    )->execute([$pv['bot_token'], $pv['bot_username'], $pv['bot_name'], $owner_id, time()]);

    $msg  = "✅ ربات به Pool اضافه شد.\n\n";
    $msg .= "🤖 نام: <b>{$pv['bot_name']}</b>\n";
    $msg .= "📛 یوزرنیم: @{$pv['bot_username']}\n";
    $msg .= "👤 آیدی مدیر: <code>{$owner_id}</code>";
    sendmessage($from_id, $msg, $mykeyboard, 'HTML');
    step('home', $from_id);
    update("user", "Processing_value", "", "id", $from_id);
}

if (preg_match('/^btoken_manage_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $tid = intval($m[1]);
    $t = $pdo->prepare("SELECT * FROM reseller_bot_token_pool WHERE id=?");
    $t->execute([$tid]);
    $t = $t->fetch(PDO::FETCH_ASSOC);
    if (!$t) { AnswerCallbackQuery($callback_query_id, '❌'); return; }

    $st_labels = ['available' => '✅ موجود', 'assigned' => '📌 اختصاص‌یافته', 'disabled' => '🔴 غیرفعال'];
    $msg  = "🤖 <b>ربات: @{$t['bot_username']}</b>\n\n";
    $msg .= "📛 نام: <b>{$t['bot_name']}</b>\n";
    $msg .= "👤 آیدی مدیر: <code>{$t['owner_admin_id']}</code>\n";
    $msg .= "وضعیت: <b>" . ($st_labels[$t['status']] ?? $t['status']) . "</b>\n";
    if ($t['assigned_to']) $msg .= "اختصاص به سفارش: <code>{$t['assigned_to']}</code>\n";

    $rows = [];
    if ($t['status'] === 'assigned') {
        $rows[] = [['text' => '🔓 آزاد کردن (برگشت به pool)', 'callback_data' => "btoken_free_{$tid}"]];
    }
    if ($t['status'] !== 'disabled') {
        $rows[] = [['text' => '🔴 غیرفعال کردن', 'callback_data' => "btoken_disable_{$tid}"]];
    } else {
        $rows[] = [['text' => '✅ فعال کردن', 'callback_data' => "btoken_enable_{$tid}"]];
    }
    $rows[] = [['text' => '🗑 حذف از pool', 'callback_data' => "btoken_delete_{$tid}"]];
    $rows[] = [['text' => '🔙 بستن', 'callback_data' => 'pool_close']];
    Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
    AnswerCallbackQuery($callback_query_id);
}

if (preg_match('/^btoken_free_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_bot_token_pool SET status='available', assigned_to=NULL WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "✅ ربات آزاد شد و به pool برگشت.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ آزاد شد', true);
}

if (preg_match('/^btoken_disable_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_bot_token_pool SET status='disabled' WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "🔴 ربات غیرفعال شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '🔴 غیرفعال شد', true);
}

if (preg_match('/^btoken_enable_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("UPDATE reseller_bot_token_pool SET status='available' WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "✅ ربات فعال شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '✅ فعال شد', true);
}

if (preg_match('/^btoken_delete_(\d+)$/', $datain, $m)) {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $pdo->prepare("DELETE FROM reseller_bot_token_pool WHERE id=?")->execute([$m[1]]);
    Editmessagetext($from_id, $message_id, "🗑 ربات از pool حذف شد.", json_encode(['inline_keyboard' => []]));
    AnswerCallbackQuery($callback_query_id, '🗑 حذف شد', true);
}

// ================================================================
// تنظیمات «پنل نمایندگی» — نمایش دکمه + متن معرفی
// (تنظیمات «کانفیگ نمایندگی» چون آن سیستم غیرفعال شده حذف شدند)
// ================================================================

if ($text === '⚙️ تنظیمات پنل نمایندگی') {
    if (!is_super_admin($from_id)) { sendmessage($from_id, "⛔ دسترسی ندارید.", $mykeyboard, 'HTML'); return; }
    $s = select('setting', '*');
    $status_txt = ($s['reseller_status'] ?? 'off') === 'on' ? '✅ فعال' : '🔴 غیرفعال';
    $msg  = "⚙️ <b>تنظیمات پنل نمایندگی</b>\n\n";
    $msg .= "🔘 نمایش دکمه «🤝 پنل نمایندگی» به همه کاربران: <b>{$status_txt}</b>\n";
    $kb = json_encode(['inline_keyboard' => [
        [['text' => ($s['reseller_status'] ?? 'off') === 'on' ? '🔴 مخفی کردن دکمه برای همه' : '✅ نمایش دکمه برای همه',
          'callback_data' => 'admin_rcfg_toggle_visibility']],
        [['text' => '📝 متن معرفی پنل نمایندگی', 'callback_data' => 'admin_rcfg_set_panelintro']],
    ]]);
    sendmessage($from_id, $msg, $kb, 'HTML');
}

if ($datain === 'admin_rcfg_toggle_visibility') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    $s   = select('setting', 'reseller_status');
    $new = ($s['reseller_status'] ?? 'off') === 'on' ? 'off' : 'on';
    update('setting', 'reseller_status', $new);
    AnswerCallbackQuery($callback_query_id, $new === 'on' ? '✅ نمایش فعال شد' : '🔴 نمایش غیرفعال شد', true);
}

if ($datain === 'admin_rcfg_set_panelintro') {
    if (!is_super_admin($from_id)) { AnswerCallbackQuery($callback_query_id, '⛔'); return; }
    sendmessage($from_id, "📝 متن معرفی «پنل نمایندگی» را ارسال کنید (HTML مجاز است):", null, 'HTML');
    step('admin_rcfg_panelintro', $from_id);
    AnswerCallbackQuery($callback_query_id);
}
if ($user['step'] === 'admin_rcfg_panelintro') {
    if (!is_super_admin($from_id)) return;
    update('setting', 'reseller_panel_intro_text', $text);
    sendmessage($from_id, "✅ متن ثبت شد.", $mykeyboard, 'HTML');
    step('home', $from_id);
}

