<?php
// ================================================================
// cron/reseller_bot_expire.php
//
// چک انقضای مدت اعتبار خود پنل نمایندگی اختصاصی (reseller_bot.expire_at)
// — جدا از انقضای کانفیگ‌های تک‌تک مشتریان (که در child_bot_expire.php است)
//
// رفتار:
//   - وقتی expire_at گذشت → status='blocked' + اطلاع به نماینده و ادمین
//     (پنل حذف نمی‌شود؛ فقط مسدود می‌شود تا ادمین یا خود نماینده تمدید کند)
//   - ۳ روز مانده به انقضا → هشدار یک‌بار به نماینده
//
// crontab (هر ساعت):
// 0 * * * * php /path/to/cron/reseller_bot_expire.php >> /tmp/reseller_bot_expire.log 2>&1
// ================================================================

date_default_timezone_set('Asia/Tehran');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../child_botapi.php';

$now = time();

// ----------------------------------------------------------------
// ۱) پنل‌هایی که مدت اعتبارشان گذشته و هنوز active هستند → blocked
// ----------------------------------------------------------------
$expired = $pdo->query("
    SELECT *
    FROM reseller_bot
    WHERE status = 'active'
      AND expire_at > 0
      AND expire_at < {$now}
")->fetchAll(PDO::FETCH_ASSOC);

$blocked_count = 0;
foreach ($expired as $b) {
    $pdo->prepare("UPDATE reseller_bot SET status='blocked', expire_warned=0 WHERE id=?")
        ->execute([$b['id']]);

    child_sendmessage($b['bot_token'], $b['owner_id'],
        "🚫 <b>مدت اعتبار پنل نمایندگی شما به پایان رسید</b>\n\n" .
        "پنل شما مسدود شد. برای تمدید، از بخش 🤝 پنل نمایندگی → ⏳ افزایش زمان اقدام کنید " .
        "یا با ادمین تماس بگیرید.",
        null, 'HTML');

    sendmessage($adminnumber,
        "🚫 <b>پنل نمایندگی منقضی و مسدود شد</b>\n\n" .
        "👤 نماینده: <code>{$b['owner_id']}</code>\n" .
        "🤖 ربات: @{$b['bot_username']}\n" .
        "🌐 پنل: <b>{$b['panel_name']}</b>",
        null, 'HTML');

    echo "BLOCKED: @{$b['bot_username']} (owner: {$b['owner_id']})\n";
    $blocked_count++;
}

// ----------------------------------------------------------------
// ۲) هشدار ۳ روز مانده به انقضا (فقط یک‌بار، با ستون expire_warned)
// ----------------------------------------------------------------
$warn_time = $now + (3 * 86400);
$soon_expire = $pdo->query("
    SELECT *
    FROM reseller_bot
    WHERE status = 'active'
      AND expire_at > {$now}
      AND expire_at <= {$warn_time}
      AND expire_warned = 0
")->fetchAll(PDO::FETCH_ASSOC);

$warned_count = 0;
foreach ($soon_expire as $b) {
    $days_left = max(1, ceil(($b['expire_at'] - $now) / 86400));
    child_sendmessage($b['bot_token'], $b['owner_id'],
        "⚠️ <b>هشدار انقضای پنل نمایندگی</b>\n\n" .
        "⏳ <b>{$days_left} روز</b> تا پایان مدت اعتبار پنل شما باقی مانده.\n\n" .
        "برای تمدید، از بخش 🤝 پنل نمایندگی → ⏳ افزایش زمان اقدام کنید.",
        null, 'HTML');
    $pdo->prepare("UPDATE reseller_bot SET expire_warned=1 WHERE id=?")->execute([$b['id']]);
    echo "WARNED: @{$b['bot_username']} ({$days_left} days left)\n";
    $warned_count++;
}

// ----------------------------------------------------------------
// ۳) ریست پرچم هشدار برای پنل‌هایی که تمدید شدند (دیگر در بازه ۳ روزه نیستند)
//    تا اگر دوباره به محدوده هشدار نزدیک شدند، هشدار جدید دریافت کنند.
// ----------------------------------------------------------------
$pdo->exec("
    UPDATE reseller_bot
    SET expire_warned = 0
    WHERE expire_warned = 1
      AND (expire_at = 0 OR expire_at > {$warn_time})
");

echo "\n=== Done ===\n";
echo "Blocked: {$blocked_count} | Warned: {$warned_count}\n";
