<?php
// cron/child_bot_daily_report.php
// هر روز صبح اجرا شه - گزارش روزانه به هر نماینده
date_default_timezone_set('Asia/Tehran');
require_once '../config.php';
require_once '../functions.php';
require_once '../child_botapi.php';
require_once '../jdf.php';

$now       = time();
$today_start = mktime(0, 0, 0);
$yesterday   = $today_start - 86400;

$bots = $pdo->query("SELECT * FROM reseller_bot WHERE status='active'")->fetchAll(PDO::FETCH_ASSOC);

foreach ($bots as $b) {
    // فروش امروز
    $today_sales = $pdo->prepare("SELECT COUNT(*), SUM(price) FROM child_bot_invoice WHERE bot_token=? AND created_at >= ?");
    $today_sales->execute([$b['bot_token'], $today_start]);
    [$today_count, $today_income] = $today_sales->fetch(PDO::FETCH_NUM);
    $today_income = $today_income ?? 0;

    // کل
    $total_active = $pdo->prepare("SELECT COUNT(*) FROM child_bot_invoice WHERE bot_token=? AND status='active'");
    $total_active->execute([$b['bot_token']]);
    $total_active = $total_active->fetchColumn();

    $remain_gb  = max(0, $b['volume_limit'] - $b['volume_used']);
    $remain_cfg = $b['config_limit'] > 0 ? max(0, $b['config_limit'] - $b['config_used']) : 'نامحدود';

    // هشدار حجم کم (زیر ۱۰٪)
    $warn = '';
    if ($b['volume_limit'] > 0 && $remain_gb < ($b['volume_limit'] * 0.10)) {
        $warn = "\n\n⚠️ <b>هشدار:</b> حجم باقیمانده کمتر از ۱۰٪ است!";
    }

    $msg  = "📊 <b>گزارش روزانه ربات @{$b['bot_username']}</b>\n";
    $msg .= "📅 " . jdate('Y/m/d', $now) . "\n\n";
    $msg .= "🛒 فروش امروز: <b>{$today_count}</b> کانفیگ | <b>" . number_format($today_income) . " تومان</b>\n";
    $msg .= "✅ کانفیگ فعال: <b>{$total_active}</b>\n\n";
    $msg .= "📦 حجم باقی: <b>";
    $msg .= $b['volume_limit'] >= 1024 ? round($remain_gb/1024, 2).' TB' : $remain_gb.' GB';
    $msg .= "</b> از <b>";
    $msg .= $b['volume_limit'] >= 1024 ? round($b['volume_limit']/1024, 2).' TB' : $b['volume_limit'].' GB';
    $msg .= "</b>\n";
    $msg .= "🔢 کانفیگ باقی: <b>{$remain_cfg}</b>\n";
    $msg .= "💳 کیف پول: <b>" . number_format($b['wallet']) . " تومان</b>";
    $msg .= $warn;

    child_sendmessage($b['bot_token'], $b['owner_id'], $msg, null, 'HTML');
    echo "Report sent to @{$b['bot_username']}\n";
    usleep(200000);
}

echo "Daily reports done. Total bots: " . count($bots) . "\n";
