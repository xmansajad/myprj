<?php
// cron/child_bot_expire.php
// هر ساعت اجرا شه
// غیرفعال یا حذف کانفیگ‌های منقضی زیر ربات‌ها
date_default_timezone_set('Asia/Tehran');
require_once '../config.php';
require_once '../functions.php';
require_once '../panels.php';
require_once '../remnawave.php';
require_once '../child_botapi.php';
require_once '../jdf.php';

$ManagePanel = new ManagePanel();
$now = time();

$expired = $pdo->query("
    SELECT ci.*, rb.auto_disable_days, rb.panel_name, rb.bot_token, rb.owner_id, rb.bot_username
    FROM child_bot_invoice ci
    JOIN reseller_bot rb ON ci.bot_token = rb.bot_token
    WHERE ci.status IN ('active','expired')
      AND ci.expire_at > 0
      AND ci.expire_at < {$now}
      AND rb.status = 'active'
")->fetchAll(PDO::FETCH_ASSOC);

$disabled_count = 0;
$removed_count  = 0;

foreach ($expired as $c) {
    $grace = $c['auto_disable_days'] * 86400;
    $overdue = $now - $c['expire_at'];

    if ($overdue >= $grace) {
        // دوره grace تموم شده → حذف از پنل
        $du = $ManagePanel->DataUser($c['panel_name'], $c['username_config']);
        if (isset($du['status'])) {
            $ManagePanel->RemoveUser($c['panel_name'], $c['username_config']);
        }
        $pdo->prepare("UPDATE child_bot_invoice SET status='removed' WHERE id=?")
            ->execute([$c['id']]);
        $pdo->prepare("UPDATE reseller_bot SET config_used=GREATEST(0,config_used-1) WHERE bot_token=?")
            ->execute([$c['bot_token']]);

        // اطلاع به مشتری
        child_sendmessage($c['bot_token'], $c['user_id'],
            "🗑 <b>کانفیگ شما حذف شد</b>\n\n📌 {$c['product_name']}\n\nاشتراک شما منقضی شده و بعد از {$c['auto_disable_days']} روز حذف گردید.\nبرای تمدید از ربات اقدام کنید.",
            null, 'HTML');

        // اطلاع به نماینده (owner)
        child_sendmessage($c['bot_token'], $c['owner_id'],
            "🗑 کانفیگ <code>{$c['username_config']}</code> منقضی و حذف شد.\nکاربر: <code>{$c['user_id']}</code>",
            null, 'HTML');

        echo "REMOVED: {$c['username_config']} (bot: @{$c['bot_username']})\n";
        $removed_count++;

    } elseif ($c['status'] === 'active') {
        // هنوز در grace period → فقط غیرفعال کن
        $du = $ManagePanel->DataUser($c['panel_name'], $c['username_config']);
        if (($du['status'] ?? '') === 'active') {
            $ManagePanel->Disableuser($c['panel_name'], $c['username_config']);
        }
        $pdo->prepare("UPDATE child_bot_invoice SET status='expired' WHERE id=?")
            ->execute([$c['id']]);

        $days_left = max(0, ceil(($c['expire_at'] + $grace - $now) / 86400));

        // اطلاع به مشتری
        child_sendmessage($c['bot_token'], $c['user_id'],
            "⏰ <b>اشتراک شما منقضی شد</b>\n\n📌 {$c['product_name']}\n\n⚠️ کانفیگ غیرفعال شد.\nتا <b>{$days_left} روز</b> دیگر کانفیگ حذف می‌شود.",
            null, 'HTML');

        echo "DISABLED: {$c['username_config']} (bot: @{$c['bot_username']}, grace: {$days_left} days left)\n";
        $disabled_count++;
    }
}

// ---- هشدار نزدیک به انقضا (۳ روز مانده) ----
$warn_time = $now + (3 * 86400);
$soon_expire = $pdo->query("
    SELECT ci.*, rb.bot_token, rb.bot_username
    FROM child_bot_invoice ci
    JOIN reseller_bot rb ON ci.bot_token = rb.bot_token
    WHERE ci.status = 'active'
      AND ci.expire_at > {$now}
      AND ci.expire_at <= {$warn_time}
      AND rb.status = 'active'
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($soon_expire as $c) {
    $days_left = max(1, ceil(($c['expire_at'] - $now) / 86400));
    child_sendmessage($c['bot_token'], $c['user_id'],
        "⚠️ <b>هشدار انقضا</b>\n\n📌 {$c['product_name']}\n⏳ <b>{$days_left} روز</b> تا انقضای اشتراک شما باقی مانده.\n\nبرای تمدید اقدام کنید.",
        null, 'HTML');
}

echo "\n=== Done ===\n";
echo "Disabled: $disabled_count | Removed: $removed_count | Warned: " . count($soon_expire) . "\n";
