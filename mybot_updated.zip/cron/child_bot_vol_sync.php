<?php
// ================================================================
// cron/child_bot_vol_sync.php
//
// مصرف واقعی کل پنل رو لحظه‌ای از Remnawave میگیره
// endpoint: GET /api/system/stats/bandwidth → calendarMonth
//
// یه call به پنل — بدون loop روی تک‌تک کانفیگ‌ها
//
// crontab (هر ۱ دقیقه):
// * * * * * php /path/to/cron/child_bot_vol_sync.php >> /tmp/volcap.log 2>&1
// ================================================================

date_default_timezone_set('Asia/Tehran');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';
require_once __DIR__ . '/../panels.php';
require_once __DIR__ . '/../child_botapi.php';
require_once __DIR__ . '/../remnawave.php';

$ManagePanel = new ManagePanel();
$now         = time();

// فقط زیر ربات‌های فعال که سقف پنل دارن
$bots = $pdo->query("
    SELECT rb.*
    FROM reseller_bot rb
    WHERE rb.status = 'active'
      AND rb.panel_vol_cap > 0
      AND rb.panel_name != ''
")->fetchAll(PDO::FETCH_ASSOC);

if (empty($bots)) {
    echo "[" . date('H:i:s') . "] No bots with panel_vol_cap. Exit.\n";
    exit;
}

// گروه‌بندی بر اساس پنل — هر پنل فقط یه API call
$by_panel = [];
foreach ($bots as $bot) {
    $by_panel[$bot['panel_name']][] = $bot;
}

foreach ($by_panel as $panel_name => $panel_bots) {

    // یه call — مصرف ماه جاری پنل
    $bw = $ManagePanel->GetPanelBandwidth($panel_name);

    if (!empty($bw['error'])) {
        echo "[" . date('H:i:s') . "] Panel [{$panel_name}] ERROR: {$bw['error']}\n";
        continue;
    }

    $total_gb = $bw['total_gb'] ?? round(($bw['total_bytes'] ?? 0) / 1073741824, 3);
    $source   = $bw['source']   ?? 'unknown';

    echo "[" . date('H:i:s') . "] Panel [{$panel_name}] ({$source}): {$total_gb} GB\n";

    foreach ($panel_bots as $bot) {
        $cap_gb   = (float)$bot['panel_vol_cap'];
        $old_used = (float)$bot['panel_vol_used'];
        $warn_pct = 0.90;

        // ذخیره آپدیت شده
        $pdo->prepare(
            "UPDATE reseller_bot SET panel_vol_used=?, panel_vol_last_sync=? WHERE bot_token=?"
        )->execute([$total_gb, $now, $bot['bot_token']]);

        $pct = $cap_gb > 0 ? round(($total_gb / $cap_gb) * 100, 1) : 0;
        echo "  Bot @{$bot['bot_username']}: {$total_gb}/{$cap_gb} GB ({$pct}%)\n";

        // ============================================================
        // به سقف رسید → فقط هشدار. غیرفعال‌سازی به عهده‌ی خود پنل
        // (Remnawave/Marzban) است، نه کرون ربات.
        // ============================================================
        if ($total_gb >= $cap_gb) {

            $was_already_capped = ($old_used >= $cap_gb);

            if (!$was_already_capped) {
                // اطلاع به نماینده از طریق زیر ربات
                child_sendmessage(
                    $bot['bot_token'],
                    $bot['owner_id'],
                    "🚨 <b>سقف حجم ماهانه پنل پر شد!</b>\n\n"
                    . "📊 مصرف ماه جاری: <b>" . number_format($total_gb, 2) . " GB</b>\n"
                    . "📦 سقف تعیین‌شده: <b>" . number_format($cap_gb, 2) . " GB</b>\n\n"
                    . "⚠️ مدیریت غیرفعال‌سازی سرویس‌ها بر عهده پنل است.",
                    null,
                    'HTML'
                );

                // اطلاع به ادمین مادر
                sendmessage(
                    $adminnumber,
                    "🚨 <b>سقف حجم پنل پر شد</b>\n\n"
                    . "🤖 ربات: @{$bot['bot_username']}\n"
                    . "🌐 پنل: <b>{$panel_name}</b>\n"
                    . "📊 مصرف: <b>" . number_format($total_gb, 2) . " GB</b> / <b>" . number_format($cap_gb, 2) . " GB</b>",
                    null,
                    'HTML'
                );

                echo "  → 🚨 CAP HIT: notified (no disable action taken)\n";
            } else {
                echo "  → 🚨 CAP (already notified, no re-notify)\n";
            }

        // ============================================================
        // نزدیک به سقف (۹۰٪) → هشدار یک‌بار
        // ============================================================
        } elseif ($total_gb >= ($cap_gb * $warn_pct)) {

            $old_pct = $cap_gb > 0 ? $old_used / $cap_gb : 0;

            if ($old_pct < $warn_pct) {
                child_sendmessage(
                    $bot['bot_token'],
                    $bot['owner_id'],
                    "⚠️ <b>هشدار: {$pct}% از سقف حجم پنل مصرف شده</b>\n\n"
                    . "📊 مصرف ماه جاری: <b>" . number_format($total_gb, 2) . " GB</b> از <b>" . number_format($cap_gb, 2) . " GB</b>\n"
                    . "🔋 باقیمانده: <b>" . number_format($cap_gb - $total_gb, 2) . " GB</b>\n\n"
                    . "در صورت نیاز، سقف را از ادمین اصلی افزایش دهید.",
                    null,
                    'HTML'
                );
                echo "  → ⚠️ 90% WARNING sent\n";
            }

        } else {
            // زیر سقف و زیر آستانه هشدار → کاری لازم نیست.
            // غیرفعال/فعال‌سازی سرویس‌ها دیگر توسط این کرون انجام نمی‌شود؛
            // مدیریت آن کاملاً بر عهده‌ی خود پنل (Remnawave/Marzban) است.
        }
    }
}

echo "[" . date('H:i:s') . "] Done. Panels: " . count($by_panel) . ", Bots: " . count($bots) . "\n";
