<?php
// cron/reseller_expire.php
// ⚠️ سیستم نمایندگی کلاسیک غیرفعال شده — این کرون دیگر نباید اجرا شود.
// در صورت نیاز به بازگرداندن سیستم نمایندگی کلاسیک، این خط را حذف کنید.
exit("reseller_expire: سیستم نمایندگی کلاسیک غیرفعال است.\n");

// هر ساعت اجرا شه: غیرفعال یا حذف کانفیگ‌های منقضی نمایندگان
date_default_timezone_set('Asia/Tehran');
require_once '../config.php';
require_once '../botapi.php';
require_once '../panels.php';
require_once '../functions.php';
require_once '../reseller.php';

$ManagePanel = new ManagePanel();

// پیدا کردن کانفیگ‌های منقضی
$now = time();
$expired = $pdo->query("
    SELECT ri.*, r.auto_disable_days, r.panel_name, r.id_user as reseller_uid
    FROM reseller_invoice ri
    JOIN reseller r ON ri.id_reseller = r.id_user
    WHERE ri.status = 'active'
      AND ri.expire_at > 0
      AND ri.expire_at < $now
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($expired as $c) {
    $grace_seconds = $c['auto_disable_days'] * 86400;
    $overdue = $now - $c['expire_at'];

    if ($overdue >= $grace_seconds) {
        // زمان grace تموم شده → حذف
        $du = $ManagePanel->DataUser($c['panel_name'], $c['username']);
        if (isset($du['status'])) {
            $ManagePanel->RemoveUser($c['panel_name'], $c['username']);
        }
        $pdo->prepare("UPDATE reseller_invoice SET status='removed' WHERE id=?")->execute([$c['id']]);
        $pdo->prepare("UPDATE reseller SET config_used=GREATEST(0,config_used-1) WHERE id_user=?")->execute([$c['reseller_uid']]);
        // اطلاع به نماینده
        sendmessage($c['reseller_uid'],
            "🗑 کانفیگ <code>{$c['username']}</code> ({$c['product_name']}) به دلیل انقضا حذف شد.",
            null, 'HTML');
        echo "REMOVED: {$c['username']}\n";
    } else {
        // هنوز در دوره grace → غیرفعال
        $du = $ManagePanel->DataUser($c['panel_name'], $c['username']);
        if (isset($du['status']) && $du['status'] == 'active') {
            $ManagePanel->Disableuser($c['panel_name'], $c['username']);
            $pdo->prepare("UPDATE reseller_invoice SET status='expired' WHERE id=?")->execute([$c['id']]);
            sendmessage($c['reseller_uid'],
                "⏰ کانفیگ <code>{$c['username']}</code> منقضی شد و غیرفعال گردید.\n\nبرای تمدید از پنل نمایندگی اقدام کنید.",
                null, 'HTML');
            echo "DISABLED: {$c['username']}\n";
        }
    }
}
echo "Done. Processed " . count($expired) . " expired configs.\n";
