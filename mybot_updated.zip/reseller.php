<?php
// ================================================================
// reseller.php — سیستم نمایندگی کامل
// ================================================================

if (!defined('RESELLER_LOADED')) define('RESELLER_LOADED', true);
require_once 'child_botapi.php';

// ================================================================
// توابع کمکی
// ================================================================
if (!function_exists('get_reseller')) {
    function get_reseller($user_id) {
        global $pdo;
        $s = $pdo->prepare("SELECT * FROM reseller WHERE id_user = ?");
        $s->execute([$user_id]);
        return $s->fetch(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('format_gb')) {
    function format_gb($gb) {
        if ($gb >= 1024) return round($gb / 1024, 2) . ' TB';
        return $gb . ' GB';
    }
}

if (!function_exists('reseller_remaining_gb')) {
    function reseller_remaining_gb($user_id) {
        $r = get_reseller($user_id);
        if (!$r) return 0;
        return max(0, $r['volume_limit'] - $r['volume_used']);
    }
}

function reseller_remaining_configs($user_id) {
    $r = get_reseller($user_id);
    if (!$r || $r['config_limit'] == 0) return PHP_INT_MAX;
    return max(0, $r['config_limit'] - $r['config_used']);
}

function reseller_status_text($status) {
    return ['active' => '✅ فعال', 'pending' => '⏳ در انتظار', 'blocked' => '🚫 مسدود'][$status] ?? $status;
}

// ================================================================
// بخش کاربر (نماینده)
// ================================================================
function handle_reseller_user($from_id, $text, $datain, $user, $keyboard)
{
    global $pdo, $textbotlang, $admin_ids, $ManagePanel;

    // کیبوردهای نماینده
    $kb_main = json_encode(['keyboard' => [
        [['text' => '📦 محصولات من'], ['text' => '⚙️ ساخت کانفیگ']],
        [['text' => '👥 مدیریت کانفیگ‌ها'], ['text' => '📊 گزارش فروش']],
        [['text' => '📈 افزایش سقف'], ['text' => '💰 کیف پول']],
        [['text' => '📋 پنل‌های من']],
        [['text' => $textbotlang['users']['backhome']]],
    ], 'resize_keyboard' => true]);

    $kb_back = json_encode(['keyboard' => [[['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]);

    $reseller = get_reseller($from_id);

    // ---- مرحله ورود تعداد گیگابایت برای افزایش حجم پنل نمایندگی ----
    if ($user['step'] == 'rb_enter_extend_vol') {
        $pv  = json_decode($user['Processing_value'], true);
        $rid = $pv['rb_id'] ?? 0;
        $rb  = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=? AND owner_id=?");
        $rb->execute([$rid, $from_id]);
        $rb  = $rb->fetch(PDO::FETCH_ASSOC);
        if (!$rb) { sendmessage($from_id, "❌ پنل یافت نشد.", $keyboard, 'HTML'); step('home', $from_id); return true; }

        if (!ctype_digit($text) || intval($text) <= 0) {
            sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]), 'HTML');
            return true;
        }
        $gb    = intval($text);
        $total = $gb * $rb['price_per_gb'];
        if ($rb['wallet'] < $total) {
            sendmessage($from_id, "❌ موجودی کیف پول کافی نیست.\n\nموجودی: <b>" . number_format($rb['wallet']) . " تومان</b>\nنیاز: <b>" . number_format($total) . " تومان</b>", json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]), 'HTML');
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot SET wallet=wallet-?, volume_limit=volume_limit+? WHERE id=?")
            ->execute([$total, $gb, $rb['id']]);

        sendmessage($from_id,
            "✅ <b>" . format_gb($gb) . "</b> به حجم پنل نمایندگی شما اضافه شد.\n💳 مبلغ کسرشده: <b>" . number_format($total) . " تومان</b>",
            $keyboard, 'HTML');
        step('home', $from_id);
        return true;
    }

    // ---- مرحله ورود تعداد روز برای افزایش زمان پنل نمایندگی ----
    if ($user['step'] == 'rb_enter_extend_days') {
        $pv  = json_decode($user['Processing_value'], true);
        $rid = $pv['rb_id'] ?? 0;
        $rb  = $pdo->prepare("SELECT * FROM reseller_bot WHERE id=? AND owner_id=?");
        $rb->execute([$rid, $from_id]);
        $rb  = $rb->fetch(PDO::FETCH_ASSOC);
        if (!$rb) { sendmessage($from_id, "❌ پنل یافت نشد.", $keyboard, 'HTML'); step('home', $from_id); return true; }

        if (!ctype_digit($text) || intval($text) <= 0) {
            sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]), 'HTML');
            return true;
        }
        $days  = intval($text);
        $total = (int)ceil($days / 30 * $rb['price_per_month']);
        if ($rb['wallet'] < $total) {
            sendmessage($from_id, "❌ موجودی کیف پول کافی نیست.\n\nموجودی: <b>" . number_format($rb['wallet']) . " تومان</b>\nنیاز: <b>" . number_format($total) . " تومان</b>", json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]), 'HTML');
            return true;
        }

        $base       = max(time(), (int)$rb['expire_at']);
        $new_expire = $base + $days * 86400;
        $pdo->prepare("UPDATE reseller_bot SET wallet=wallet-?, expire_at=?, expire_warned=0 WHERE id=?")
            ->execute([$total, $new_expire, $rb['id']]);

        sendmessage($from_id,
            "✅ <b>{$days} روز</b> به مدت اعتبار پنل نمایندگی شما اضافه شد.\n⏳ تاریخ انقضای جدید: <b>" . date('Y/m/d', $new_expire) . "</b>\n💳 مبلغ کسرشده: <b>" . number_format($total) . " تومان</b>",
            $keyboard, 'HTML');
        step('home', $from_id);
        return true;
    }

    // ---- هاب پنل نمایندگی ----
    if ($text == '🤝 پنل نمایندگی') {
        $info  = "🤝 <b>پنل نمایندگی</b>\n\n";
        $info .= "یکی از گزینه‌های زیر را انتخاب کنید:";
        $rows = [];

        // ---- وضعیت درخواست پنل نمایندگی (ربات اختصاصی) ----
        $bot_req = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE buyer_id=? ORDER BY created_at DESC LIMIT 1");
        $bot_req->execute([$from_id]);
        $bot_req = $bot_req->fetch(PDO::FETCH_ASSOC);
        if ($bot_req && $bot_req['delivered'] == 1 && $bot_req['payment_status'] == 'paid') {
            $rows[] = [['text' => '🖥 پنل نمایندگی (فعال - مشاهده سرویس‌ها)', 'callback_data' => 'rhub_panel_status']];
        } else {
            $rows[] = [['text' => '🖥 پنل نمایندگی', 'callback_data' => 'rhub_panel_intro']];
        }

        sendmessage($from_id, $info, json_encode(['inline_keyboard' => $rows]), 'HTML');
        return true;
    }

    if (!$reseller || $reseller['status'] !== 'active') return false;

    // سیستم نمایندگی کلاسیک (فروش کانفیگ توسط نماینده) غیرفعال شده —
    // حتی برای رکوردهای قدیمی reseller.status='active' این مسیر دیگر در دسترس نیست.
    return false;

    // ================================================================
    // ---- محصولات نماینده ----
    // ================================================================
    if ($text == '📦 محصولات من') {
        $products = $pdo->prepare("SELECT * FROM reseller_product WHERE id_reseller = ? ORDER BY id DESC");
        $products->execute([$from_id]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);
        if (empty($products)) {
            sendmessage($from_id, "📦 هیچ محصولی تعریف نکرده‌اید.\n\nبرای افزودن محصول از دکمه ➕ استفاده کنید.", json_encode(['keyboard' => [[['text' => '➕ افزودن محصول']], [['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]), 'HTML');
        } else {
            $msg = "📦 <b>محصولات شما:</b>\n\n";
            $btns = [];
            foreach ($products as $p) {
                $st = $p['status'] == 'active' ? '✅' : '⏸';
                $msg .= "$st <b>{$p['name']}</b> — {$p['volume_gb']} GB / {$p['days']} روز — " . number_format($p['price']) . " تومان\n";
                $btns[] = [
                    ['text' => "✏️ {$p['name']}", 'callback_data' => "res_prod_edit_{$p['id']}"],
                    ['text' => ($p['status'] == 'active' ? '⏸ غیرفعال' : '✅ فعال'), 'callback_data' => "res_prod_toggle_{$p['id']}"],
                    ['text' => '🗑', 'callback_data' => "res_prod_del_{$p['id']}"],
                ];
            }
            $btns[] = [['text' => '➕ افزودن محصول', 'callback_data' => 'res_prod_add']];
            sendmessage($from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
        }
        return true;
    }

    // ---- افزودن محصول ----
    if ($user['step'] == 'reseller_add_product_name') {
        if (mb_strlen($text) < 2 || mb_strlen($text) > 50) { sendmessage($from_id, "❌ نام محصول باید ۲ تا ۵۰ کاراکتر باشد.", $kb_back, 'HTML'); return true; }
        update("user", "Processing_value", json_encode(['prod_name' => $text]), "id", $from_id);
        sendmessage($from_id, "📦 حجم (گیگابایت) را وارد کنید:", $kb_back, 'HTML');
        step('reseller_add_product_gb', $from_id);
        return true;
    }
    if ($user['step'] == 'reseller_add_product_gb') {
        if (!ctype_digit($text) || intval($text) <= 0) { sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); return true; }
        $d = json_decode($user['Processing_value'], true);
        $d['prod_gb'] = intval($text);
        update("user", "Processing_value", json_encode($d), "id", $from_id);
        sendmessage($from_id, "📅 مدت زمان (روز) را وارد کنید:", $kb_back, 'HTML');
        step('reseller_add_product_days', $from_id);
        return true;
    }
    if ($user['step'] == 'reseller_add_product_days') {
        if (!ctype_digit($text) || intval($text) <= 0) { sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); return true; }
        $d = json_decode($user['Processing_value'], true);
        $d['prod_days'] = intval($text);
        update("user", "Processing_value", json_encode($d), "id", $from_id);
        sendmessage($from_id, "💰 قیمت (تومان) را وارد کنید:", $kb_back, 'HTML');
        step('reseller_add_product_price', $from_id);
        return true;
    }
    if ($user['step'] == 'reseller_add_product_price') {
        if (!ctype_digit($text) || intval($text) < 0) { sendmessage($from_id, "❌ عدد معتبر وارد کنید.", $kb_back, 'HTML'); return true; }
        $d = json_decode($user['Processing_value'], true);
        $price = intval($text);
        // محاسبه هزینه بر اساس قیمت/گیگ و قیمت/ماه ادمین
        $cost_gb    = $reseller['price_per_gb'] * $d['prod_gb'];
        $cost_month = $reseller['price_per_month'] * max(1, ceil($d['prod_days'] / 30));
        $cost_total = $cost_gb + $cost_month;
        if ($price < $cost_total) {
            sendmessage($from_id, "❌ قیمت وارد شده کمتر از حداقل مجاز است.\n\nحداقل قیمت: <b>" . number_format($cost_total) . " تومان</b>\n(هزینه حجم: " . number_format($cost_gb) . " + هزینه زمان: " . number_format($cost_month) . ")", $kb_back, 'HTML');
            return true;
        }
        $pdo->prepare("INSERT INTO reseller_product (id_reseller, name, volume_gb, days, price, status) VALUES (?, ?, ?, ?, ?, 'active')")
            ->execute([$from_id, $d['prod_name'], $d['prod_gb'], $d['prod_days'], $price]);
        sendmessage($from_id, "✅ محصول <b>{$d['prod_name']}</b> ثبت شد.\n\n📦 {$d['prod_gb']} GB / {$d['prod_days']} روز — " . number_format($price) . " تومان", $kb_main, 'HTML');
        step('home', $from_id);
        return true;
    }

    // ================================================================
    // ---- ساخت کانفیگ ----
    // ================================================================
    if ($text == '⚙️ ساخت کانفیگ') {
        // چک سقف
        if ($reseller['config_limit'] > 0 && $reseller['config_used'] >= $reseller['config_limit']) {
            sendmessage($from_id, "⚠️ به سقف تعداد کانفیگ رسیده‌اید ({$reseller['config_limit']} عدد).\n\n📈 برای افزایش سقف از گزینه «افزایش سقف» استفاده کنید.", $kb_main, 'HTML');
            return true;
        }
        if ($reseller['volume_limit'] <= $reseller['volume_used']) {
            sendmessage($from_id, "⚠️ حجم باقیمانده کافی نیست.\n\n📈 برای خرید حجم از گزینه «افزایش سقف» استفاده کنید.", $kb_main, 'HTML');
            return true;
        }
        // نمایش محصولات برای انتخاب
        $products = $pdo->prepare("SELECT * FROM reseller_product WHERE id_reseller = ? AND status = 'active' ORDER BY id");
        $products->execute([$from_id]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);
        if (empty($products)) {
            sendmessage($from_id, "❌ ابتدا محصول تعریف کنید.", $kb_main, 'HTML');
            return true;
        }
        $btns = [];
        foreach ($products as $p) {
            // چک کافی بودن حجم
            $remain = reseller_remaining_gb($from_id);
            $disabled = $p['volume_gb'] > $remain ? ' ⚠️' : '';
            $btns[] = [['text' => "📦 {$p['name']} — {$p['volume_gb']}GB/{$p['days']}روز{$disabled}", 'callback_data' => "res_build_{$p['id']}"]];
        }
        sendmessage($from_id, "⚙️ <b>ساخت کانفیگ</b>\n\nمحصول مورد نظر را انتخاب کنید:", json_encode(['inline_keyboard' => $btns]), 'HTML');
        return true;
    }

    // ================================================================
    // ---- مدیریت کانفیگ‌ها ----
    // ================================================================
    if ($text == '👥 مدیریت کانفیگ‌ها') {
        $configs = $pdo->prepare("SELECT * FROM reseller_invoice WHERE id_reseller = ? ORDER BY created_at DESC LIMIT 20");
        $configs->execute([$from_id]);
        $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($configs)) { sendmessage($from_id, "📋 هیچ کانفیگی ساخته نشده.", $kb_main, 'HTML'); return true; }
        $btns = [];
        foreach ($configs as $c) {
            $expire_fa = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
            $st_icon = ['active' => '✅', 'disabled' => '🔴', 'expired' => '⏰', 'removed' => '🗑'][$c['status']] ?? '❓';
            $btns[] = [['text' => "$st_icon {$c['username']} | {$c['product_name']} | $expire_fa", 'callback_data' => "res_cfg_{$c['id']}"]];
        }
        sendmessage($from_id, "👥 <b>کانفیگ‌های شما:</b>", json_encode(['inline_keyboard' => $btns]), 'HTML');
        return true;
    }

    // ================================================================
    // ---- گزارش فروش ----
    // ================================================================
    if ($text == '📊 گزارش فروش') {
        $total_configs = $pdo->prepare("SELECT COUNT(*) FROM reseller_invoice WHERE id_reseller = ?");
        $total_configs->execute([$from_id]);
        $total_configs = $total_configs->fetchColumn();

        $active_configs = $pdo->prepare("SELECT COUNT(*) FROM reseller_invoice WHERE id_reseller = ? AND status = 'active'");
        $active_configs->execute([$from_id]);
        $active_configs = $active_configs->fetchColumn();

        $total_income = $pdo->prepare("SELECT SUM(price) FROM reseller_invoice WHERE id_reseller = ?");
        $total_income->execute([$from_id]);
        $total_income = $total_income->fetchColumn() ?? 0;

        $vol_used = reseller_remaining_gb($from_id);

        $msg  = "📊 <b>گزارش فروش</b>\n\n";
        $msg .= "📦 کل کانفیگ ساخته شده: <b>$total_configs</b>\n";
        $msg .= "✅ کانفیگ فعال: <b>$active_configs</b>\n";
        $msg .= "💰 درآمد کل: <b>" . number_format($total_income) . " تومان</b>\n\n";
        $msg .= "━━━━━━━━━━━━━━\n";
        $msg .= "📦 حجم باقیمانده: <b>" . format_gb($vol_used) . "</b>\n";
        $msg .= "🔢 کانفیگ باقیمانده: <b>" . ($reseller['config_limit'] == 0 ? 'نامحدود' : reseller_remaining_configs($from_id) . ' عدد') . "</b>\n";
        $msg .= "💰 موجودی کیف پول: <b>" . number_format($reseller['wallet']) . " تومان</b>";
        sendmessage($from_id, $msg, $kb_main, 'HTML');
        return true;
    }

    // ================================================================
    // ---- افزایش سقف (درخواست به ادمین) ----
    // ================================================================
    if ($text == '📈 افزایش سقف') {
        $btns = json_encode(['keyboard' => [
            [['text' => '📦 افزایش سقف حجم'], ['text' => '🔢 افزایش سقف کانفیگ']],
            [['text' => '🔙 بازگشت']],
        ], 'resize_keyboard' => true]);
        sendmessage($from_id, "📈 <b>افزایش سقف</b>\n\nچه چیزی را می‌خواهید افزایش دهید؟", $btns, 'HTML');
        return true;
    }

    if ($text == '📦 افزایش سقف حجم') {
        if ($reseller['price_per_gb'] <= 0) {
            sendmessage($from_id, "⚠️ قیمت هر گیگابایت برای حساب شما هنوز توسط مدیر تعیین نشده است.\n\nلطفاً با ادمین تماس بگیرید.", $kb_main, 'HTML');
            return true;
        }
        sendmessage($from_id, "📦 <b>افزایش سقف حجم</b>\n\nچند گیگابایت می‌خواهید اضافه کنید؟\n\n💰 قیمت هر گیگ: <b>" . number_format($reseller['price_per_gb']) . " تومان</b>", $kb_back, 'HTML');
        step('reseller_req_gb', $from_id);
        return true;
    }

    if ($user['step'] == 'reseller_req_gb') {
        if (!ctype_digit($text) || intval($text) <= 0) { sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); return true; }
        if ($reseller['price_per_gb'] <= 0) {
            sendmessage($from_id, "⚠️ قیمت هر گیگابایت برای حساب شما تعیین نشده است.\n\nبا ادمین تماس بگیرید.", $kb_main, 'HTML');
            step('home', $from_id);
            return true;
        }
        $gb = intval($text);
        $total = $gb * $reseller['price_per_gb'];
        $kb_confirm = json_encode(['inline_keyboard' => [
            [
                ['text' => '💳 پرداخت از کیف پول', 'callback_data' => "res_vol_pay_{$gb}_{$total}"],
                ['text' => '❌ انصراف', 'callback_data' => 'res_cancel'],
            ]
        ]]);
        sendmessage($from_id, "📦 درخواست افزایش حجم:\n\n📦 حجم: <b>" . format_gb($gb) . "</b>\n💰 مبلغ: <b>" . number_format($total) . " تومان</b>\n💳 موجودی کیف پول: <b>" . number_format($reseller['wallet']) . " تومان</b>", $kb_confirm, 'HTML');
        step('home', $from_id);
        return true;
    }

    if ($text == '🔢 افزایش سقف کانفیگ') {
        sendmessage($from_id, "🔢 <b>افزایش سقف کانفیگ</b>\n\nتعداد کانفیگ اضافی مورد نیاز را وارد کنید:", $kb_back, 'HTML');
        step('reseller_req_cfg', $from_id);
        return true;
    }

    if ($user['step'] == 'reseller_req_cfg') {
        if (!ctype_digit($text) || intval($text) <= 0) { sendmessage($from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); return true; }
        $count = intval($text);
        $msg = "🔢 درخواست افزایش سقف کانفیگ:\n\n🔢 تعداد: <b>$count</b> کانفیگ\n\nدرخواست به مدیر ارسال می‌شود.";
        $kb_confirm = json_encode(['inline_keyboard' => [
            [
                ['text' => '✅ ارسال درخواست', 'callback_data' => "res_cfg_req_$count"],
                ['text' => '❌ انصراف', 'callback_data' => 'res_cancel'],
            ]
        ]]);
        sendmessage($from_id, $msg, $kb_confirm, 'HTML');
        step('home', $from_id);
        return true;
    }

    // ================================================================
    // ---- کیف پول نماینده ----
    // ================================================================
    if ($text == '💰 کیف پول') {
        $msg  = "💰 <b>کیف پول نمایندگی</b>\n\n";
        $msg .= "موجودی: <b>" . number_format($reseller['wallet']) . " تومان</b>\n\n";
        $msg .= "برای شارژ کیف پول با مدیر تماس بگیرید.";
        sendmessage($from_id, $msg, $kb_main, 'HTML');
        return true;
    }

    return false;
}

// ================================================================
// «کانفیگ نمایندگی» — مراحل وارد کردن حجم/روز (متن آزاد توسط کاربر)
// این تابع از index.php، قبل از handle_reseller_user صدا زده می‌شود
// چون step ها با پیشوند rcfg_ شروع می‌شوند.
// ================================================================
function handle_reseller_cfg_steps($from_id, $text, $user, $keyboard)
{
    global $pdo;

    if ($user['step'] === 'rcfg_enter_volume') {
        $gb = intval(preg_replace('/\D/', '', $text));
        $setting = select('setting', '*');
        $min_gb  = max(1, intval($setting['reseller_cfg_min_gb'] ?? 1));
        if ($gb < $min_gb) {
            sendmessage($from_id, "❌ حجم باید حداقل {$min_gb} گیگابایت باشد. دوباره وارد کنید:", null, 'HTML');
            return true;
        }
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")
            ->execute([json_encode(['volume_gb' => $gb]), $from_id]);
        sendmessage($from_id, "⏳ تعداد روز مورد نظر را وارد کنید (مثلاً 30):", null, 'HTML');
        step('rcfg_enter_days', $from_id);
        return true;
    }

    if ($user['step'] === 'rcfg_enter_days') {
        $pv = json_decode($user['Processing_value'] ?? '{}', true);
        if (empty($pv['volume_gb'])) { step('home', $from_id); return true; }

        $days = intval(preg_replace('/\D/', '', $text));
        $setting  = select('setting', '*');
        $min_days = max(1, intval($setting['reseller_cfg_min_days'] ?? 1));
        if ($days < $min_days) {
            sendmessage($from_id, "❌ تعداد روز باید حداقل {$min_days} باشد. دوباره وارد کنید:", null, 'HTML');
            return true;
        }

        $price_per_gb  = max(0, intval($setting['reseller_cfg_price_per_gb']  ?? 0));
        $price_per_day = max(0, intval($setting['reseller_cfg_price_per_day'] ?? 0));
        $volume_gb = intval($pv['volume_gb']);
        $price = ($volume_gb * $price_per_gb) + ($days * $price_per_day);

        $vol_txt = $volume_gb >= 1024 ? round($volume_gb / 1024, 2) . ' TB' : $volume_gb . ' GB';

        $msg  = "📦 <b>پیش‌فاکتور کانفیگ نمایندگی</b>\n\n";
        $msg .= "🔋 حجم: <b>{$vol_txt}</b>\n";
        $msg .= "⏳ مدت: <b>{$days} روز</b>\n";
        $msg .= "💰 قیمت کل: <b>" . number_format($price) . " تومان</b>\n\n";
        $msg .= "آیا تایید می‌کنید؟";

        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")
            ->execute([json_encode(['volume_gb' => $volume_gb, 'days' => $days, 'price' => $price]), $from_id]);

        $kb = json_encode(['inline_keyboard' => [
            [['text' => '✅ ثبت سفارش', 'callback_data' => 'rcfg_submit_order']],
            [['text' => '❌ انصراف', 'callback_data' => 'rcfg_cancel']],
        ]]);
        sendmessage($from_id, $msg, $kb, 'HTML');
        step('rcfg_confirm', $from_id);
        return true;
    }

    return false;
}

// ================================================================
// بخش ادمین (ربات مادر)
// ================================================================
// ================================================================
// هاب پنل نمایندگی — callback های دو دکمه (پنل / کانفیگ)
// از index.php صدا زده می‌شود، قبل از handle_reseller_callbacks
// ================================================================
function handle_reseller_hub_callbacks($from_id, $datain, $message_id, $callback_query_id)
{
    global $pdo, $admin_ids, $adminnumber;

    // ---- معرفی + درخواست «پنل نمایندگی» (ربات اختصاصی) ----
    if ($datain === 'rhub_panel_intro') {
        $setting = select('setting', '*');
        $intro = trim($setting['reseller_panel_intro_text'] ?? '');
        if ($intro === '') {
            $intro = "🖥 <b>پنل نمایندگی</b>\n\nبا دریافت پنل نمایندگی، یک ربات تلگرامی اختصاصی برای فروش سرویس VPN دریافت می‌کنید که به‌صورت خودکار به یک پنل اختصاص داده می‌شود.";
        }

        // وضعیت تایید شخص (قبل از انتخاب پلن)
        $appr = $pdo->prepare("SELECT * FROM reseller_bot_approval WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
        $appr->execute([$from_id]);
        $appr = $appr->fetch(PDO::FETCH_ASSOC);

        // اگه سفارش در انتظار بررسی یا تایید‌شده‌ی پرداخت‌نشده داره، وضعیتشو نشون بده
        $existing = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE buyer_id=? AND delivered=0 ORDER BY created_at DESC LIMIT 1");
        $existing->execute([$from_id]);
        $existing = $existing->fetch(PDO::FETCH_ASSOC);

        $rows = [];
        if (($setting['bot_sale_status'] ?? 'off') === 'off') {
            $intro .= "\n\n⛔️ در حال حاضر امکان درخواست پنل نمایندگی وجود ندارد.";
        } elseif ($existing && $existing['approval_status'] === 'awaiting_approval') {
            $intro .= "\n\n⏳ شما یک درخواست در انتظار تایید مدیر دارید. (سفارش: <code>{$existing['order_id']}</code>)";
        } elseif ($existing && $existing['approval_status'] === 'approved' && $existing['payment_status'] !== 'paid') {
            $intro .= "\n\n✅ درخواست شما تایید شده — پرداخت را تکمیل کنید.";
            $rows[] = [['text' => '💳 ادامه پرداخت', 'callback_data' => "bot_sale_payment_options_{$existing['order_id']}"]];
        } elseif (!$appr || $appr['status'] === 'rejected') {
            // هنوز هیچ درخواستی نداده یا درخواست قبلیش رد شده — می‌تونه (دوباره) درخواست بده
            if ($appr && $appr['status'] === 'rejected') {
                $intro .= "\n\n❌ درخواست قبلی شما توسط مدیر رد شده بود. می‌توانید دوباره درخواست دهید.";
            }
            $rows[] = [['text' => '📝 درخواست نمایندگی', 'callback_data' => 'rhub_panel_request']];
        } elseif ($appr['status'] === 'pending') {
            $intro .= "\n\n⏳ درخواست نمایندگی شما در انتظار تایید مدیر است.";
        } elseif ($appr['status'] === 'approved') {
            $intro .= "\n\n✅ درخواست شما تایید شده — حالا می‌توانید پلن مورد نظر را انتخاب کنید.";
            $rows[] = [['text' => '🛒 انتخاب پلن', 'callback_data' => 'rhub_panel_apply']];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']];

        Editmessagetext($from_id, $message_id, $intro, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- ثبت درخواست نمایندگی (مرحله اول، بدون پلن) → برای تایید/رد شخص نزد مدیر ----
    if ($datain === 'rhub_panel_request') {
        $setting = select('setting', '*');
        if (($setting['bot_sale_status'] ?? 'off') === 'off') {
            AnswerCallbackQuery($callback_query_id, '⚠️ در حال حاضر فروش پنل نمایندگی غیرفعال است.', true);
            return true;
        }

        $appr = $pdo->prepare("SELECT * FROM reseller_bot_approval WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
        $appr->execute([$from_id]);
        $appr = $appr->fetch(PDO::FETCH_ASSOC);
        if ($appr && in_array($appr['status'], ['pending', 'approved'])) {
            AnswerCallbackQuery($callback_query_id, '⚠️ شما قبلاً درخواست داده‌اید.', true);
            return true;
        }

        $pdo->prepare("INSERT INTO reseller_bot_approval (user_id, status, created_at) VALUES (?, 'pending', ?)")
            ->execute([$from_id, time()]);

        $msg  = "✅ <b>درخواست نمایندگی شما ثبت شد</b>\n\n";
        $msg .= "⏳ پس از بررسی و تایید مدیر، امکان انتخاب پلن برای شما فعال می‌شود.";
        $rows = [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']]];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id, '✅ درخواست ثبت شد');

        // اطلاع به ادمین‌ها با دکمه تایید/رد شخص
        global $admin_ids, $adminnumber;
        $msg_admin  = "🆕 <b>درخواست جدید نمایندگی (تایید شخص)</b>\n\n";
        $msg_admin .= "👤 آیدی عددی کاربر: <code>{$from_id}</code>\n";
        $msg_admin .= "ℹ️ تایید این مرحله صرفاً اجازه‌ی انتخاب پلن می‌دهد؛ پرداخت و تحویل پنل در مراحل بعدی است.";
        $kb_admin = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید شخص', 'callback_data' => "rhub_panel_person_approve_{$from_id}"],
            ['text' => '❌ رد شخص',    'callback_data' => "rhub_panel_person_reject_{$from_id}"],
        ]]]);
        $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
        foreach ($admin_targets as $admin) {
            sendmessage($admin, $msg_admin, $kb_admin, 'HTML');
        }
        return true;
    }

    // ---- ادمین: تایید شخص برای درخواست پنل نمایندگی ----
    if (preg_match('/^rhub_panel_person_approve_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $uid = $m[1];
        $appr = $pdo->prepare("SELECT * FROM reseller_bot_approval WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
        $appr->execute([$uid]);
        $appr = $appr->fetch(PDO::FETCH_ASSOC);
        if (!$appr || $appr['status'] !== 'pending') {
            AnswerCallbackQuery($callback_query_id, '⚠️ این درخواست قبلاً پردازش شده یا یافت نشد.', true);
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot_approval SET status='approved', reviewed_at=?, reviewed_by=? WHERE id=?")
            ->execute([time(), $from_id, $appr['id']]);

        sendmessage($uid,
            "✅ <b>درخواست نمایندگی شما تایید شد</b>\n\nاز منوی 🤝 پنل نمایندگی → 🖥 پنل نمایندگی، حالا می‌توانید پلن مورد نظر را انتخاب کنید.",
            null, 'HTML');

        Editmessagetext($from_id, $message_id,
            "✅ شخص تایید شد.\n👤 آیدی: <code>{$uid}</code>", null);
        AnswerCallbackQuery($callback_query_id, '✅ تایید شد', true);
        return true;
    }

    // ---- ادمین: رد شخص برای درخواست پنل نمایندگی ----
    if (preg_match('/^rhub_panel_person_reject_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $uid = $m[1];
        $appr = $pdo->prepare("SELECT * FROM reseller_bot_approval WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
        $appr->execute([$uid]);
        $appr = $appr->fetch(PDO::FETCH_ASSOC);
        if (!$appr || $appr['status'] !== 'pending') {
            AnswerCallbackQuery($callback_query_id, '⚠️ این درخواست قبلاً پردازش شده یا یافت نشد.', true);
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot_approval SET status='rejected', reviewed_at=?, reviewed_by=? WHERE id=?")
            ->execute([time(), $from_id, $appr['id']]);

        sendmessage($uid,
            "❌ <b>درخواست نمایندگی شما رد شد</b>\n\nبرای اطلاعات بیشتر با پشتیبانی تماس بگیرید.",
            null, 'HTML');

        Editmessagetext($from_id, $message_id,
            "❌ شخص رد شد.\n👤 آیدی: <code>{$uid}</code>", null);
        AnswerCallbackQuery($callback_query_id, '❌ رد شد', true);
        return true;
    }

    // ---- ثبت درخواست پنل نمایندگی (مرحله دوم: انتخاب پلن — فقط بعد از تایید شخص) ----
    if ($datain === 'rhub_panel_apply') {
        $setting = select('setting', '*');
        if (($setting['bot_sale_status'] ?? 'off') === 'off') {
            AnswerCallbackQuery($callback_query_id, '⚠️ در حال حاضر فروش پنل نمایندگی غیرفعال است.', true);
            return true;
        }

        // محافظ: تایید شخص باید قبلاً انجام شده باشه
        $appr = $pdo->prepare("SELECT * FROM reseller_bot_approval WHERE user_id=? ORDER BY created_at DESC LIMIT 1");
        $appr->execute([$from_id]);
        $appr = $appr->fetch(PDO::FETCH_ASSOC);
        if (!$appr || $appr['status'] !== 'approved') {
            AnswerCallbackQuery($callback_query_id, '⚠️ ابتدا باید درخواست نمایندگی شما توسط مدیر تایید شود.', true);
            return true;
        }

        $existing = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE buyer_id=? AND delivered=0 AND approval_status != 'rejected' ORDER BY created_at DESC LIMIT 1");
        $existing->execute([$from_id]);
        if ($existing->fetch()) {
            AnswerCallbackQuery($callback_query_id, '⚠️ شما قبلاً درخواست ثبت کرده‌اید.', true);
            return true;
        }

        $plans = $pdo->query("SELECT * FROM reseller_bot_plan WHERE status='active' ORDER BY price ASC")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($plans)) {
            AnswerCallbackQuery($callback_query_id, '⚠️ در حال حاضر پلنی برای پنل نمایندگی تعریف نشده.', true);
            return true;
        }

        $msg  = "📝 <b>درخواست پنل نمایندگی</b>\n\nیکی از پلن‌های زیر را انتخاب کنید:";
        $rows = [];
        foreach ($plans as $p) {
            $vol = $p['volume_gb'] >= 1024 ? round($p['volume_gb'] / 1024, 1) . ' TB' : $p['volume_gb'] . ' GB';
            $rows[] = [['text' => "🔹 {$p['name']} — {$vol} — " . number_format($p['price']) . " تومان",
                         'callback_data' => "bot_sale_plan_{$p['id']}"]];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- وضعیت پنل نمایندگی فعال (سرویس‌ها + قیمت) ----
    if ($datain === 'rhub_panel_status') {
        $inv = $pdo->prepare(
            "SELECT * FROM reseller_bot_invoice WHERE buyer_id=? AND delivered=1 AND payment_status='paid' ORDER BY created_at DESC LIMIT 1"
        );
        $inv->execute([$from_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ پنلی یافت نشد', true); return true; }

        $rb = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $rb->execute([$inv['bot_token']]);
        $rb = $rb->fetch(PDO::FETCH_ASSOC);

        $vol_txt    = $inv['volume_gb'] >= 1024 ? round($inv['volume_gb'] / 1024, 1) . ' TB' : $inv['volume_gb'] . ' GB';
        $used_gb    = (float)($rb['volume_used'] ?? 0);
        $remain_gb  = max(0, (float)($rb['volume_limit'] ?? $inv['volume_gb']) - $used_gb);
        $used_txt   = format_gb($used_gb);
        $remain_txt = format_gb($remain_gb);

        $expire_at = (int)($rb['expire_at'] ?? 0);
        if ($expire_at > 0) {
            $days_left  = max(0, ceil(($expire_at - time()) / 86400));
            $expire_txt = $days_left > 0
                ? "<b>{$days_left} روز مانده</b> (تا " . date('Y/m/d', $expire_at) . ")"
                : "<b>منقضی شده</b> (" . date('Y/m/d', $expire_at) . ")";
        } else {
            $expire_txt = "<b>نامحدود</b>";
        }

        $msg  = "🖥 <b>پنل نمایندگی شما</b>\n\n";
        $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg .= "📦 حجم کل: <b>{$vol_txt}</b> | مصرف‌شده: <b>{$used_txt}</b> | باقیمانده: <b>{$remain_txt}</b>\n";
        $msg .= "👥 سقف کانفیگ: <b>{$inv['config_limit']}</b>\n";
        $msg .= "⏳ مدت اعتبار: {$expire_txt}\n";
        $msg .= "🌐 پنل اختصاص‌یافته: <b>" . ($rb['panel_name'] ?? '—') . "</b>\n";
        $msg .= "🤖 ربات: @" . ($rb['bot_username'] ?? $inv['bot_username']) . "\n";
        $msg .= "📌 وضعیت: <b>" . (($rb['status'] ?? '') === 'active' ? '✅ فعال' : '🚫 غیرفعال') . "</b>\n";
        $msg .= "💳 کیف پول: <b>" . number_format($rb['wallet'] ?? 0) . " تومان</b>";

        $rows = [];
        if (($rb['price_per_gb'] ?? 0) > 0) {
            $rows[] = [['text' => '📦 افزایش حجم', 'callback_data' => 'rb_extend_vol']];
        }
        if (($rb['price_per_month'] ?? 0) > 0) {
            $rows[] = [['text' => '⏳ افزایش زمان', 'callback_data' => 'rb_extend_days']];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- افزایش حجم پنل نمایندگی توسط خود نماینده ----
    if ($datain === 'rb_extend_vol') {
        $rb = $pdo->prepare("SELECT * FROM reseller_bot WHERE owner_id=? ORDER BY id DESC LIMIT 1");
        $rb->execute([$from_id]);
        $rb = $rb->fetch(PDO::FETCH_ASSOC);
        if (!$rb || $rb['status'] !== 'active') { AnswerCallbackQuery($callback_query_id, '❌ پنل فعالی یافت نشد', true); return true; }
        if ($rb['price_per_gb'] <= 0) { AnswerCallbackQuery($callback_query_id, '⚠️ قیمت هر گیگابایت تعیین نشده', true); return true; }

        update("user", "Processing_value", json_encode(['rb_id' => $rb['id']]), "id", $from_id);
        Editmessagetext($from_id, $message_id,
            "📦 <b>افزایش حجم پنل نمایندگی</b>\n\n💰 قیمت هر گیگ: <b>" . number_format($rb['price_per_gb']) . " تومان</b>\n💳 موجودی کیف پول: <b>" . number_format($rb['wallet']) . " تومان</b>\n\nچند گیگابایت می‌خواهید اضافه کنید؟ عدد را پیام دهید:",
            json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]));
        step('rb_enter_extend_vol', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- افزایش زمان پنل نمایندگی توسط خود نماینده ----
    if ($datain === 'rb_extend_days') {
        $rb = $pdo->prepare("SELECT * FROM reseller_bot WHERE owner_id=? ORDER BY id DESC LIMIT 1");
        $rb->execute([$from_id]);
        $rb = $rb->fetch(PDO::FETCH_ASSOC);
        if (!$rb || $rb['status'] !== 'active') { AnswerCallbackQuery($callback_query_id, '❌ پنل فعالی یافت نشد', true); return true; }
        if ($rb['price_per_month'] <= 0) { AnswerCallbackQuery($callback_query_id, '⚠️ قیمت هر ماه تعیین نشده', true); return true; }

        update("user", "Processing_value", json_encode(['rb_id' => $rb['id']]), "id", $from_id);
        Editmessagetext($from_id, $message_id,
            "⏳ <b>افزایش زمان پنل نمایندگی</b>\n\n💰 قیمت هر ۳۰ روز: <b>" . number_format($rb['price_per_month']) . " تومان</b>\n💳 موجودی کیف پول: <b>" . number_format($rb['wallet']) . " تومان</b>\n\nچند روز می‌خواهید اضافه کنید؟ عدد را پیام دهید:",
            json_encode(['inline_keyboard' => [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_panel_status']]]]));
        step('rb_enter_extend_days', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- معرفی + درخواست «کانفیگ نمایندگی» (حجم/روز با نرخ ادمین) ----
    if ($datain === 'rhub_cfg_intro') {
        $setting = select('setting', '*');
        $intro = trim($setting['reseller_cfg_intro_text'] ?? '');
        if ($intro === '') {
            $intro = "📦 <b>کانفیگ نمایندگی</b>\n\nبا تایید این درخواست، می‌توانید حجم و مدت دلخواه را با نرخ پایین‌تر مخصوص نمایندگان خریداری کنید.";
        }

        $rows = [];
        if ($reseller_check = get_reseller($from_id)) {
            if ($reseller_check['status'] === 'pending') {
                $intro .= "\n\n⏳ درخواست شما در انتظار بررسی مدیر است.";
            } elseif ($reseller_check['status'] === 'blocked') {
                $intro .= "\n\n🚫 حساب نمایندگی شما مسدود شده است.";
            }
        } else {
            $rows[] = [['text' => '📝 درخواست کانفیگ نمایندگی', 'callback_data' => 'rhub_cfg_apply']];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']];

        Editmessagetext($from_id, $message_id, $intro, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- ثبت درخواست کانفیگ نمایندگی (تایید مستقل مدیر) ----
    if ($datain === 'rhub_cfg_apply') {
        if (get_reseller($from_id)) {
            AnswerCallbackQuery($callback_query_id, '⚠️ شما قبلاً درخواست داده‌اید.', true);
            return true;
        }
        $pdo->prepare(
            "INSERT INTO reseller (id_user, panel_name, volume_limit, volume_used, config_limit, config_used, price_per_gb, price_per_month, wallet, status, created_at)
             VALUES (?, '', 0, 0, 0, 0, 0, 0, 0, 'pending', ?)"
        )->execute([$from_id, time()]);

        Editmessagetext($from_id, $message_id, "✅ درخواست کانفیگ نمایندگی شما ثبت شد و در انتظار بررسی مدیر است.", json_encode(['inline_keyboard' => []]));

        $user_info = select("user", "*", "id", $from_id, "select");
        $msg_admin = "📨 <b>درخواست کانفیگ نمایندگی جدید</b>\n\n"
                   . "👤 آیدی: <code>$from_id</code>\n"
                   . "🔖 یوزرنیم: @" . ($user_info['username'] ?? '-');
        $kb_admin = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید', 'callback_data' => "reseller_approve_$from_id"],
            ['text' => '❌ رد', 'callback_data' => "reseller_reject_$from_id"],
        ]]]);
        $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
        foreach ($admin_targets as $admin) { sendmessage($admin, $msg_admin, $kb_admin, 'HTML'); }
        AnswerCallbackQuery($callback_query_id, '✅ ثبت شد', true);
        return true;
    }

    // ---- وضعیت کانفیگ نمایندگی فعال — شروع خرید حجم/روز ----
    if ($datain === 'rhub_cfg_status') {
        $reseller_check = get_reseller($from_id);
        if (!$reseller_check || $reseller_check['status'] !== 'active') {
            AnswerCallbackQuery($callback_query_id, '❌ دسترسی ندارید', true);
            return true;
        }
        $setting = select('setting', '*');
        $price_per_gb  = max(0, intval($setting['reseller_cfg_price_per_gb']  ?? 0));
        $price_per_day = max(0, intval($setting['reseller_cfg_price_per_day'] ?? 0));
        $min_gb   = max(1, intval($setting['reseller_cfg_min_gb']   ?? 1));
        $min_days = max(1, intval($setting['reseller_cfg_min_days'] ?? 1));

        $msg  = "📦 <b>کانفیگ نمایندگی</b>\n\n";
        $msg .= "💵 نرخ هر گیگابایت: <b>" . number_format($price_per_gb) . " تومان</b>\n";
        $msg .= "💵 نرخ هر روز: <b>" . number_format($price_per_day) . " تومان</b>\n";
        $msg .= "📌 حداقل حجم: <b>{$min_gb} GB</b> | حداقل مدت: <b>{$min_days} روز</b>\n\n";
        $msg .= "حجم مورد نظر خود را به گیگابایت وارد کنید:";

        $rows = [[['text' => '🔙 بازگشت', 'callback_data' => 'rhub_back']]];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        step('rcfg_enter_volume', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- بازگشت به هاب ----
    if ($datain === 'rhub_back') {
        $info  = "🤝 <b>پنل نمایندگی</b>\n\nیکی از گزینه‌های زیر را انتخاب کنید:";
        $rows  = [];

        $bot_req = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE buyer_id=? ORDER BY created_at DESC LIMIT 1");
        $bot_req->execute([$from_id]);
        $bot_req = $bot_req->fetch(PDO::FETCH_ASSOC);
        if ($bot_req && $bot_req['delivered'] == 1 && $bot_req['payment_status'] == 'paid') {
            $rows[] = [['text' => '🖥 پنل نمایندگی (فعال - مشاهده سرویس‌ها)', 'callback_data' => 'rhub_panel_status']];
        } else {
            $rows[] = [['text' => '🖥 پنل نمایندگی', 'callback_data' => 'rhub_panel_intro']];
        }

        Editmessagetext($from_id, $message_id, $info, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- تایید نهایی سفارش کانفیگ نمایندگی (بعد دیدن پیش‌فاکتور) ----
    if ($datain === 'rcfg_submit_order') {
        $user_row = $pdo->prepare("SELECT * FROM user WHERE id=?");
        $user_row->execute([$from_id]);
        $user_row = $user_row->fetch(PDO::FETCH_ASSOC);
        $pv = json_decode($user_row['Processing_value'] ?? '{}', true);

        if (empty($pv['volume_gb']) || empty($pv['days'])) {
            AnswerCallbackQuery($callback_query_id, '❌ خطا. لطفاً دوباره شروع کنید.', true);
            step('home', $from_id);
            return true;
        }

        $order_id = 'RC' . time() . rand(1000, 9999);
        $pdo->prepare(
            "INSERT INTO reseller_cfg_order (order_id, id_user, volume_gb, days, price, approval_status, payment_status, delivered, created_at)
             VALUES (?,?,?,?,?,'awaiting_approval','pending',0,?)"
        )->execute([$order_id, $from_id, $pv['volume_gb'], $pv['days'], $pv['price'], time()]);

        $vol_txt = $pv['volume_gb'] >= 1024 ? round($pv['volume_gb'] / 1024, 2) . ' TB' : $pv['volume_gb'] . ' GB';
        $detail  = "📦 حجم: <b>{$vol_txt}</b>\n";
        $detail .= "⏳ مدت: <b>{$pv['days']} روز</b>\n";
        $detail .= "💰 مبلغ: <b>" . number_format($pv['price']) . " تومان</b>\n";
        $detail .= "👤 آیدی عددی: <code>{$from_id}</code>\n";
        $detail .= "📌 شناسه سفارش: <code>{$order_id}</code>";

        Editmessagetext($from_id, $message_id,
            "✅ <b>سفارش شما ثبت شد و در انتظار تایید مدیر است</b>\n\n{$detail}\n\n⏳ بعد از تایید، روش‌های پرداخت نمایش داده می‌شود.",
            null);

        $msg_admin = "🆕 <b>درخواست جدید: کانفیگ نمایندگی (در انتظار تایید)</b>\n\n" . $detail;
        $kb_admin = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید سفارش', 'callback_data' => "rcfg_order_approve_{$order_id}"],
            ['text' => '❌ رد سفارش',    'callback_data' => "rcfg_order_reject_{$order_id}"],
        ]]]);
        $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
        foreach ($admin_targets as $admin) { sendmessage($admin, $msg_admin, $kb_admin, 'HTML'); }

        step('home', $from_id);
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        AnswerCallbackQuery($callback_query_id, '✅ سفارش ثبت شد');
        return true;
    }

    if ($datain === 'rcfg_cancel') {
        Editmessagetext($from_id, $message_id, "❌ لغو شد.", json_encode(['inline_keyboard' => []]));
        step('home', $from_id);
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- ادمین: تایید سفارش کانفیگ نمایندگی → نمایش روش‌های پرداخت ----
    if (preg_match('/^rcfg_order_approve_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $o = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=?");
        $o->execute([$order_id]);
        $o = $o->fetch(PDO::FETCH_ASSOC);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true); return true; }
        if ($o['approval_status'] !== 'awaiting_approval') {
            AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true);
            return true;
        }
        $pdo->prepare("UPDATE reseller_cfg_order SET approval_status='approved', reviewed_at=?, reviewed_by=? WHERE order_id=?")
            ->execute([time(), $from_id, $order_id]);

        _rcfg_send_payment_options($o['id_user'], $order_id);

        Editmessagetext($from_id, $message_id,
            "✅ سفارش تایید شد و روش‌های پرداخت برای کاربر ارسال شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        AnswerCallbackQuery($callback_query_id, '✅ تایید شد', true);
        return true;
    }

    // ---- ادمین: رد سفارش کانفیگ نمایندگی ----
    if (preg_match('/^rcfg_order_reject_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $o = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=?");
        $o->execute([$order_id]);
        $o = $o->fetch(PDO::FETCH_ASSOC);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true); return true; }
        if ($o['approval_status'] !== 'awaiting_approval') {
            AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true);
            return true;
        }
        $pdo->prepare("UPDATE reseller_cfg_order SET approval_status='rejected', payment_status='rejected', reviewed_at=?, reviewed_by=? WHERE order_id=?")
            ->execute([time(), $from_id, $order_id]);

        sendmessage($o['id_user'], "❌ <b>سفارش کانفیگ نمایندگی شما رد شد</b>\n\n📌 شناسه: <code>{$order_id}</code>", null, 'HTML');
        Editmessagetext($from_id, $message_id, "❌ سفارش رد شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        AnswerCallbackQuery($callback_query_id, '❌ رد شد', true);
        return true;
    }

    // ---- نمایش (مجدد) روش‌های پرداخت برای سفارش کانفیگ نمایندگی approved ----
    if (preg_match('/^rcfg_payment_options_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $o = _rcfg_get_approved_order($order_id, $from_id);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }
        $kb = _rcfg_payment_options_kb($order_id);
        if (!$kb) { AnswerCallbackQuery($callback_query_id, '❌ هیچ روش پرداختی تنظیم نشده'); return true; }
        Editmessagetext($from_id, $message_id, _rcfg_payment_options_text($o), $kb);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت کارت به کارت (کانفیگ نمایندگی) ----
    if (preg_match('/^rcfg_pay_card_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $o = _rcfg_get_approved_order($order_id, $from_id);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $setting = select('setting', '*');
        $card    = $setting['bot_sale_card_num']  ?? '';
        $cname   = $setting['bot_sale_card_name'] ?? '';

        $msg  = "💳 <b>پرداخت کارت به کارت</b>\n\n";
        $msg .= "💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n\n";
        $msg .= "🏦 شماره کارت:\n<code>{$card}</code>\n";
        if ($cname) $msg .= "👤 به نام: <b>{$cname}</b>\n";
        $msg .= "\nبعد از واریز، شماره پیگیری را ارسال کنید:";

        $kb = json_encode(['inline_keyboard' => [
            [['text' => '📋 کپی شماره کارت', 'copy_text' => ['text' => $card]]],
            [['text' => '🔙 بازگشت', 'callback_data' => "rcfg_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")
            ->execute([json_encode(['order_id' => $order_id]), $from_id]);
        step('rcfg_card_tracking', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین زرین‌پال (کانفیگ نمایندگی) ----
    if (preg_match('/^rcfg_pay_zarinpal_(.+)$/', $datain, $m)) {
        global $domainhosts;
        $order_id = $m[1];
        $o = _rcfg_get_approved_order($order_id, $from_id);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $pdo->prepare("UPDATE reseller_cfg_order SET payment_method='zarinpal' WHERE order_id=?")->execute([$order_id]);
        $pay_url = "https://{$domainhosts}/payment/zarinpal/zarinpal_cfg.php?price={$o['price']}&order_id={$order_id}";

        $msg = "🔐 <b>پرداخت آنلاین زرین‌پال</b>\n\n💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n\nروی دکمه زیر کلیک کنید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت از طریق زرین‌پال', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "rcfg_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین آقای پرداخت (کانفیگ نمایندگی) ----
    if (preg_match('/^rcfg_pay_aqaye_(.+)$/', $datain, $m)) {
        global $domainhosts;
        $order_id = $m[1];
        $o = _rcfg_get_approved_order($order_id, $from_id);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $pdo->prepare("UPDATE reseller_cfg_order SET payment_method='aqayepardakht' WHERE order_id=?")->execute([$order_id]);
        $pay_url = "https://{$domainhosts}/payment/aqayepardakht/aqayepardakht_cfg.php?price={$o['price']}&order_id={$order_id}";

        $msg = "💳 <b>پرداخت آنلاین آقای پرداخت</b>\n\n💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n\nروی دکمه زیر کلیک کنید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت آنلاین', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "rcfg_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین NowPayments (کانفیگ نمایندگی) ----
    if (preg_match('/^rcfg_pay_nowpayments_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $o = _rcfg_get_approved_order($order_id, $from_id);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $price_rate = tronratee();
        $usd_amount = $price_rate['result']['USD'] > 0 ? round($o['price'] / $price_rate['result']['USD'], 2) : 0;
        if ($usd_amount <= 0) { AnswerCallbackQuery($callback_query_id, '❌ خطا در تبدیل قیمت به دلار'); return true; }

        $pdo->prepare("UPDATE reseller_cfg_order SET payment_method='nowpayments' WHERE order_id=?")->execute([$order_id]);
        $pay = nowPayments('invoice', $usd_amount, $order_id, "خرید کانفیگ نمایندگی");
        $pay_url = $pay['invoice_url'] ?? $pay['url'] ?? '';
        if (empty($pay_url)) { AnswerCallbackQuery($callback_query_id, '❌ خطا در ساخت لینک پرداخت'); return true; }

        $msg  = "🔐 <b>پرداخت آنلاین NowPayments</b>\n\n💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n";
        $msg .= "💵 معادل: <b>{$usd_amount} USD</b>\n\nروی دکمه زیر کلیک کنید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت از طریق NowPayments', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "rcfg_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    return false;
}

// ------------------------------------------------------------------
// step: دریافت شماره پیگیری کارت‌به‌کارت برای کانفیگ نمایندگی
// از index.php صدا زده می‌شود (قبل از handle_reseller_user)
// ------------------------------------------------------------------
function handle_reseller_cfg_card_tracking_step($from_id, $text, $user, $keyboard)
{
    global $pdo, $admin_ids, $adminnumber;

    if ($user['step'] !== 'rcfg_card_tracking') return false;

    $pv = json_decode($user['Processing_value'] ?? '{}', true);
    $order_id = $pv['order_id'] ?? null;
    if (!$order_id) { step('home', $from_id); return true; }

    $tracking = trim($text);
    if (strlen($tracking) < 4) {
        sendmessage($from_id, "❌ شماره پیگیری معتبر نیست. دوباره وارد کنید:", null, 'HTML');
        return true;
    }

    $o = _rcfg_get_approved_order($order_id, $from_id);
    if (!$o) {
        sendmessage($from_id, "❌ سفارش معتبر نیست یا قبلاً پردازش شده.", $keyboard, 'HTML');
        step('home', $from_id);
        return true;
    }

    $pdo->prepare("UPDATE reseller_cfg_order SET payment_method='card', payment_status='waiting_admin' WHERE order_id=?")
        ->execute([$order_id]);

    $msg_admin  = "💳 <b>تایید واریز کارت‌به‌کارت — کانفیگ نمایندگی</b>\n\n";
    $msg_admin .= "👤 خریدار: <code>{$from_id}</code>\n";
    $msg_admin .= "💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n";
    $msg_admin .= "🔖 شماره پیگیری: <code>{$tracking}</code>\n";
    $msg_admin .= "📌 شناسه سفارش: <code>{$order_id}</code>";
    $kb_admin = json_encode(['inline_keyboard' => [[
        ['text' => '✅ تایید و اعمال', 'callback_data' => "rcfg_approve_{$order_id}"],
        ['text' => '❌ رد کردن',       'callback_data' => "rcfg_reject_{$order_id}"],
    ]]]);
    $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
    foreach ($admin_targets as $admin) { sendmessage($admin, $msg_admin, $kb_admin, 'HTML'); }

    sendmessage($from_id,
        "✅ <b>شماره پیگیری ثبت شد</b>\n\n📌 شناسه سفارش: <code>{$order_id}</code>\n⏳ بعد از تایید واریز توسط ادمین، حجم/مدت به حساب نمایندگی شما اضافه می‌شود.",
        $keyboard, 'HTML');

    step('home', $from_id);
    $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
    return true;
}

// ------------------------------------------------------------------
// rcfg_deliver_order — تابع مشترک تحویل/اعمال سفارش کانفیگ نمایندگی
// روی جدول reseller حجم و مدت رو اضافه می‌کنه (volume_limit += ، auto_disable_days امتداد پیدا می‌کنه)
// صدا زده می‌شه از کال‌بک تایید دستی ادمین (کارت‌به‌کارت) و از callback درگاه‌ها
// ------------------------------------------------------------------
function rcfg_deliver_order($order_id, $admin_id = null)
{
    global $pdo;

    $o = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=?");
    $o->execute([$order_id]);
    $o = $o->fetch(PDO::FETCH_ASSOC);

    if (!$o) return ['ok' => false, 'msg' => '❌ سفارش یافت نشد'];
    if ($o['delivered']) return ['ok' => false, 'msg' => '⚠️ این سفارش قبلاً اعمال شده'];
    if (($o['approval_status'] ?? '') !== 'approved') {
        return ['ok' => false, 'msg' => '❌ این سفارش هنوز توسط مدیر تایید نشده'];
    }

    $reseller_row = get_reseller($o['id_user']);
    if (!$reseller_row) return ['ok' => false, 'msg' => '❌ حساب نمایندگی یافت نشد'];

    $extra_volume_bytes = intval($o['volume_gb']) * 1073741824;
    $pdo->prepare("UPDATE reseller SET volume_limit = volume_limit + ? WHERE id_user=?")
        ->execute([$o['volume_gb'], $o['id_user']]);

    $pdo->prepare("UPDATE reseller_cfg_order SET payment_status='paid', delivered=1, paid_at=? WHERE order_id=?")
        ->execute([time(), $order_id]);

    $vol_txt = $o['volume_gb'] >= 1024 ? round($o['volume_gb'] / 1024, 2) . ' TB' : $o['volume_gb'] . ' GB';
    sendmessage($o['id_user'],
        "🎉 <b>کانفیگ نمایندگی شما اعمال شد!</b>\n\n📦 حجم اضافه‌شده: <b>{$vol_txt}</b>\n⏳ مدت: <b>{$o['days']} روز</b>\n\nاز بخش 🤝 پنل نمایندگی → 📦 کانفیگ نمایندگی استفاده کنید.",
        null, 'HTML');

    global $adminnumber;
    sendmessage($adminnumber,
        "✅ <b>کانفیگ نمایندگی اعمال شد</b>\n\n👤 کاربر: <code>{$o['id_user']}</code>\n📦 حجم: <b>{$vol_txt}</b>\n📌 سفارش: <code>{$order_id}</code>",
        null, 'HTML');

    return ['ok' => true, 'msg' => '✅ سفارش با موفقیت اعمال شد'];
}

function _rcfg_get_approved_order(string $order_id, $user_id): ?array
{
    global $pdo;
    $s = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=? AND id_user=? AND approval_status='approved' AND delivered=0");
    $s->execute([$order_id, $user_id]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

function _rcfg_payment_options_kb(string $order_id): ?string
{
    $setting = select('setting', '*');
    $rows    = [];

    $cart_status  = select('PaySetting', 'ValuePay', 'NamePay', 'Cartstatus', 'select')['ValuePay'] ?? 'offcard';
    $now_status   = select('PaySetting', 'ValuePay', 'NamePay', 'nowpaymentstatus', 'select')['ValuePay'] ?? 'offnowpayment';
    $aqaye_status = select('PaySetting', 'ValuePay', 'NamePay', 'statusaqayepardakht', 'select')['ValuePay'] ?? 'offaqayepardakht';
    $zarin_status = select('PaySetting', 'ValuePay', 'NamePay', 'statuszarinpal', 'select')['ValuePay'] ?? 'offzarinpal';

    $zarin_key = select('PaySetting', 'ValuePay', 'NamePay', 'merchant_id_zarinpal', 'select')['ValuePay'] ?? '';
    $aqaye_key = select('PaySetting', 'ValuePay', 'NamePay', 'merchant_id_aqayepardakht', 'select')['ValuePay'] ?? '';
    $now_key   = select('PaySetting', 'ValuePay', 'NamePay', 'apinowpayment', 'select')['ValuePay'] ?? '';

    if (!empty($setting['bot_sale_card_num']) && $cart_status !== 'offcard') {
        $rows[] = [['text' => '💳 پرداخت کارت به کارت', 'callback_data' => "rcfg_pay_card_{$order_id}"]];
    }
    if (!empty($zarin_key) && $zarin_status !== 'offzarinpal') {
        $rows[] = [['text' => '🔐 پرداخت آنلاین (زرین‌پال)', 'callback_data' => "rcfg_pay_zarinpal_{$order_id}"]];
    }
    if (!empty($aqaye_key) && $aqaye_status !== 'offaqayepardakht') {
        $rows[] = [['text' => '💳 پرداخت آنلاین (آقای پرداخت)', 'callback_data' => "rcfg_pay_aqaye_{$order_id}"]];
    }
    if (!empty($now_key) && $now_status !== 'offnowpayment') {
        $rows[] = [['text' => '🔐 پرداخت آنلاین (NowPayments)', 'callback_data' => "rcfg_pay_nowpayments_{$order_id}"]];
    }

    if (empty($rows)) return null;
    return json_encode(['inline_keyboard' => $rows]);
}

function _rcfg_payment_options_text(array $o): string
{
    $vol_txt = $o['volume_gb'] >= 1024 ? round($o['volume_gb'] / 1024, 2) . ' TB' : $o['volume_gb'] . ' GB';
    $msg  = "✅ <b>سفارش شما تایید شد!</b>\n\n💳 <b>انتخاب روش پرداخت</b>\n\n";
    $msg .= "📦 حجم: <b>{$vol_txt}</b> | ⏳ مدت: <b>{$o['days']} روز</b>\n";
    $msg .= "💰 مبلغ: <b>" . number_format($o['price']) . " تومان</b>\n\nروش پرداخت خود را انتخاب کنید:";
    return $msg;
}

function _rcfg_send_payment_options($user_id, string $order_id): void
{
    global $pdo;
    $o = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=?");
    $o->execute([$order_id]);
    $o = $o->fetch(PDO::FETCH_ASSOC);
    if (!$o) return;

    $kb = _rcfg_payment_options_kb($order_id);
    if (!$kb) {
        sendmessage($user_id,
            "⚠️ سفارش شما تایید شد اما در حال حاضر هیچ روش پرداختی فعال نیست. لطفاً با پشتیبانی تماس بگیرید.\n📌 سفارش: <code>{$order_id}</code>",
            null, 'HTML');
        return;
    }
    sendmessage($user_id, _rcfg_payment_options_text($o), $kb, 'HTML');
}


function handle_reseller_admin($from_id, $text, $datain, $user, $keyboard)
{
    global $pdo, $admin_ids, $ManagePanel;

    $kb_admin = json_encode(['keyboard' => [
        [['text' => '👥 لیست نمایندگان'], ['text' => '➕ اضافه کردن نماینده']],
        [['text' => '📨 درخواست‌های افزایش سقف'], ['text' => '📊 گزارش کامل نمایندگان']],
        [['text' => '🏠 بازگشت به منوی مدیریت']],
    ], 'resize_keyboard' => true]);

    $kb_edit = json_encode(['keyboard' => [
        [['text' => '📦 تنظیم سقف حجم'], ['text' => '🔢 تنظیم سقف کانفیگ']],
        [['text' => '💵 تنظیم قیمت/گیگ'], ['text' => '📅 تنظیم قیمت/ماه']],
        [['text' => '🔌 تنظیم اینباندهای مجاز'], ['text' => '⏰ تنظیم روزهای تمدید']],
        [['text' => '💳 شارژ کیف پول نماینده'], ['text' => '📊 گزارش این نماینده']],
        [['text' => '✅ فعال کردن'], ['text' => '🚫 مسدود کردن']],
        [['text' => '🗑 حذف نماینده']],
        [['text' => '🔙 بازگشت']],
    ], 'resize_keyboard' => true]);

    $kb_back = json_encode(['keyboard' => [[['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]);

    // ---- منوی اصلی مدیریت نمایندگان ----
    if ($text == '🤝 مدیریت نمایندگان') {
        sendmessage($from_id, "🤝 <b>مدیریت نمایندگان</b>", $kb_admin, 'HTML');
        step('home', $from_id);
        return true;
    }

    // بازگشت به منوی ادمین — این رو handle نکن، بذار admin.php خودش handle کنه
    if ($text == '🏠 بازگشت به منوی مدیریت') {
        return false;
    }

    // ================================================================
    // ---- لیست نمایندگان ----
    // ================================================================
    if ($text == '👥 لیست نمایندگان') {
        $list = $pdo->query("SELECT * FROM reseller ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($list)) { sendmessage($from_id, "📋 هیچ نماینده‌ای ثبت نشده.", $kb_admin, 'HTML'); return true; }
        $msg = "👥 <b>لیست نمایندگان:</b>\n\n";
        foreach ($list as $r) {
            $icon = ['active' => '✅', 'pending' => '⏳', 'blocked' => '🚫'][$r['status']] ?? '❓';
            $remain = max(0, $r['volume_limit'] - $r['volume_used']);
            $msg .= "$icon <code>{$r['id_user']}</code> — " . format_gb($remain) . "/" . format_gb($r['volume_limit']);
            if ($r['config_limit'] > 0) $msg .= " | cfg: {$r['config_used']}/{$r['config_limit']}";
            $msg .= " | 💰" . number_format($r['wallet']) . "\n";
        }
        $msg .= "\n📝 آیدی نماینده را بفرستید:";
        sendmessage($from_id, $msg, $kb_admin, 'HTML');
        step('reseller_admin_select', $from_id);
        return true;
    }

    if ($user['step'] == 'reseller_admin_select') {
        // دکمه‌های منوی ادمین — اگه زده شد step رو ریست کن و به handler اصلی پاس بده
        $admin_menu_buttons = [
            '🔙 بازگشت', '🏠 بازگشت به منوی مدیریت',
            '👥 لیست نمایندگان', '➕ اضافه کردن نماینده',
            '📨 درخواست‌های افزایش سقف', '📊 گزارش کامل نمایندگان',
            '🤝 مدیریت نمایندگان',
        ];
        if (in_array($text, $admin_menu_buttons, true)) {
            step('home', $from_id);
            $user['step'] = 'home'; // آپدیت محلی تا ادامه کد درست کار کنه
            // fall through — handler پایین‌تر همین متن رو پیک می‌کنه
        } elseif (!is_numeric(trim($text))) {
            // فقط برای متن‌های غیرمنویی پیام خطا بده
            sendmessage($from_id, "❌ آیدی عددی وارد کنید.", $kb_admin, 'HTML');
            return true;
        } else {
            $r = get_reseller(trim($text));
            if (!$r) { sendmessage($from_id, "❌ نماینده‌ای پیدا نشد.", $kb_admin, 'HTML'); step('home', $from_id); return true; }
            update("user", "Processing_value", trim($text), "id", $from_id);
            sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML');
            step('reseller_admin_edit', $from_id);
            return true;
        }
    }

    if ($user['step'] == 'reseller_admin_edit') {
        $target = $user['Processing_value'];

        // دکمه بازگشت از منوی ویرایش
        if ($text == '🔙 بازگشت') {
            sendmessage($from_id, "🤝 <b>مدیریت نمایندگان</b>", $kb_admin, 'HTML');
            step('home', $from_id);
            return true;
        }

        // اگه target خالیه برگرد
        if (empty($target) || !is_numeric($target)) {
            sendmessage($from_id, "⚠️ خطا: نماینده‌ای انتخاب نشده. دوباره از لیست نمایندگان انتخاب کنید.", $kb_admin, 'HTML');
            step('home', $from_id);
            return true;
        }

        if ($text == '📦 تنظیم سقف حجم') {
            sendmessage($from_id, "📦 سقف حجم جدید را به گیگابایت وارد کنید:", $kb_back, 'HTML');
            step('reseller_set_volume_limit', $from_id); return true;
        }
        if ($text == '🔢 تنظیم سقف کانفیگ') {
            sendmessage($from_id, "🔢 سقف تعداد کانفیگ را وارد کنید (۰ = نامحدود):", $kb_back, 'HTML');
            step('reseller_set_config_limit', $from_id); return true;
        }
        if ($text == '💵 تنظیم قیمت/گیگ') {
            sendmessage($from_id, "💵 قیمت هر گیگابایت (تومان):", $kb_back, 'HTML');
            step('reseller_set_price_gb', $from_id); return true;
        }
        if ($text == '📅 تنظیم قیمت/ماه') {
            sendmessage($from_id, "📅 قیمت هر ماه (تومان):", $kb_back, 'HTML');
            step('reseller_set_price_month', $from_id); return true;
        }
        if ($text == '🔌 تنظیم اینباندهای مجاز') {
            // گرفتن لیست اینباندها از پنل نماینده
            $r = get_reseller($target);
            if (!$r['panel_name']) { sendmessage($from_id, "❌ ابتدا پنل نماینده را تنظیم کنید.", $kb_back, 'HTML'); return true; }
            $inbounds = $ManagePanel->getInbounds($r['panel_name']);
            if (empty($inbounds)) { sendmessage($from_id, "❌ اینباندی در این پنل یافت نشد.", $kb_back, 'HTML'); return true; }
            $current = json_decode($r['allowed_inbounds'] ?? '[]', true) ?: [];
            $btns = [];
            foreach ($inbounds as $ib) {
                $tag = $ib['tag'] ?? $ib['remark'] ?? $ib['id'];
                $is_allowed = in_array($tag, $current) ? '✅ ' : '⬜ ';
                $btns[] = [['text' => "$is_allowed$tag", 'callback_data' => "res_inb_toggle_{$target}_{$tag}"]];
            }
            $btns[] = [['text' => '💾 ذخیره', 'callback_data' => "res_inb_save_$target"]];
            sendmessage($from_id, "🔌 <b>اینباندهای مجاز برای نماینده <code>$target</code></b>\n\nتیک بزنید:", json_encode(['inline_keyboard' => $btns]), 'HTML');
            return true;
        }
        if ($text == '⏰ تنظیم روزهای تمدید') {
            sendmessage($from_id, "⏰ پس از انقضا چند روز کانفیگ غیرفعال نشه (۰ = بلافاصله):", $kb_back, 'HTML');
            step('reseller_set_autodis', $from_id); return true;
        }
        if ($text == '💳 شارژ کیف پول نماینده') {
            $r = get_reseller($target);
            sendmessage($from_id, "💳 موجودی فعلی: <b>" . number_format($r['wallet']) . " تومان</b>\n\nمبلغ شارژ (تومان) را وارد کنید:\n(برای کسر، عدد منفی وارد کنید مثلاً: -50000)", $kb_back, 'HTML');
            step('reseller_charge_wallet', $from_id); return true;
        }
        if ($text == '📊 گزارش این نماینده') {
            $r = get_reseller($target);
            sendmessage($from_id, _reseller_report($target, $r), $kb_edit, 'HTML');
            return true;
        }
        if ($text == '✅ فعال کردن') {
            $r = get_reseller($target);
            if (!$r['panel_name']) {
                sendmessage($from_id, "⚠️ ابتدا پنل نماینده را تنظیم کنید.\nنام پنل را بفرستید:", $kb_back, 'HTML');
                step('reseller_set_panel', $from_id); return true;
            }
            $pdo->prepare("UPDATE reseller SET status='active' WHERE id_user=?")->execute([$target]);
            sendmessage($from_id, "✅ نماینده فعال شد.", $kb_admin, 'HTML');
            sendmessage($target, "🎉 <b>حساب نمایندگی شما فعال شد!</b>\n\nاز دکمه 🤝 پنل نمایندگی استفاده کنید.", null, 'HTML');
            step('home', $from_id); return true;
        }
        if ($text == '🚫 مسدود کردن') {
            $pdo->prepare("UPDATE reseller SET status='blocked' WHERE id_user=?")->execute([$target]);
            sendmessage($from_id, "🚫 نماینده مسدود شد.", $kb_admin, 'HTML');
            sendmessage($target, "🚫 حساب نمایندگی شما مسدود شده است.", null, 'HTML');
            step('home', $from_id); return true;
        }
        if ($text == '🗑 حذف نماینده') {
            $pdo->prepare("DELETE FROM reseller WHERE id_user=?")->execute([$target]);
            $pdo->prepare("DELETE FROM reseller_product WHERE id_reseller=?")->execute([$target]);
            sendmessage($from_id, "🗑 نماینده حذف شد.", $kb_admin, 'HTML');
            sendmessage($target, "❌ حساب نمایندگی شما حذف شده است.", null, 'HTML');
            step('home', $from_id); return true;
        }
    }

    // ---- handlers مراحل ست کردن ----
    if ($user['step'] == 'reseller_set_volume_limit') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        if (!ctype_digit($text)) { sendmessage($from_id, "❌ عدد صحیح وارد کنید.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET volume_limit=? WHERE id_user=?")->execute([intval($text), $target]);
        sendmessage($from_id, "✅ سقف حجم به " . format_gb(intval($text)) . " تنظیم شد.", $kb_edit, 'HTML');
        sendmessage($target, "📦 سقف حجم شما به <b>" . format_gb(intval($text)) . "</b> تنظیم شد.", null, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }
    if ($user['step'] == 'reseller_set_config_limit') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        if (!ctype_digit($text)) { sendmessage($from_id, "❌ عدد صحیح وارد کنید.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET config_limit=? WHERE id_user=?")->execute([intval($text), $target]);
        $lbl = intval($text) == 0 ? 'نامحدود' : intval($text) . ' عدد';
        sendmessage($from_id, "✅ سقف کانفیگ به $lbl تنظیم شد.", $kb_edit, 'HTML');
        sendmessage($target, "🔢 سقف کانفیگ شما به <b>$lbl</b> تنظیم شد.", null, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }
    if ($user['step'] == 'reseller_set_price_gb') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        if (!ctype_digit($text)) { sendmessage($from_id, "❌ عدد معتبر وارد کنید.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET price_per_gb=? WHERE id_user=?")->execute([intval($text), $target]);
        sendmessage($from_id, "✅ قیمت/گیگ به " . number_format(intval($text)) . " تومان تنظیم شد.", $kb_edit, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }
    if ($user['step'] == 'reseller_set_price_month') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        if (!ctype_digit($text)) { sendmessage($from_id, "❌ عدد معتبر وارد کنید.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET price_per_month=? WHERE id_user=?")->execute([intval($text), $target]);
        sendmessage($from_id, "✅ قیمت/ماه به " . number_format(intval($text)) . " تومان تنظیم شد.", $kb_edit, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }
    if ($user['step'] == 'reseller_set_autodis') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        if (!ctype_digit($text)) { sendmessage($from_id, "❌ عدد معتبر وارد کنید.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET auto_disable_days=? WHERE id_user=?")->execute([intval($text), $target]);
        sendmessage($from_id, "✅ تنظیم شد: " . (intval($text) == 0 ? 'غیرفعال بلافاصله' : "بعد از " . intval($text) . " روز") . ".", $kb_edit, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }
    if ($user['step'] == 'reseller_set_panel') {
        if ($text == '🔙 بازگشت') { sendmessage($from_id, "🤝 <b>مدیریت نمایندگان</b>", $kb_admin, 'HTML'); step('home', $from_id); return true; }
        $panel_exists = select("marzban_panel", "name_panel", "name_panel", $text, "select");
        if (!$panel_exists) { sendmessage($from_id, "❌ این پنل در ربات ثبت نشده.", $kb_back, 'HTML'); return true; }
        $target = $user['Processing_value'];
        $pdo->prepare("UPDATE reseller SET panel_name=?, status='active' WHERE id_user=?")->execute([$text, $target]);
        sendmessage($from_id, "✅ پنل تنظیم و نماینده فعال شد.", $kb_admin, 'HTML');
        sendmessage($target, "🎉 <b>حساب نمایندگی شما فعال شد!</b>", null, 'HTML');
        step('home', $from_id); return true;
    }
    if ($user['step'] == 'reseller_charge_wallet') {
        if ($text == '🔙 بازگشت') { $r = get_reseller($user['Processing_value']); sendmessage($from_id, _reseller_info_text($r), $kb_edit, 'HTML'); step('reseller_admin_edit', $from_id); return true; }
        $target = $user['Processing_value'];
        $amount = intval(str_replace(',', '', $text));
        if ($amount == 0) { sendmessage($from_id, "❌ مبلغ نامعتبر.", $kb_back, 'HTML'); return true; }
        $r = get_reseller($target);
        $new_wallet = $r['wallet'] + $amount;
        if ($new_wallet < 0) { sendmessage($from_id, "❌ موجودی نماینده کافی نیست (موجودی: " . number_format($r['wallet']) . " تومان).", $kb_back, 'HTML'); return true; }
        $pdo->prepare("UPDATE reseller SET wallet=? WHERE id_user=?")->execute([$new_wallet, $target]);
        $action = $amount > 0 ? "+" . number_format($amount) : number_format($amount);
        sendmessage($from_id, "✅ کیف پول نماینده <code>$target</code>: $action تومان\nموجودی جدید: <b>" . number_format($new_wallet) . " تومان</b>", $kb_edit, 'HTML');
        sendmessage($target, $amount > 0 ? "💳 کیف پول شما <b>+" . number_format($amount) . " تومان</b> شارژ شد.\nموجودی: <b>" . number_format($new_wallet) . " تومان</b>" : "💳 <b>" . number_format(abs($amount)) . " تومان</b> از کیف پول شما کسر شد.\nموجودی: <b>" . number_format($new_wallet) . " تومان</b>", null, 'HTML');
        step('reseller_admin_edit', $from_id); return true;
    }

    // ================================================================
    // ---- اضافه کردن نماینده دستی ----
    // ================================================================
    if ($text == '➕ اضافه کردن نماینده') {
        sendmessage($from_id, "➕ آیدی عددی کاربر را بفرستید:", $kb_back, 'HTML');
        step('reseller_manual_add', $from_id); return true;
    }
    if ($user['step'] == 'reseller_manual_add') {
        // دکمه بازگشت
        if ($text == '🔙 بازگشت') {
            sendmessage($from_id, "🤝 <b>مدیریت نمایندگان</b>", $kb_admin, 'HTML');
            step('home', $from_id);
            return true;
        }
        if (!is_numeric(trim($text))) { sendmessage($from_id, "❌ آیدی باید عددی باشد.", $kb_back, 'HTML'); return true; }
        if (get_reseller(trim($text))) { sendmessage($from_id, "⚠️ این کاربر قبلاً نماینده است.", $kb_admin, 'HTML'); step('home', $from_id); return true; }
        $pdo->prepare("INSERT INTO reseller (id_user, panel_name, volume_limit, volume_used, config_limit, config_used, price_per_gb, price_per_month, wallet, status, created_at) VALUES (?, '', 0, 0, 0, 0, 0, 0, 0, 'pending', ?)")
            ->execute([trim($text), time()]);
        update("user", "Processing_value", trim($text), "id", $from_id);
        sendmessage($from_id, "✅ نماینده <code>" . trim($text) . "</code> اضافه شد.\n\nنام پنل مورد نظر را بفرستید:", $kb_back, 'HTML');
        step('reseller_set_panel', $from_id); return true;
    }

    // ================================================================
    // ---- درخواست‌های افزایش سقف ----
    // ================================================================
    if ($text == '📨 درخواست‌های افزایش سقف') {
        $reqs = $pdo->query("SELECT rr.*, u.username FROM reseller_request rr LEFT JOIN user u ON rr.id_user = u.id WHERE rr.status = 'pending' ORDER BY rr.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($reqs)) { sendmessage($from_id, "📨 درخواست در انتظاری وجود ندارد.", $kb_admin, 'HTML'); return true; }
        foreach ($reqs as $req) {
            $type = $req['volume_gb'] > 0 ? "📦 حجم: <b>" . format_gb($req['volume_gb']) . "</b>" : "🔢 کانفیگ: <b>{$req['config_count']} عدد</b>";
            $msg  = "📨 <b>درخواست افزایش سقف</b>\n\n"
                  . "👤 نماینده: <code>{$req['id_user']}</code> (@" . ($req['username'] ?? '-') . ")\n"
                  . "$type\n"
                  . "💰 مبلغ پرداختی: <b>" . number_format($req['total_price']) . " تومان</b>";
            $kb = json_encode(['inline_keyboard' => [[
                ['text' => '✅ تایید', 'callback_data' => "resreq_approve_{$req['id']}"],
                ['text' => '❌ رد + برگشت وجه', 'callback_data' => "resreq_reject_{$req['id']}"],
            ]]]);
            sendmessage($from_id, $msg, $kb, 'HTML');
        }
        return true;
    }

    // ================================================================
    // ---- گزارش کامل نمایندگان ----
    // ================================================================
    if ($text == '📊 گزارش کامل نمایندگان') {
        $resellers = $pdo->query("SELECT r.*, (SELECT COUNT(*) FROM reseller_invoice ri WHERE ri.id_reseller = r.id_user AND ri.status='active') as active_cfgs, (SELECT SUM(ri.price) FROM reseller_invoice ri WHERE ri.id_reseller = r.id_user) as total_income FROM reseller r WHERE r.status='active' ORDER BY r.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($resellers)) { sendmessage($from_id, "📊 هیچ نماینده فعالی وجود ندارد.", $kb_admin, 'HTML'); return true; }
        $total_income_all = 0;
        $msg = "📊 <b>گزارش کامل نمایندگان</b>\n\n";
        foreach ($resellers as $r) {
            $remain = max(0, $r['volume_limit'] - $r['volume_used']);
            $income = $r['total_income'] ?? 0;
            $total_income_all += $income;
            $msg .= "👤 <code>{$r['id_user']}</code>\n"
                  . "   📦 " . format_gb($remain) . "/" . format_gb($r['volume_limit'])
                  . " | 🔢 {$r['config_used']}"
                  . ($r['config_limit'] > 0 ? "/{$r['config_limit']}" : '')
                  . " | ✅ {$r['active_cfgs']}"
                  . " | 💰" . number_format($income) . "\n";
        }
        $msg .= "\n💰 <b>درآمد کل: " . number_format($total_income_all) . " تومان</b>";
        sendmessage($from_id, $msg, $kb_admin, 'HTML');
        return true;
    }

    return false;
}

// ================================================================
// callbacks (inline keyboard)
// ================================================================
function handle_reseller_callbacks($from_id, $datain, $message_id, $callback_query_id)
{
    global $pdo, $admin_ids, $ManagePanel;

    // ---- تایید/رد درخواست نمایندگی ----
    if (preg_match('/^reseller_approve_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $target = $m[1];
        $pdo->prepare("UPDATE reseller SET status='pending' WHERE id_user=?")->execute([$target]);
        Editmessagetext($from_id, $message_id, "✅ درخواست تایید شد.\n\nآیدی: <code>$target</code>\n\nپنل نماینده را تنظیم کنید.", json_encode(['inline_keyboard' => []]));
        update("user", "Processing_value", $target, "id", $from_id);
        sendmessage($from_id, "📌 نام پنل را بفرستید:", null, 'HTML');
        step('reseller_set_panel', $from_id);
        sendmessage($target, "✅ درخواست نمایندگی شما تایید شد! منتظر تنظیم اطلاعات توسط مدیر باشید.", null, 'HTML');
        return true;
    }
    if (preg_match('/^reseller_reject_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $target = $m[1];
        $pdo->prepare("DELETE FROM reseller WHERE id_user=? AND status='pending'")->execute([$target]);
        Editmessagetext($from_id, $message_id, "❌ درخواست رد شد.", json_encode(['inline_keyboard' => []]));
        sendmessage($target, "❌ درخواست نمایندگی شما رد شد.", null, 'HTML');
        return true;
    }

    // ---- ادمین: تایید واریز کارت‌به‌کارت کانفیگ نمایندگی → اعمال نهایی ----
    if (preg_match('/^rcfg_approve_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $result   = rcfg_deliver_order($order_id, $from_id);
        AnswerCallbackQuery($callback_query_id, $result['msg'], true);
        if ($result['ok']) {
            Editmessagetext($from_id, $message_id, "✅ سفارش اعمال شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        }
        return true;
    }

    // ---- ادمین: رد واریز کارت‌به‌کارت کانفیگ نمایندگی ----
    if (preg_match('/^rcfg_reject_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $o = $pdo->prepare("SELECT * FROM reseller_cfg_order WHERE order_id=?");
        $o->execute([$order_id]);
        $o = $o->fetch(PDO::FETCH_ASSOC);
        if (!$o) { AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true); return true; }
        $pdo->prepare("UPDATE reseller_cfg_order SET payment_status='rejected' WHERE order_id=?")->execute([$order_id]);
        sendmessage($o['id_user'], "❌ <b>سفارش شما رد شد</b>\n\n📌 شناسه: <code>{$order_id}</code>", null, 'HTML');
        AnswerCallbackQuery($callback_query_id, '❌ سفارش رد شد', true);
        Editmessagetext($from_id, $message_id, "❌ سفارش رد شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        return true;
    }

    // ---- مدیریت محصولات نماینده ----

    if ($datain == 'res_prod_add') {
        sendmessage($from_id, "📦 نام محصول را وارد کنید:", null, 'HTML');
        step('reseller_add_product_name', $from_id);
        return true;
    }
    if (preg_match('/^res_prod_toggle_(\d+)$/', $datain, $m)) {
        $pid = $m[1];
        $p = $pdo->prepare("SELECT * FROM reseller_product WHERE id=? AND id_reseller=?");
        $p->execute([$pid, $from_id]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) return true;
        $new = $p['status'] == 'active' ? 'inactive' : 'active';
        $pdo->prepare("UPDATE reseller_product SET status=? WHERE id=?")->execute([$new, $pid]);
        AnswerCallbackQuery($callback_query_id, $new == 'active' ? '✅ محصول فعال شد' : '⏸ محصول غیرفعال شد');
        return true;
    }
    if (preg_match('/^res_prod_del_(\d+)$/', $datain, $m)) {
        $pdo->prepare("DELETE FROM reseller_product WHERE id=? AND id_reseller=?")->execute([$m[1], $from_id]);
        Editmessagetext($from_id, $message_id, "🗑 محصول حذف شد.", json_encode(['inline_keyboard' => []]));
        return true;
    }

    // ---- ساخت کانفیگ توسط نماینده ----
    if (preg_match('/^res_build_(\d+)$/', $datain, $m)) {
        $pid  = $m[1];
        $r    = get_reseller($from_id);
        if (!$r || $r['status'] != 'active') return true;

        $p = $pdo->prepare("SELECT * FROM reseller_product WHERE id=? AND id_reseller=? AND status='active'");
        $p->execute([$pid, $from_id]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) { AnswerCallbackQuery($callback_query_id, '❌ محصول یافت نشد'); return true; }

        // چک سقف‌ها
        if ($r['config_limit'] > 0 && $r['config_used'] >= $r['config_limit']) {
            AnswerCallbackQuery($callback_query_id, '⚠️ به سقف کانفیگ رسیده‌اید'); return true;
        }
        if ($p['volume_gb'] > ($r['volume_limit'] - $r['volume_used'])) {
            AnswerCallbackQuery($callback_query_id, '⚠️ حجم کافی ندارید'); return true;
        }
        // چک کیف پول
        $cost = ($p['volume_gb'] * $r['price_per_gb']) + ($r['price_per_month'] * max(1, ceil($p['days'] / 30)));
        if ($r['wallet'] < $cost) {
            Editmessagetext($from_id, $message_id, "❌ موجودی کیف پول کافی نیست.\n\nهزینه: <b>" . number_format($cost) . " تومان</b>\nموجودی: <b>" . number_format($r['wallet']) . " تومان</b>", json_encode(['inline_keyboard' => []]));
            return true;
        }

        // ساخت username
        $username = 'res_' . $from_id . '_' . substr(md5(uniqid()), 0, 6);
        $expire_at = time() + ($p['days'] * 86400);
        $data_limit = $p['volume_gb'] * 1073741824;

        // اینباندهای مجاز
        $allowed = json_decode($r['allowed_inbounds'] ?? '[]', true) ?: [];

        $datac = [
            'expire'     => $expire_at,
            'data_limit' => $data_limit,
        ];
        // Squad برای remnawave
        $panel_info = select("marzban_panel", "*", "name_panel", $r['panel_name'], "select");
        if ($panel_info['type'] == 'remnawave') {
            $parsed = _remna_parse_inboundid($r['panel_name']);
            if (!empty($parsed['main_squad'])) $datac['squad_uuid'] = $parsed['main_squad'];
        }

        $result = $ManagePanel->createUser($r['panel_name'], $username, $datac);
        if (!isset($result['username'])) {
            Editmessagetext($from_id, $message_id, "❌ خطا در ساخت کانفیگ: " . json_encode($result['msg'] ?? ''), json_encode(['inline_keyboard' => []]));
            return true;
        }

        // ذخیره در reseller_invoice
        $pdo->prepare("INSERT INTO reseller_invoice (id_reseller, username, product_name, volume_gb, days, price, status, created_at, expire_at) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)")
            ->execute([$from_id, $username, $p['name'], $p['volume_gb'], $p['days'], $p['price'], time(), $expire_at]);

        // آپدیت آمار نماینده
        $pdo->prepare("UPDATE reseller SET volume_used=volume_used+?, config_used=config_used+1, wallet=wallet-? WHERE id_user=?")
            ->execute([$p['volume_gb'], $cost, $from_id]);

        // گرفتن لینک سابسکریپشن
        $user_data = $ManagePanel->DataUser($r['panel_name'], $username);
        $sub_url   = $user_data['subscription_url'] ?? ($user_data['links'][0] ?? 'N/A');

        Editmessagetext($from_id, $message_id, "✅ <b>کانفیگ ساخته شد!</b>\n\n"
            . "👤 یوزرنیم: <code>$username</code>\n"
            . "📦 حجم: <b>{$p['volume_gb']} GB</b>\n"
            . "📅 روزها: <b>{$p['days']} روز</b>\n"
            . "💰 هزینه: <b>" . number_format($cost) . " تومان</b>\n\n"
            . "🔗 لینک سابسکریپشن:\n<code>$sub_url</code>", json_encode(['inline_keyboard' => []]));
        return true;
    }

    // ---- مشاهده/مدیریت کانفیگ‌ها ----
    if (preg_match('/^res_cfg_(\d+)$/', $datain, $m)) {
        $cid = $m[1];
        $c = $pdo->prepare("SELECT * FROM reseller_invoice WHERE id=? AND id_reseller=?");
        $c->execute([$cid, $from_id]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) return true;

        $r = get_reseller($from_id);
        $du = $ManagePanel->DataUser($r['panel_name'], $c['username']);
        $used = isset($du['used_traffic']) ? round($du['used_traffic'] / 1073741824, 2) . ' GB' : '—';
        $total_gb = round($c['volume_gb'], 2) . ' GB';
        $expire_fa = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
        $status_text = ['active' => '✅ فعال', 'disabled' => '🔴 غیرفعال', 'expired' => '⏰ منقضی'][$du['status'] ?? $c['status']] ?? '—';

        $sub_url = $du['subscription_url'] ?? ($du['links'][0] ?? 'N/A');

        $msg = "📌 <b>{$c['username']}</b>\n\n"
             . "📦 حجم: $used / $total_gb\n"
             . "📅 انقضا: $expire_fa\n"
             . "⚡ وضعیت: $status_text\n\n"
             . "🔗 لینک:\n<code>$sub_url</code>";

        $btns = [
            [
                ['text' => '✅ فعال', 'callback_data' => "res_cfg_en_{$cid}"],
                ['text' => '🔴 غیرفعال', 'callback_data' => "res_cfg_dis_{$cid}"],
            ],
            [
                ['text' => '⏰ تمدید (+۳۰ روز)', 'callback_data' => "res_cfg_renew_{$cid}"],
                ['text' => '🗑 حذف', 'callback_data' => "res_cfg_del_{$cid}"],
            ],
        ];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $btns]));
        return true;
    }

    // فعال/غیرفعال/تمدید/حذف کانفیگ نماینده
    if (preg_match('/^res_cfg_(en|dis|renew|del)_(\d+)$/', $datain, $m)) {
        $action = $m[1]; $cid = $m[2];
        $c = $pdo->prepare("SELECT * FROM reseller_invoice WHERE id=? AND id_reseller=?");
        $c->execute([$cid, $from_id]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) return true;
        $r = get_reseller($from_id);

        if ($action == 'en') {
            $ManagePanel->Enableuser($r['panel_name'], $c['username']);
            $pdo->prepare("UPDATE reseller_invoice SET status='active' WHERE id=?")->execute([$cid]);
            AnswerCallbackQuery($callback_query_id, '✅ فعال شد');
        } elseif ($action == 'dis') {
            $ManagePanel->Disableuser($r['panel_name'], $c['username']);
            $pdo->prepare("UPDATE reseller_invoice SET status='disabled' WHERE id=?")->execute([$cid]);
            AnswerCallbackQuery($callback_query_id, '🔴 غیرفعال شد');
        } elseif ($action == 'renew') {
            // هزینه ۳۰ روز
            $cost_month = $r['price_per_month'];
            if ($r['wallet'] < $cost_month) {
                AnswerCallbackQuery($callback_query_id, '❌ موجودی کافی نیست'); return true;
            }
            $new_expire = max(time(), $c['expire_at']) + 2592000; // 30 روز
            $du = $ManagePanel->DataUser($r['panel_name'], $c['username']);
            $ManagePanel->Modifyuser($c['username'], $r['panel_name'], ['expire' => $new_expire]);
            $pdo->prepare("UPDATE reseller_invoice SET expire_at=?, days=days+30, status='active' WHERE id=?")->execute([$new_expire, $cid]);
            $pdo->prepare("UPDATE reseller SET wallet=wallet-? WHERE id_user=?")->execute([$cost_month, $from_id]);
            AnswerCallbackQuery($callback_query_id, '✅ ۳۰ روز تمدید شد');
        } elseif ($action == 'del') {
            $du = $ManagePanel->DataUser($r['panel_name'], $c['username']);
            if (isset($du['status'])) $ManagePanel->RemoveUser($r['panel_name'], $c['username']);
            $pdo->prepare("UPDATE reseller_invoice SET status='removed' WHERE id=?")->execute([$cid]);
            $pdo->prepare("UPDATE reseller SET config_used=GREATEST(0,config_used-1) WHERE id_user=?")->execute([$from_id]);
            AnswerCallbackQuery($callback_query_id, '🗑 حذف شد');
        }
        return true;
    }

    // ---- پرداخت کیف پول برای حجم ----
    if (preg_match('/^res_vol_pay_(\d+)_(\d+)$/', $datain, $m)) {
        $gb = intval($m[1]); $total = intval($m[2]);
        $r = get_reseller($from_id);
        if (!$r) return true;
        if ($total <= 0 || $r['price_per_gb'] <= 0) {
            Editmessagetext($from_id, $message_id, "⚠️ قیمت هر گیگابایت برای حساب شما تعیین نشده است.\n\nبا ادمین تماس بگیرید.", json_encode(['inline_keyboard' => []]));
            return true;
        }
        if ($r['wallet'] < $total) {
            Editmessagetext($from_id, $message_id, "❌ موجودی کافی نیست.\n\nموجودی: <b>" . number_format($r['wallet']) . " تومان</b>\nنیاز: <b>" . number_format($total) . " تومان</b>", json_encode(['inline_keyboard' => []]));
            return true;
        }
        // ذخیره درخواست و کسر از کیف پول
        $pdo->prepare("INSERT INTO reseller_request (id_user, volume_gb, config_count, total_price, status, created_at) VALUES (?, ?, 0, ?, 'pending', ?)")
            ->execute([$from_id, $gb, $total, time()]);
        $req_id = $pdo->lastInsertId();
        $pdo->prepare("UPDATE reseller SET wallet=wallet-? WHERE id_user=?")->execute([$total, $from_id]);
        Editmessagetext($from_id, $message_id, "✅ مبلغ از کیف پول کسر شد.\n\n⏳ در انتظار تایید مدیر...", json_encode(['inline_keyboard' => []]));
        $msg = "📨 <b>درخواست افزایش سقف حجم</b>\n\n👤 نماینده: <code>$from_id</code>\n📦 حجم: <b>" . format_gb($gb) . "</b>\n💰 مبلغ: <b>" . number_format($total) . " تومان</b>";
        $kb = json_encode(['inline_keyboard' => [[['text' => '✅ تایید', 'callback_data' => "resreq_approve_$req_id"], ['text' => '❌ رد + برگشت', 'callback_data' => "resreq_reject_$req_id"]]]]);
        foreach ($admin_ids as $admin) { sendmessage($admin, $msg, $kb, 'HTML'); }
        return true;
    }

    // ---- درخواست افزایش سقف کانفیگ ----
    if (preg_match('/^res_cfg_req_(\d+)$/', $datain, $m)) {
        $count = intval($m[1]);
        $r = get_reseller($from_id);
        $pdo->prepare("INSERT INTO reseller_request (id_user, volume_gb, config_count, total_price, status, created_at) VALUES (?, 0, ?, 0, 'pending', ?)")
            ->execute([$from_id, $count, time()]);
        $req_id = $pdo->lastInsertId();
        Editmessagetext($from_id, $message_id, "✅ درخواست ارسال شد.\n\n⏳ در انتظار تایید مدیر...", json_encode(['inline_keyboard' => []]));
        $msg = "📨 <b>درخواست افزایش سقف کانفیگ</b>\n\n👤 نماینده: <code>$from_id</code>\n🔢 تعداد: <b>$count کانفیگ</b>";
        $kb = json_encode(['inline_keyboard' => [[['text' => '✅ تایید', 'callback_data' => "resreq_approve_$req_id"], ['text' => '❌ رد', 'callback_data' => "resreq_reject_$req_id"]]]]);
        foreach ($admin_ids as $admin) { sendmessage($admin, $msg, $kb, 'HTML'); }
        return true;
    }

    // ---- تایید/رد درخواست سقف توسط ادمین ----
    if (preg_match('/^resreq_approve_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $req_id = intval($m[1]);
        $req = $pdo->prepare("SELECT * FROM reseller_request WHERE id=?");
        $req->execute([$req_id]);
        $req = $req->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] != 'pending') { Editmessagetext($from_id, $message_id, "⚠️ قبلاً پردازش شده.", json_encode(['inline_keyboard' => []])); return true; }
        if ($req['volume_gb'] > 0) {
            $pdo->prepare("UPDATE reseller SET volume_limit=volume_limit+? WHERE id_user=?")->execute([$req['volume_gb'], $req['id_user']]);
            sendmessage($req['id_user'], "✅ <b>درخواست تایید شد!</b>\n📦 " . format_gb($req['volume_gb']) . " به سقف حجم شما اضافه شد.", null, 'HTML');
        } else {
            $pdo->prepare("UPDATE reseller SET config_limit=config_limit+? WHERE id_user=?")->execute([$req['config_count'], $req['id_user']]);
            sendmessage($req['id_user'], "✅ <b>درخواست تایید شد!</b>\n🔢 {$req['config_count']} کانفیگ به سقف شما اضافه شد.", null, 'HTML');
        }
        $pdo->prepare("UPDATE reseller_request SET status='approved', reviewed_at=? WHERE id=?")->execute([time(), $req_id]);
        Editmessagetext($from_id, $message_id, "✅ تایید شد.", json_encode(['inline_keyboard' => []]));
        return true;
    }
    if (preg_match('/^resreq_reject_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $req_id = intval($m[1]);
        $req = $pdo->prepare("SELECT * FROM reseller_request WHERE id=?");
        $req->execute([$req_id]);
        $req = $req->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] != 'pending') { Editmessagetext($from_id, $message_id, "⚠️ قبلاً پردازش شده.", json_encode(['inline_keyboard' => []])); return true; }
        // برگشت وجه به کیف پول
        if ($req['total_price'] > 0) {
            $pdo->prepare("UPDATE reseller SET wallet=wallet+? WHERE id_user=?")->execute([$req['total_price'], $req['id_user']]);
            sendmessage($req['id_user'], "❌ <b>درخواست رد شد.</b>\n💳 " . number_format($req['total_price']) . " تومان به کیف پول برگشت.", null, 'HTML');
        } else {
            sendmessage($req['id_user'], "❌ <b>درخواست افزایش سقف کانفیگ رد شد.</b>", null, 'HTML');
        }
        $pdo->prepare("UPDATE reseller_request SET status='rejected', reviewed_at=? WHERE id=?")->execute([time(), $req_id]);
        Editmessagetext($from_id, $message_id, "❌ رد شد.", json_encode(['inline_keyboard' => []]));
        return true;
    }

    if ($datain == 'res_cancel') {
        Editmessagetext($from_id, $message_id, "❌ لغو شد.", json_encode(['inline_keyboard' => []]));
        return true;
    }

    // ================================================================
    // callbacks تایید/رد درخواست‌های زیر ربات‌ها به ربات مادر
    // ================================================================
    if (preg_match('/^cbreq_approve_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $req_id = intval($m[1]);
        $req = $pdo->prepare("SELECT * FROM child_bot_request WHERE id=?");
        $req->execute([$req_id]);
        $req = $req->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] !== 'pending') {
            Editmessagetext($from_id, $message_id, "⚠️ این درخواست قبلاً پردازش شده.", json_encode(['inline_keyboard' => []]));
            return true;
        }
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$req['bot_token']]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        if ($req['request_type'] === 'volume') {
            $pdo->prepare("UPDATE reseller_bot SET volume_limit=volume_limit+? WHERE bot_token=?")
                ->execute([$req['amount'], $req['bot_token']]);
            $msg_owner = "✅ <b>درخواست تایید شد!</b>\n📦 <b>" . child_fmt_gb($req['amount']) . "</b> به سقف حجم شما اضافه شد.";
        } else {
            $pdo->prepare("UPDATE reseller_bot SET config_limit=config_limit+? WHERE bot_token=?")
                ->execute([$req['amount'], $req['bot_token']]);
            $msg_owner = "✅ <b>درخواست تایید شد!</b>\n🔢 <b>{$req['amount']} کانفیگ</b> به سقف شما اضافه شد.";
        }
        $pdo->prepare("UPDATE child_bot_request SET status='approved', reviewed_at=?, reviewed_by=? WHERE id=?")
            ->execute([time(), $from_id, $req_id]);

        // اطلاع به نماینده از طریق زیر ربات
        child_sendmessage($req['bot_token'], $bi['owner_id'], $msg_owner, null, 'HTML');

        Editmessagetext($from_id, $message_id,
            "✅ تایید شد.
🤖 ربات: @{$bi['bot_username']}
📋 نوع: {$req['request_type']}
📦 مقدار: {$req['amount']}",
            json_encode(['inline_keyboard' => []]));
        return true;
    }

    if (preg_match('/^cbreq_reject_(\d+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $req_id = intval($m[1]);
        $req = $pdo->prepare("SELECT * FROM child_bot_request WHERE id=?");
        $req->execute([$req_id]);
        $req = $req->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] !== 'pending') {
            Editmessagetext($from_id, $message_id, "⚠️ این درخواست قبلاً پردازش شده.", json_encode(['inline_keyboard' => []]));
            return true;
        }
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$req['bot_token']]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        // برگشت وجه به کیف پول زیر ربات
        if ($req['total_price'] > 0) {
            $pdo->prepare("UPDATE reseller_bot SET wallet=wallet+? WHERE bot_token=?")
                ->execute([$req['total_price'], $req['bot_token']]);
            $msg_owner = "❌ <b>درخواست رد شد.</b>\n💳 " . number_format($req['total_price']) . " تومان به کیف پول برگشت.";
        } else {
            $msg_owner = "❌ <b>درخواست افزایش سقف رد شد.</b>";
        }
        $pdo->prepare("UPDATE child_bot_request SET status='rejected', reviewed_at=?, reviewed_by=? WHERE id=?")
            ->execute([time(), $from_id, $req_id]);

        child_sendmessage($req['bot_token'], $bi['owner_id'], $msg_owner, null, 'HTML');

        Editmessagetext($from_id, $message_id,
            "❌ رد شد.
🤖 ربات: @{$bi['bot_username']}",
            json_encode(['inline_keyboard' => []]));
        return true;
    }

    return false;
}

// ================================================================
// توابع کمکی خروجی
// ================================================================
function _reseller_info_text($r) {
    $remain = max(0, $r['volume_limit'] - $r['volume_used']);
    return "👤 <b>نماینده <code>{$r['id_user']}</code></b>\n\n"
         . "📌 پنل: <b>{$r['panel_name']}</b>\n"
         . "⚡ وضعیت: <b>" . reseller_status_text($r['status']) . "</b>\n"
         . "💰 کیف پول: <b>" . number_format($r['wallet']) . " تومان</b>\n\n"
         . "━━━━━━━━━━━━━━\n"
         . "📦 سقف حجم: <b>" . format_gb($r['volume_limit']) . "</b>\n"
         . "✅ مصرف شده: <b>" . format_gb($r['volume_used']) . "</b>\n"
         . "🔋 باقیمانده: <b>" . format_gb($remain) . "</b>\n\n"
         . "🔢 سقف کانفیگ: <b>" . ($r['config_limit'] == 0 ? 'نامحدود' : $r['config_limit']) . "</b>\n"
         . "📌 ساخته شده: <b>{$r['config_used']}</b>\n\n"
         . "💵 قیمت/گیگ: <b>" . number_format($r['price_per_gb']) . " تومان</b>\n"
         . "📅 قیمت/ماه: <b>" . number_format($r['price_per_month']) . " تومان</b>\n"
         . "⏰ روزهای تمدید: <b>" . ($r['auto_disable_days'] == 0 ? 'بلافاصله' : $r['auto_disable_days'] . ' روز') . "</b>";
}

function _reseller_report($uid, $r) {
    global $pdo;
    $total  = $pdo->prepare("SELECT COUNT(*) FROM reseller_invoice WHERE id_reseller=?"); $total->execute([$uid]); $total = $total->fetchColumn();
    $active = $pdo->prepare("SELECT COUNT(*) FROM reseller_invoice WHERE id_reseller=? AND status='active'"); $active->execute([$uid]); $active = $active->fetchColumn();
    $income = $pdo->prepare("SELECT SUM(price) FROM reseller_invoice WHERE id_reseller=?"); $income->execute([$uid]); $income = $income->fetchColumn() ?? 0;
    return "📊 <b>گزارش نماینده <code>$uid</code></b>\n\n"
         . "📦 کل کانفیگ: <b>$total</b>\n"
         . "✅ فعال: <b>$active</b>\n"
         . "💰 درآمد کل: <b>" . number_format($income) . " تومان</b>\n"
         . "💳 کیف پول: <b>" . number_format($r['wallet']) . " تومان</b>\n"
         . "📦 حجم باقی: <b>" . format_gb(max(0, $r['volume_limit'] - $r['volume_used'])) . "</b>";
}
