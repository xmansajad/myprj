<?php
require_once 'functions.php';

#-----------------------------#
// دریافت Caddy Auth از فیلد inboundid
// فرمت: caddy_auth|main_squad_uuid|test_squad_uuid
// caddy_auth میتونه باشه:
//   0         → بدون Caddy auth
//   user:pass → Basic Auth
//   هر چیز دیگه → X-Api-Key
function _remna_caddy_auth($name_panel)
{
    $panel     = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $inboundid = isset($panel['inboundid']) ? trim($panel['inboundid']) : '';
    if (!$inboundid || $inboundid === '0') return null;

    $caddy = $inboundid;
    if (strpos($inboundid, '|') !== false) {
        $parts = explode('|', $inboundid);
        $caddy = $parts[0];
    }
    if (!$caddy || $caddy === '0') return null;
    return $caddy;
}

// برای سازگاری با کد قدیم
function _remna_basic_auth($name_panel)
{
    return _remna_caddy_auth($name_panel);
}

#-----------------------------#
// دریافت / کش کردن توکن Remnawave
// password_panel = API Token (JWT از داشبورد Settings > API Tokens)
function token_panel_remna($name_panel)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $pw = trim($panel['password_panel']);

    // اگه password_panel خودش API Token هست (JWT با 2 نقطه)، مستقیم استفاده کن
    if (substr_count($pw, '.') === 2 && strlen($pw) > 100) {
        return ['access_token' => $pw];
    }

    // بررسی توکن کش‌شده (حداکثر ۵۰ دقیقه)
    if ($panel['datelogin'] != null) {
        $date = json_decode($panel['datelogin'], true);
        if (isset($date['time'])) {
            $elapsed = time() - strtotime($date['time']);
            if ($elapsed <= 3000) {
                return $date;
            }
        }
    }

    // لاگین با username/password
    $url  = rtrim($panel['url_panel'], '/') . '/api/auth/login';
    $data = json_encode([
        'username' => $panel['username_panel'],
        'password' => $panel['password_panel']
    ]);

    $loginHeaders = [
        'Content-Type: application/json',
        'Accept: application/json'
    ];

    // Caddy auth
    $basic = _remna_caddy_auth($name_panel);
    if ($basic && strpos($basic, ':') !== false) {
        // Basic Auth → embed در URL
        $parsed = parse_url($url);
        $url = $parsed['scheme'] . '://' . rawurlencode(explode(':', $basic)[0])
             . ':' . rawurlencode(explode(':', $basic, 2)[1])
             . '@' . $parsed['host']
             . (isset($parsed['port']) ? ':' . $parsed['port'] : '')
             . (isset($parsed['path']) ? $parsed['path'] : '');
    } elseif ($basic) {
        // X-Api-Key
        $loginHeaders[] = 'X-Api-Key: ' . $basic;
    }

    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_TIMEOUT_MS     => 6000,
        CURLOPT_HTTPHEADER     => $loginHeaders
    ];
    curl_setopt_array($ch, $opts);

    $response = curl_exec($ch);
    if (curl_error($ch)) {
        curl_close($ch);
        return ['error' => curl_error($ch)];
    }
    curl_close($ch);

    $body       = json_decode($response, true);
    $token_data = isset($body['response']) ? $body['response'] : $body;

    if (isset($token_data['accessToken'])) {
        $time      = date('Y/m/d H:i:s');
        $cacheData = json_encode([
            'time'         => $time,
            'access_token' => $token_data['accessToken']
        ]);
        update("marzban_panel", "datelogin", $cacheData, 'name_panel', $panel['name_panel']);
        return ['time' => $time, 'access_token' => $token_data['accessToken']];
    }

    return $body;
}

#-----------------------------#
// هلپر داخلی cURL
// اگه Caddy Basic Auth (user:pass) داره: credentials رو در URL embed میکنیم
// اگه X-Api-Key داره: به عنوان هدر ارسال میشه
// هر دو روش با Authorization: Bearer سازگارند
function _remna_request($method, $url, $token, $data = null, $caddy_auth = null)
{
    // Caddy Basic Auth → embed در URL تا با Bearer تداخل نداشته باشه
    if ($caddy_auth && $caddy_auth !== '0' && strpos($caddy_auth, ':') !== false) {
        $parsed = parse_url($url);
        $url = $parsed['scheme'] . '://' . rawurlencode(explode(':', $caddy_auth)[0])
             . ':' . rawurlencode(explode(':', $caddy_auth, 2)[1])
             . '@' . $parsed['host']
             . (isset($parsed['port']) ? ':' . $parsed['port'] : '')
             . (isset($parsed['path']) ? $parsed['path'] : '')
             . (isset($parsed['query']) ? '?' . $parsed['query'] : '');
        $caddy_auth = null; // دیگه نیازی به هدر نیست
    }

    $ch      = curl_init($url);
    $headers = [
        'Accept: application/json',
        'Authorization: Bearer ' . $token
    ];

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, 8000);

    // X-Api-Key (نه user:pass)
    if ($caddy_auth && $caddy_auth !== '0') {
        $headers[] = 'X-Api-Key: ' . $caddy_auth;
    }

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data !== null) {
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        } else {
            curl_setopt($ch, CURLOPT_POSTFIELDS, '');
        }
    } elseif ($method === 'PUT') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        if ($data !== null) {
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
    } elseif ($method === 'DELETE') {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $raw     = curl_exec($ch);
    curl_close($ch);
    $decoded = json_decode($raw, true);

    // همه پاسخ‌های Remnawave داخل {"response": {...}} هستند
    if (isset($decoded['response'])) {
        return $decoded['response'];
    }
    return $decoded;
}

#-----------------------------#
// دریافت اطلاعات کاربر با نام کاربری
function getuser_remna($username, $name_panel)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);
    $url   = rtrim($panel['url_panel'], '/') . '/api/users/by-username/' . urlencode($username);
    return _remna_request('GET', $url, $auth['access_token'], null, $basic);
}

#-----------------------------#
// ایجاد کاربر جدید
function adduser_remna($username, $expire, $data_limit, $name_panel, $is_test = false, $product_squad = null)
{
    $panel  = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth   = token_panel_remna($name_panel);
    $basic  = _remna_basic_auth($name_panel);
    $url    = rtrim($panel['url_panel'], '/') . '/api/users';
    $parsed = _remna_parse_inboundid($name_panel);

    $data = [
        'username'          => $username,
        'trafficLimitBytes' => intval($data_limit),
        'status'            => 'ACTIVE'
    ];

    // expireAt در Remnawave API required هست
    if ($expire != 0) {
        $data['expireAt'] = date('c', $expire);
    } else {
        // unlimited = تاریخ خیلی دور
        $data['expireAt'] = date('c', strtotime('+100 years'));
    }

    // اولویت: squad محصول > squad تنظیمات پنل (تست یا خرید)
    if ($product_squad && $product_squad !== 'all') {
        $squad_uuid = $product_squad;
    } else {
        $squad_uuid = $is_test ? $parsed['test_squad'] : $parsed['main_squad'];
    }

    if ($squad_uuid) {
        $data['activeInternalSquads'] = [$squad_uuid]; // API انتظار string[] داره نه object[]
    }

    return _remna_request('POST', $url, $auth['access_token'], $data, $basic);
}

#-----------------------------#
// ریست ترافیک
function ResetUserDataUsage_remna($username, $name_panel)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);

    $user = getuser_remna($username, $name_panel);
    if (!isset($user['uuid'])) return ['error' => 'User not found'];

    $url = rtrim($panel['url_panel'], '/') . '/api/users/' . $user['uuid'] . '/actions/reset-traffic';
    return _remna_request('POST', $url, $auth['access_token'], null, $basic);
}

#-----------------------------#
// حذف کاربر
function removeuser_remna($name_panel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);

    $user = getuser_remna($username, $name_panel);
    if (!isset($user['uuid'])) return ['error' => 'User not found'];

    $url = rtrim($panel['url_panel'], '/') . '/api/users/' . $user['uuid'];
    return _remna_request('DELETE', $url, $auth['access_token'], null, $basic);
}

#-----------------------------#
// revoke سابسکریپشن
function revoke_sub_remna($username, $name_panel)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);

    $user = getuser_remna($username, $name_panel);
    if (!isset($user['uuid'])) return ['error' => 'User not found'];

    $url = rtrim($panel['url_panel'], '/') . '/api/users/' . $user['uuid'] . '/actions/revoke';
    return _remna_request('POST', $url, $auth['access_token'], null, $basic);
}

#-----------------------------#
// ویرایش کاربر
function Modifyuser_remna($name_panel, $username, $config = [])
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);

    $user = getuser_remna($username, $name_panel);
    if (!isset($user['uuid'])) return ['error' => 'User not found'];

    $data = array_merge(['uuid' => $user['uuid']], $config);
    $url  = rtrim($panel['url_panel'], '/') . '/api/users';
    return _remna_request('PUT', $url, $auth['access_token'], $data, $basic);
}

#-----------------------------#
// دریافت لیست اسکوادها
function get_squads_remna($name_panel)
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $auth  = token_panel_remna($name_panel);
    $basic = _remna_basic_auth($name_panel);
    $url   = rtrim($panel['url_panel'], '/') . '/api/internal-squads';
    return _remna_request('GET', $url, $auth['access_token'], null, $basic);
}

#-----------------------------#
// parse کردن inboundid برای remnawave
// فرمت: caddy_auth|main_squad_uuid|test_squad_uuid
function _remna_parse_inboundid($name_panel)
{
    $panel  = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    $raw    = $panel['inboundid'] ?? '0';
    $parts  = explode('|', $raw);
    return [
        'caddy'      => $parts[0] ?? '0',
        'main_squad' => $parts[1] ?? '',
        'test_squad' => $parts[2] ?? '',
    ];
}

// ------------------------------------------------------------------
// گرفتن مصرف واقعی کل پنل رمناوی
//
// رمناوی دو endpoint مرتبط داره:
//   GET /api/system/stats          → آمار کلی (usersCount, nodesCount)
//   GET /api/nodes/usage           → مصرف per-node (bytesIn + bytesOut)
//
// ما از /api/nodes/usage استفاده می‌کنیم چون sum همه node ها
// = مصرف واقعی کل پنل هست و یه call کافیه.
//
// اگه /api/nodes/usage وجود نداشت، fallback به /api/system/stats
// ------------------------------------------------------------------
function get_system_stats_remna(string $name_panel): array
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    if (!$panel) return ['error' => 'panel not found'];
    $auth  = token_panel_remna($name_panel);
    if (!isset($auth['access_token'])) return ['error' => 'auth failed'];
    $basic = _remna_basic_auth($name_panel);
    $url   = rtrim($panel['url_panel'], '/') . '/api/system/stats';
    $result = _remna_request('GET', $url, $auth['access_token'], null, $basic);
    if (!is_array($result)) return ['error' => 'bad response from /api/system/stats'];
    return $result;
}

// ------------------------------------------------------------------
// مصرف bandwidth پنل از /api/system/stats/bandwidth
// response: {
//   "today":         {"bytes": int, "delta": int},
//   "lastSevenDays": {"bytes": int, "delta": int},
//   "lastThirtyDays":{"bytes": int, "delta": int},
//   "calendarMonth": {"bytes": int, "delta": int},
//   "currentYear":   {"bytes": int, "delta": int}
// }
// ما از calendarMonth استفاده میکنیم — مصرف ماه جاری
// ------------------------------------------------------------------
function get_bandwidth_stats_remna(string $name_panel): array
{
    $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
    if (!$panel) return ['error' => 'panel not found'];
    $auth  = token_panel_remna($name_panel);
    if (!isset($auth['access_token'])) return ['error' => 'auth failed'];
    $basic = _remna_basic_auth($name_panel);
    $url   = rtrim($panel['url_panel'], '/') . '/api/system/stats/bandwidth';
    $result = _remna_request('GET', $url, $auth['access_token'], null, $basic);
    if (!is_array($result)) return ['error' => 'bad response from /api/system/stats/bandwidth'];
    return $result;
}

// ------------------------------------------------------------------
// get_panel_bandwidth_remna
// مصرف ماه جاری پنل را از calendarMonth میگیره
// این همون عددیه که توی داشبورد رمناوی "Calendar month" نشون داده میشه
// برمیگردونه: ['total_bytes' => int, 'total_gb' => float, 'source' => string, 'error' => string|null]
// ------------------------------------------------------------------
function get_panel_bandwidth_remna(string $name_panel): array
{
    $bw = get_bandwidth_stats_remna($name_panel);

    if (isset($bw['error'])) {
        return ['total_bytes' => 0, 'total_gb' => 0.0, 'source' => '', 'error' => $bw['error']];
    }

    // calendarMonth = مصرف ماه جاری میلادی
    // lastThirtyDays = ۳۰ روز اخیر (آپشن دوم)
    $bytes = 0;
    $source = '';

    if (isset($bw['calendarMonth']['bytes'])) {
        $bytes  = (int)$bw['calendarMonth']['bytes'];
        $source = 'calendarMonth';
    } elseif (isset($bw['lastThirtyDays']['bytes'])) {
        $bytes  = (int)$bw['lastThirtyDays']['bytes'];
        $source = 'lastThirtyDays';
    } elseif (isset($bw['currentYear']['bytes'])) {
        $bytes  = (int)$bw['currentYear']['bytes'];
        $source = 'currentYear';
    } else {
        // fallback: اولین فیلد bytes که پیدا بشه
        foreach ($bw as $key => $val) {
            if (is_array($val) && isset($val['bytes'])) {
                $bytes  = (int)$val['bytes'];
                $source = $key;
                break;
            }
        }
    }

    return [
        'total_bytes' => $bytes,
        'total_gb'    => round($bytes / 1073741824, 3),
        'source'      => $source,
        'error'       => $bytes === 0 && empty($source) ? 'no bytes field found in bandwidth response' : null,
        '_raw'        => $bw,  // برای debug
    ];
}

// ------------------------------------------------------------------
// debug: نمایش raw response از هر دو endpoint (برای ادمین)
// ------------------------------------------------------------------
function debug_remna_stats(string $name_panel): string
{
    $bw    = get_bandwidth_stats_remna($name_panel);
    $stats = get_system_stats_remna($name_panel);
    return "=== /api/system/stats/bandwidth ===
"
         . json_encode($bw,    JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
         . "

=== /api/system/stats ===
"
         . json_encode($stats, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
