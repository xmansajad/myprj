<?php
// reseller_bot_sale.php
// فاز ۲ — ربات مادر: فروش پنل نمایندگی (زیر ربات)
// شامل: نمایش پلن‌ها، پرداخت کارت‌به‌کارت / درگاه، تحویل خودکار پنل

// ------------------------------------------------------------------
// تابع اصلی: handle_bot_sale_user
// فراخوانی از index.php در بخش مربوط به کاربران
// ------------------------------------------------------------------
function handle_bot_sale_user($from_id, $text, $datain, $user, $keyboard)
{
    global $pdo, $adminnumber, $domainhosts;

    $setting = select('setting', '*');
    if (($setting['bot_sale_status'] ?? 'off') === 'off') {
        return false; // فروش پنل غیرفعال است
    }

    // ---- منوی اصلی خرید پنل ----
    if ($text === '🤖 خرید پنل نمایندگی') {
        $plans = $pdo->query(
            "SELECT * FROM reseller_bot_plan WHERE status='active' ORDER BY price ASC"
        )->fetchAll(PDO::FETCH_ASSOC);

        if (empty($plans)) {
            sendmessage($from_id,
                "⚠️ در حال حاضر پلن فعالی برای فروش وجود ندارد.\nلطفاً بعداً مراجعه کنید.",
                $keyboard, 'HTML');
            step('home', $from_id);
            return true;
        }

        $msg  = "🤖 <b>خرید پنل نمایندگی</b>\n\n";
        $msg .= "با خرید پنل نمایندگی، یک ربات تلگرامی اختصاصی دریافت می‌کنید ";
        $msg .= "و می‌توانید مستقلاً اشتراک VPN بفروشید.\n\n";
        $msg .= "📋 <b>پلن‌های موجود:</b>\n\n";

        $rows = [];
        foreach ($plans as $p) {
            $vol = $p['volume_gb'] >= 1024
                ? round($p['volume_gb'] / 1024, 1) . ' TB'
                : $p['volume_gb'] . ' GB';
            $msg .= "🔹 <b>{$p['name']}</b>\n";
            $msg .= "   📦 حجم: {$vol} | 👥 سقف کانفیگ: {$p['config_limit']}\n";
            $msg .= "   ⏳ مدت: {$p['duration_days']} روز\n";
            $msg .= "   💰 قیمت: <b>" . number_format($p['price']) . " تومان</b>\n\n";
            $rows[] = [['text' => "🛒 خرید: {$p['name']} — " . number_format($p['price']) . " تومان",
                         'callback_data' => "bot_sale_plan_{$p['id']}"]];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'backuser']];
        $kb = json_encode(['inline_keyboard' => $rows]);

        sendmessage($from_id, $msg, $kb, 'HTML');
        step('home', $from_id);
        return true;
    }

    // ---- وضعیت پنل‌های خریداری شده ----
    if ($text === '📋 پنل‌های من') {
        $bots = $pdo->prepare(
            "SELECT rbi.*, rb.bot_username, rb.status as bot_status
             FROM reseller_bot_invoice rbi
             LEFT JOIN reseller_bot rb ON rb.bot_token = rbi.bot_token
             WHERE rbi.buyer_id = ? AND rbi.payment_status = 'paid'
             ORDER BY rbi.created_at DESC LIMIT 10"
        );
        $bots->execute([$from_id]);
        $bots = $bots->fetchAll(PDO::FETCH_ASSOC);

        if (empty($bots)) {
            sendmessage($from_id, "📋 شما هنوز پنل نمایندگی خریداری نکرده‌اید.", $keyboard, 'HTML');
            return true;
        }

        $msg = "📋 <b>پنل‌های نمایندگی شما</b>\n\n";
        foreach ($bots as $b) {
            $status_txt = match($b['bot_status'] ?? 'pending') {
                'active'  => '✅ فعال',
                'pending' => '⏳ در انتظار تحویل',
                'blocked' => '🚫 مسدود',
                default   => '❓ نامشخص'
            };
            $username = $b['bot_username'] ? "@{$b['bot_username']}" : '—';
            $date = date('Y/m/d', $b['created_at']);
            $msg .= "🤖 <b>{$b['plan_name']}</b>\n";
            $msg .= "   🔗 ربات: {$username} | وضعیت: {$status_txt}\n";
            $msg .= "   📅 خرید: {$date}\n\n";
        }
        sendmessage($from_id, $msg, $keyboard, 'HTML');
        return true;
    }

    // ---- مرحله دریافت توکن ربات از خریدار (بعد از تایید پرداخت) ----
    if ($user['step'] === 'bot_sale_enter_token') {
        $pv = json_decode($user['Processing_value'], true);
        $order_id = $pv['order_id'] ?? null;
        if (!$order_id) { step('home', $from_id); return true; }

        $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=? AND buyer_id=?");
        $inv->execute([$order_id, $from_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);

        if (!$inv || $inv['payment_status'] !== 'paid' || $inv['delivered']) {
            sendmessage($from_id, "❌ سفارش معتبر نیست یا قبلاً پردازش شده.", $keyboard, 'HTML');
            step('home', $from_id);
            return true;
        }

        $token = trim($text);

        // اعتبارسنجی فرمت ساده توکن قبل از زدن به API تلگرام
        if (!preg_match('/^\d{6,12}:[A-Za-z0-9_-]{30,45}$/', $token)) {
            sendmessage($from_id,
                "❌ فرمت توکن نامعتبر است.\n\n" .
                "توکن باید شبیه این باشد:\n<code>123456789:AAExampleTokenHere1234567890</code>\n\n" .
                "اگر هنوز ربات نساخته‌اید:\n" .
                "1️⃣ به @BotFather پیام دهید\n" .
                "2️⃣ دستور /newbot را بفرستید\n" .
                "3️⃣ نام و یوزرنیم (باید به bot ختم شود) انتخاب کنید\n" .
                "4️⃣ توکن دریافتی را اینجا بفرستید",
                null, 'HTML');
            return true;
        }

        // چک تکراری نبودن توکن (قبلاً برای ربات دیگری استفاده نشده باشد)
        $dup = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=?");
        $dup->execute([$token]);
        if ($dup->fetch()) {
            sendmessage($from_id,
                "❌ این ربات قبلاً برای یک پنل نمایندگی دیگر استفاده شده است.\n\n" .
                "لطفاً یک ربات جدید با @BotFather بسازید (دستور /newbot) و توکن آن را ارسال کنید.",
                null, 'HTML');
            return true;
        }

        // اعتبارسنجی توکن از طریق تلگرام (getMe)
        require_once 'child_botapi.php';
        $bot_info = child_get_bot_info($token);
        if (!$bot_info) {
            sendmessage($from_id,
                "❌ این توکن معتبر نیست یا ربات در دسترس نیست.\n\n" .
                "لطفاً توکن را از پیام BotFather کپی و دوباره ارسال کنید.\n\n" .
                "اگر هنوز ربات نساخته‌اید:\n" .
                "1️⃣ به @BotFather پیام دهید\n" .
                "2️⃣ دستور /newbot را بفرستید\n" .
                "3️⃣ نام و یوزرنیم (باید به bot ختم شود) انتخاب کنید\n" .
                "4️⃣ توکن دریافتی را اینجا بفرستید",
                null, 'HTML');
            return true;
        }

        // ثبت اطلاعات ربات روی فاکتور و تحویل نهایی پنل
        $pdo->prepare("UPDATE reseller_bot_invoice SET bot_token=?, bot_username=? WHERE order_id=?")
            ->execute([$token, $bot_info['username'], $order_id]);

        $result = bot_sale_deliver_panel($order_id, null);

        if (!$result['ok']) {
            // توکن ثبت شد ولی تحویل ناموفق بود (مثلاً استخر پنل خالیه).
            // کاربر رو منتظر نگه می‌داریم تا ادمین دستی دوباره تحویل رو بزنه.
            sendmessage($from_id,
                "✅ توکن ربات شما با موفقیت ثبت شد.\n" .
                "⏳ تحویل نهایی پنل در حال انجام است و به محض آماده شدن، ربات شما فعال می‌شود.",
                $keyboard, 'HTML');
            global $adminnumber;
            sendmessage($adminnumber,
                "🔁 برای تکمیل تحویل این سفارش (بعد از رفع مشکل) دوباره روی دکمه زیر بزنید:",
                json_encode(['inline_keyboard' => [[
                    ['text' => '🔄 تلاش مجدد تحویل پنل', 'callback_data' => "bot_sale_retry_{$order_id}"]
                ]]]), 'HTML');
            $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
            step('home', $from_id);
            return true;
        }

        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        step('home', $from_id);
        return true;
    }

    // ---- مرحله وارد کردن شماره پیگیری (کارت به کارت) ----
    if ($user['step'] === 'bot_sale_card_tracking') {
        $pv = json_decode($user['Processing_value'], true);
        $order_id = $pv['order_id'] ?? null;
        if (!$order_id) { step('home', $from_id); return true; }

        $tracking = trim($text);
        if (strlen($tracking) < 4) {
            sendmessage($from_id, "❌ شماره پیگیری معتبر نیست. دوباره وارد کنید:", null, 'HTML');
            return true;
        }

        $inv = _bot_sale_get_approved_invoice($order_id, $from_id);
        if (!$inv) {
            sendmessage($from_id, "❌ سفارش معتبر نیست یا قبلاً پردازش شده.", $keyboard, 'HTML');
            step('home', $from_id);
            return true;
        }

        // به‌روزرسانی همون سفارش approved — نه ساخت فاکتور جدید (تایید دوم: پرداخت کارت‌به‌کارت)
        $pdo->prepare(
            "UPDATE reseller_bot_invoice SET payment_method='card', payment_status='waiting_admin' WHERE order_id=?"
        )->execute([$order_id]);

        // اطلاع به ادمین‌ها
        global $admin_ids, $adminnumber;
        $msg_admin  = "💳 <b>تایید واریز کارت‌به‌کارت — پنل نمایندگی</b>\n\n";
        $msg_admin .= "👤 خریدار: <code>{$from_id}</code>\n";
        $msg_admin .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg_admin .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n";
        $msg_admin .= "🤖 ربات: @{$inv['bot_username']}\n";
        $msg_admin .= "🔖 شماره پیگیری: <code>{$tracking}</code>\n";
        $msg_admin .= "📌 شناسه سفارش: <code>{$order_id}</code>";
        $kb_admin = json_encode(['inline_keyboard' => [
            [
                ['text' => '✅ تایید و تحویل پنل', 'callback_data' => "bot_sale_approve_{$order_id}"],
                ['text' => '❌ رد کردن',            'callback_data' => "bot_sale_reject_{$order_id}"],
            ]
        ]]);
        $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
        foreach ($admin_targets as $admin) {
            sendmessage($admin, $msg_admin, $kb_admin, 'HTML');
        }

        // اطلاع به کاربر
        $msg_user  = "✅ <b>شماره پیگیری ثبت شد</b>\n\n";
        $msg_user .= "📌 شناسه سفارش: <code>{$order_id}</code>\n";
        $msg_user .= "⏳ بعد از تایید واریز توسط ادمین، پنل شما فعال می‌شود.\n";
        $msg_user .= "معمولاً کمتر از ۱ ساعت طول می‌کشد.";
        sendmessage($from_id, $msg_user, $keyboard, 'HTML');

        step('home', $from_id);
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        return true;
    }

    return false;
}

// ------------------------------------------------------------------
// تابع اصلی: handle_bot_sale_callbacks
// فراخوانی از index.php در بخش callback_query
// ------------------------------------------------------------------
function handle_bot_sale_callbacks($from_id, $datain, $message_id, $callback_query_id)
{
    global $pdo, $adminnumber, $domainhosts;

    // ---- انتخاب پلن → نمایش جزئیات و درخواست تایید (توکن ربات بعداً از خود خریدار گرفته می‌شود) ----
    if (preg_match('/^bot_sale_plan_(\d+)$/', $datain, $m)) {
        $plan = _bot_sale_get_plan((int)$m[1]);
        if (!$plan) {
            AnswerCallbackQuery($callback_query_id, '❌ پلن یافت نشد');
            return true;
        }

        $vol = $plan['volume_gb'] >= 1024
            ? round($plan['volume_gb'] / 1024, 1) . ' TB'
            : $plan['volume_gb'] . ' GB';

        $msg  = "🛒 <b>خرید پنل: {$plan['name']}</b>\n\n";
        $msg .= "📦 حجم: <b>{$vol}</b>\n";
        $msg .= "👥 سقف کانفیگ: <b>{$plan['config_limit']}</b>\n";
        $msg .= "⏳ مدت: <b>{$plan['duration_days']} روز</b>\n";
        $msg .= "💰 قیمت: <b>" . number_format($plan['price']) . " تومان</b>\n\n";
        $msg .= "━━━━━━━━━━━━━━\n";
        $msg .= "ℹ️ بعد از تایید سفارش توسط مدیر و پرداخت، از شما خواسته می‌شود ";
        $msg .= "توکن رباتی که از @BotFather ساخته‌اید را ارسال کنید تا پنل نمایندگی روی همان ربات شما فعال شود.";

        // ذخیره plan_id انتخاب‌شده در Processing_value
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([
            json_encode(['plan_id' => $plan['id']]), $from_id
        ]);

        $kb = json_encode(['inline_keyboard' => [
            [['text' => '✅ تایید و ثبت سفارش', 'callback_data' => 'bot_sale_confirm_token']],
            [['text' => '🔙 بازگشت به پلن‌ها', 'callback_data' => 'bot_sale_plans']],
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('bot_sale_confirm_token', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- لیست پلن‌ها (بازگشت) ----
    if ($datain === 'bot_sale_plans') {
        $plans = $pdo->query(
            "SELECT * FROM reseller_bot_plan WHERE status='active' ORDER BY price ASC"
        )->fetchAll(PDO::FETCH_ASSOC);

        $msg  = "🤖 <b>انتخاب پلن نمایندگی</b>\n\n";
        $rows = [];

        foreach ($plans as $p) {
            $vol = $p['volume_gb'] >= 1024
                ? round($p['volume_gb'] / 1024, 1) . ' TB'
                : $p['volume_gb'] . ' GB';
            $rows[] = [['text' => "🛒 {$p['name']} — {$vol} — " . number_format($p['price']) . " تومان",
                         'callback_data' => "bot_sale_plan_{$p['id']}"]];
        }
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'backuser']];
        Editmessagetext($from_id, $message_id, $msg, json_encode(['inline_keyboard' => $rows]));
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- تایید پلن → ساخت سفارش در انتظار تایید مدیر (توکن ربات بعداً از خریدار گرفته می‌شود) ----
    if ($datain === 'bot_sale_confirm_token') {
        $user_row = $pdo->prepare("SELECT * FROM user WHERE id=?");
        $user_row->execute([$from_id]);
        $user_row = $user_row->fetch(PDO::FETCH_ASSOC);
        $pv = json_decode($user_row['Processing_value'] ?? '{}', true);

        $plan = _bot_sale_get_plan($pv['plan_id'] ?? 0);
        if (!$plan) {
            AnswerCallbackQuery($callback_query_id, '❌ خطا. لطفاً دوباره شروع کنید.');
            step('home', $from_id);
            return true;
        }

        $order_id = _bot_sale_create_pending_order($from_id, $plan, []);
        if (!$order_id) {
            AnswerCallbackQuery($callback_query_id, '❌ خطا در ثبت سفارش');
            return true;
        }

        $vol = $plan['volume_gb'] >= 1024
            ? round($plan['volume_gb'] / 1024, 1) . ' TB'
            : $plan['volume_gb'] . ' GB';

        $detail  = "📋 پلن: <b>{$plan['name']}</b>\n";
        $detail .= "📦 حجم: <b>{$vol}</b> | 👥 سقف کانفیگ: <b>{$plan['config_limit']}</b>\n";
        $detail .= "⏳ مدت: <b>{$plan['duration_days']} روز</b>\n";
        $detail .= "💰 مبلغ: <b>" . number_format($plan['price']) . " تومان</b>\n\n";
        $detail .= "👤 آیدی عددی خریدار: <code>{$from_id}</code>\n";
        $detail .= "📌 شناسه سفارش: <code>{$order_id}</code>";

        // پیام به کاربر (برای اطمینان خودش)
        $msg_user  = "✅ <b>سفارش شما ثبت شد و در انتظار تایید مدیر است</b>\n\n";
        $msg_user .= $detail . "\n\n";
        $msg_user .= "⏳ بعد از تایید مدیر، روش‌های پرداخت برای شما نمایش داده می‌شود.";
        Editmessagetext($from_id, $message_id, $msg_user, null);

        // پیام به همه ادمین‌ها با دکمه تایید/رد
        global $admin_ids, $adminnumber;
        $msg_admin = "🆕 <b>درخواست جدید: خرید پنل نمایندگی (در انتظار تایید)</b>\n\n" . $detail;
        $kb_admin = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید سفارش', 'callback_data' => "bot_sale_order_approve_{$order_id}"],
            ['text' => '❌ رد سفارش',    'callback_data' => "bot_sale_order_reject_{$order_id}"],
        ]]]);
        $admin_targets = !empty($admin_ids) && is_array($admin_ids) ? $admin_ids : [$adminnumber];
        foreach ($admin_targets as $admin) {
            sendmessage($admin, $msg_admin, $kb_admin, 'HTML');
        }

        step('home', $from_id);
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        AnswerCallbackQuery($callback_query_id, '✅ سفارش ثبت شد');
        return true;
    }

    // ---- ادمین: تایید سفارش → باز شدن روش‌های پرداخت برای کاربر ----
    if (preg_match('/^bot_sale_order_approve_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
        $inv->execute([$order_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true); return true; }
        if ($inv['approval_status'] !== 'awaiting_approval') {
            AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true);
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot_invoice SET approval_status='approved', reviewed_at=?, reviewed_by=? WHERE order_id=?")
            ->execute([time(), $from_id, $order_id]);

        _bot_sale_send_payment_options($inv['buyer_id'], $order_id);

        Editmessagetext($from_id, $message_id,
            "✅ سفارش تایید شد و روش‌های پرداخت برای کاربر ارسال شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        AnswerCallbackQuery($callback_query_id, '✅ تایید شد', true);
        return true;
    }

    // ---- ادمین: رد سفارش (قبل از پرداخت) ----
    if (preg_match('/^bot_sale_order_reject_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
        $inv->execute([$order_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true); return true; }
        if ($inv['approval_status'] !== 'awaiting_approval') {
            AnswerCallbackQuery($callback_query_id, '⚠️ قبلاً پردازش شده', true);
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot_invoice SET approval_status='rejected', payment_status='rejected', reviewed_at=?, reviewed_by=? WHERE order_id=?")
            ->execute([time(), $from_id, $order_id]);

        // حذف رکورد reseller_bot چون هنوز پنل تخصیص نیافته (اگه توکنی ثبت شده باشه)
        if (!$inv['delivered'] && !empty($inv['bot_token'])) {
            $pdo->prepare("DELETE FROM reseller_bot WHERE bot_token=? AND status='pending'")->execute([$inv['bot_token']]);
        }

        sendmessage($inv['buyer_id'],
            "❌ <b>سفارش شما توسط مدیر رد شد</b>\n\n📌 شناسه: <code>{$order_id}</code>\nبرای اطلاعات بیشتر با پشتیبانی تماس بگیرید.",
            null, 'HTML');

        Editmessagetext($from_id, $message_id,
            "❌ سفارش رد شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        AnswerCallbackQuery($callback_query_id, '❌ رد شد', true);
        return true;
    }

    // ---- نمایش (مجدد) روش‌های پرداخت برای سفارش approved ----
    if (preg_match('/^bot_sale_payment_options_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=? AND buyer_id=?");
        $inv->execute([$order_id, $from_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);
        if (!$inv || $inv['approval_status'] !== 'approved') {
            AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست');
            return true;
        }
        $kb = _bot_sale_payment_options_kb($order_id);
        if (!$kb) { AnswerCallbackQuery($callback_query_id, '❌ هیچ روش پرداختی تنظیم نشده'); return true; }
        Editmessagetext($from_id, $message_id, _bot_sale_payment_options_text($inv), $kb);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت کارت به کارت ----
    if (preg_match('/^bot_sale_pay_card_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $inv = _bot_sale_get_approved_invoice($order_id, $from_id);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $setting = select('setting', '*');
        $card    = $setting['bot_sale_card_num']  ?? '';
        $cname   = $setting['bot_sale_card_name'] ?? '';

        $msg  = "💳 <b>پرداخت کارت به کارت</b>\n\n";
        $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n\n";
        $msg .= "🏦 شماره کارت:\n<code>{$card}</code>\n";
        if ($cname) $msg .= "👤 به نام: <b>{$cname}</b>\n";
        $msg .= "\nبعد از واریز، شماره پیگیری را ارسال کنید:";

        $kb = json_encode(['inline_keyboard' => [
            [['text' => '📋 کپی شماره کارت', 'copy_text' => ['text' => $card]]],
            [['text' => '🔙 بازگشت', 'callback_data' => "bot_sale_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        // ذخیره order_id جاری برای مرحله بعد (وارد کردن شماره پیگیری)
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")
            ->execute([json_encode(['order_id' => $order_id]), $from_id]);
        step('bot_sale_card_tracking', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین زرین‌پال ----
    if (preg_match('/^bot_sale_pay_zarinpal_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $inv = _bot_sale_get_approved_invoice($order_id, $from_id);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $pdo->prepare("UPDATE reseller_bot_invoice SET payment_method='zarinpal' WHERE order_id=?")->execute([$order_id]);

        $pay_url = "https://{$domainhosts}/payment/zarinpal/zarinpal_bot.php?price={$inv['price']}&order_id={$order_id}";
        $msg  = "🔐 <b>پرداخت آنلاین زرین‌پال</b>\n\n";
        $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n\n";
        $msg .= "روی دکمه زیر کلیک کنید تا به درگاه منتقل شوید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت از طریق زرین‌پال', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "bot_sale_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین NowPayments ----
    if (preg_match('/^bot_sale_pay_nowpayments_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $inv = _bot_sale_get_approved_invoice($order_id, $from_id);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $price_rate = tronratee();
        $usd_amount = $price_rate['result']['USD'] > 0 ? round($inv['price'] / $price_rate['result']['USD'], 2) : 0;
        if ($usd_amount <= 0) {
            AnswerCallbackQuery($callback_query_id, '❌ خطا در تبدیل قیمت به دلار');
            return true;
        }

        $pdo->prepare("UPDATE reseller_bot_invoice SET payment_method='nowpayments' WHERE order_id=?")->execute([$order_id]);

        $pay = nowPayments('invoice', $usd_amount, $order_id, "خرید پنل نمایندگی — {$inv['plan_name']}");
        $pay_url = $pay['invoice_url'] ?? $pay['url'] ?? '';
        if (empty($pay_url)) {
            AnswerCallbackQuery($callback_query_id, '❌ خطا در ساخت لینک پرداخت');
            return true;
        }

        $msg  = "🔐 <b>پرداخت آنلاین NowPayments</b>\n\n";
        $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n";
        $msg .= "💵 معادل: <b>{$usd_amount} USD</b>\n\n";
        $msg .= "روی دکمه زیر کلیک کنید تا به درگاه منتقل شوید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت از طریق NowPayments', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "bot_sale_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- پرداخت آنلاین آقای پرداخت ----
    if (preg_match('/^bot_sale_pay_aqaye_(.+)$/', $datain, $m)) {
        $order_id = $m[1];
        $inv = _bot_sale_get_approved_invoice($order_id, $from_id);
        if (!$inv) { AnswerCallbackQuery($callback_query_id, '❌ سفارش معتبر نیست'); return true; }

        $pdo->prepare("UPDATE reseller_bot_invoice SET payment_method='aqayepardakht' WHERE order_id=?")->execute([$order_id]);

        $pay_url = "https://{$domainhosts}/payment/aqayepardakht/aqayepardakht_bot.php?price={$inv['price']}&order_id={$order_id}";
        $msg  = "💳 <b>پرداخت آنلاین آقای پرداخت</b>\n\n";
        $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
        $msg .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n\n";
        $msg .= "روی دکمه زیر کلیک کنید:";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => '💳 پرداخت آنلاین', 'url' => $pay_url]],
            [['text' => '🔙 بازگشت', 'callback_data' => "bot_sale_payment_options_{$order_id}"]]
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        step('home', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // ---- ادمین: تایید پرداخت ----
    if (preg_match('/^bot_sale_approve_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $result   = bot_sale_deliver_panel($order_id, $from_id);
        AnswerCallbackQuery($callback_query_id, $result['msg'], true);
        if ($result['ok']) {
            $txt = !empty($result['awaiting_token'])
                ? "✅ پرداخت تایید شد — از خریدار خواسته شد توکن ربات خود را ارسال کند.\n📌 سفارش: <code>{$order_id}</code>"
                : "✅ پنل تحویل داده شد.\n📌 سفارش: <code>{$order_id}</code>";
            Editmessagetext($from_id, $message_id, $txt, null);
        }
        return true;
    }

    // ---- ادمین: تلاش مجدد تحویل پنل (مثلاً بعد از پر کردن استخر پنل) ----
    if (preg_match('/^bot_sale_retry_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $result   = bot_sale_deliver_panel($order_id, $from_id);
        AnswerCallbackQuery($callback_query_id, $result['msg'], true);
        if ($result['ok']) {
            Editmessagetext($from_id, $message_id,
                "✅ پنل تحویل داده شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        }
        return true;
    }

    // ---- ادمین: رد کردن سفارش ----
    if (preg_match('/^bot_sale_reject_(.+)$/', $datain, $m)) {
        if (guard_admin_callback($from_id, $callback_query_id)) return true;
        $order_id = $m[1];
        $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
        $inv->execute([$order_id]);
        $inv = $inv->fetch(PDO::FETCH_ASSOC);
        if (!$inv) {
            AnswerCallbackQuery($callback_query_id, '❌ سفارش یافت نشد', true);
            return true;
        }
        $pdo->prepare("UPDATE reseller_bot_invoice SET payment_status='rejected' WHERE order_id=?")
            ->execute([$order_id]);
        // حذف رکورد reseller_bot اگر هنوز تحویل نشده
        if (!$inv['delivered']) {
            $pdo->prepare("DELETE FROM reseller_bot WHERE bot_token=? AND status='pending'")
                ->execute([$inv['bot_token']]);
        }
        // آزاد کردن توکن در pool
        $pdo->prepare("UPDATE reseller_bot_token_pool SET status='available', assigned_to=NULL WHERE assigned_to=?")
            ->execute([$order_id]);
        // اطلاع به خریدار
        sendmessage($inv['buyer_id'],
            "❌ <b>سفارش شما رد شد</b>\n\n📌 شناسه: <code>{$order_id}</code>\nبرای اطلاعات بیشتر با پشتیبانی تماس بگیرید.",
            null, 'HTML');
        AnswerCallbackQuery($callback_query_id, '❌ سفارش رد شد', true);
        Editmessagetext($from_id, $message_id,
            "❌ سفارش رد شد.\n📌 سفارش: <code>{$order_id}</code>", null);
        return true;
    }

    return false;
}

// ------------------------------------------------------------------
// تحویل پنل — تابع مشترک (صدا زده می‌شه از ادمین callback و back.php درگاه)
// ------------------------------------------------------------------
function bot_sale_deliver_panel($order_id, $admin_id = null)
{
    global $pdo, $domainhosts;
    require_once __DIR__ . '/child_botapi.php';

    // ---------------------------------------------------
    // 1. Load invoice — guard against double-delivery
    // ---------------------------------------------------
    $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
    $inv->execute([$order_id]);
    $inv = $inv->fetch(PDO::FETCH_ASSOC);

    if (!$inv)           return ['ok' => false, 'msg' => '❌ سفارش یافت نشد'];
    if ($inv['delivered']) return ['ok' => false, 'msg' => '⚠️ این پنل قبلاً تحویل داده شده'];

    // محافظ سخت: تا سفارش توسط مدیر approved نشده، تحویل پنل ممنوع
    // (حتی اگه کسی مستقیم لینک پرداخت/درگاه رو صدا بزنه)
    if (($inv['approval_status'] ?? '') !== 'approved') {
        return ['ok' => false, 'msg' => '❌ این سفارش هنوز توسط مدیر تایید نشده — تحویل پنل مسدود است'];
    }

    $bot_token = $inv['bot_token'];
    $buyer_id  = $inv['buyer_id'];

    // ---------------------------------------------------
    // 1b. پرداخت تایید شد ولی هنوز توکن رباتی از خریدار
    //     دریافت نشده — پرداخت را paid می‌کنیم و از خریدار
    //     می‌خواهیم خودش توکن BotFather را ارسال کند.
    //     (تحویل واقعی پنل در مرحله bot_sale_enter_token انجام می‌شود)
    // ---------------------------------------------------
    if (empty($bot_token)) {
        $pdo->prepare(
            "UPDATE reseller_bot_invoice SET payment_status='paid', paid_at=? WHERE order_id=?"
        )->execute([time(), $order_id]);

        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")
            ->execute([json_encode(['order_id' => $order_id]), $buyer_id]);
        step('bot_sale_enter_token', $buyer_id);

        sendmessage($buyer_id,
            "✅ <b>پرداخت شما تایید شد!</b>\n\n" .
            "برای راه‌اندازی ربات نمایندگی، یک ربات تلگرامی جدید از @BotFather بسازید " .
            "و توکن آن را اینجا ارسال کنید.\n\n" .
            "🔹 اگر هنوز رباتی نساخته‌اید:\n" .
            "1️⃣ به @BotFather پیام دهید\n" .
            "2️⃣ دستور /newbot را بفرستید\n" .
            "3️⃣ یک نام و یوزرنیم (باید به bot ختم شود) انتخاب کنید\n" .
            "4️⃣ توکنی که BotFather می‌دهد را همینجا برای من ارسال کنید\n\n" .
            "🔑 توکن ربات را ارسال کنید:",
            null, 'HTML');

        return ['ok' => true, 'msg' => '✅ پرداخت تایید شد — منتظر دریافت توکن ربات از خریدار', 'awaiting_token' => true];
    }

    // ---------------------------------------------------
    // 2. Ensure reseller_bot row exists (online payment
    //    may arrive before the row is created)
    // ---------------------------------------------------
    $rb = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
    $rb->execute([$bot_token]);
    $rb = $rb->fetch(PDO::FETCH_ASSOC);

    if (!$rb) {
        $plan = _bot_sale_get_plan($inv['plan_id']);
        if (!$plan) return ['ok' => false, 'msg' => '❌ پلن یافت نشد'];
        $pv = [
            'bot_token'    => $bot_token,
            'bot_username' => $inv['bot_username'],
            'bot_name'     => $inv['bot_username'],
        ];
        _bot_sale_register_reseller_bot($pv, $plan, $buyer_id);
        $rb = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $rb->execute([$bot_token]);
        $rb = $rb->fetch(PDO::FETCH_ASSOC);
        if (!$rb) return ['ok' => false, 'msg' => '❌ خطا در ثبت reseller_bot'];
    }

    // ---------------------------------------------------
    // 3. Panel assignment — exclusively from reseller_panel_pool
    //    اگر پلن خریداری‌شده یک پنل مشخص (مثلاً «رمنا-۱») داشته باشد،
    //    باید دقیقاً از همان نوع پنل در استخر تخصیص داده شود؛
    //    فقط اگر پلن «بدون پنل خاص» باشد (panel_name خالی)، هر پنل
    //    available از استخر قابل قبول است.
    //    (ادمین از قبل پنل‌های وی‌پی‌ان را در استخر ثبت کرده است؛
    //     در صورت نبودن پنل مناسب، تحویل متوقف و به ادمین اطلاع داده می‌شود)
    // ---------------------------------------------------
    $plan_for_panel = _bot_sale_get_plan($inv['plan_id']);
    $required_panel = trim($plan_for_panel['panel_name'] ?? '');

    if ($required_panel !== '') {
        $pool_stmt = $pdo->prepare(
            "SELECT * FROM reseller_panel_pool WHERE status='available' AND name_panel=? ORDER BY id ASC LIMIT 1 FOR UPDATE"
        );
        $pool_stmt->execute([$required_panel]);
    } else {
        $pool_stmt = $pdo->query(
            "SELECT * FROM reseller_panel_pool WHERE status='available' ORDER BY id ASC LIMIT 1 FOR UPDATE"
        );
    }
    $pool_panel = $pool_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pool_panel) {
        global $adminnumber;
        $panel_hint = $required_panel !== '' ? "🌐 پنل موردنیاز پلن: <b>{$required_panel}</b>\n" : '';
        sendmessage($adminnumber,
            "⚠️ <b>پنل مناسب در استخر موجود نیست!</b>\n\n" .
            "خریدار <code>{$buyer_id}</code> پرداخت و توکن ربات را ارسال کرده، اما " .
            ($required_panel !== ''
                ? "هیچ پنل «<b>{$required_panel}</b>» با وضعیت available در استخر پنل یافت نشد."
                : "هیچ پنلی در استخر پنل (<code>reseller_panel_pool</code>) موجود نیست.") . "\n\n" .
            $panel_hint .
            "📌 سفارش: <code>{$order_id}</code>\n" .
            "🔑 توکن: <code>{$bot_token}</code>\n\n" .
            "لطفاً پنل مناسب را به استخر اضافه کنید و سپس دوباره تایید را بزنید.",
            null, 'HTML');
        return ['ok' => false, 'msg' => '❌ پنل مناسب در استخر موجود نیست — به ادمین اطلاع داده شد'];
    }

    $panel_to_assign = $pool_panel['name_panel'];
    $pool_id         = $pool_panel['id'];
    // Lock this pool entry to this bot_token
    $pdo->prepare(
        "UPDATE reseller_panel_pool SET status='assigned', assigned_to=? WHERE id=?"
    )->execute([$bot_token, $pool_id]);

    // ---------------------------------------------------
    // 4. Activate reseller_bot with full provisioning data
    // ---------------------------------------------------
    $duration_days = max(0, intval($inv['duration_days'] ?? 0));
    $expire_at     = $duration_days > 0 ? (time() + $duration_days * 86400) : 0;

    $pdo->prepare(
        "UPDATE reseller_bot SET
            status        = 'active',
            volume_limit  = ?,
            config_limit  = ?,
            panel_name    = ?,
            panel_pool_id = ?,
            owner_id      = ?,
            allowed_inbounds = NULL,
            webhook_set   = 0,
            expire_at     = ?,
            expire_warned = 0
         WHERE bot_token = ?"
    )->execute([
        $inv['volume_gb'],
        $inv['config_limit'],
        $panel_to_assign,
        $pool_id,
        $buyer_id,
        $expire_at,
        $bot_token,
    ]);

    // Also update invoice with the panel that was actually assigned
    $pdo->prepare(
        "UPDATE reseller_bot_invoice SET panel_name=? WHERE order_id=?"
    )->execute([$panel_to_assign, $order_id]);

    // NOTE: deliberately NOT touching the `reseller` table here.
    // پنل نمایندگی (reseller_bot) و کانفیگ نمایندگی (reseller) دو سیستم کاملاً مستقل‌اند.

    // ---------------------------------------------------
    // 5. Set webhook — ensure URL has https://
    // ---------------------------------------------------
    $domain_with_scheme = _bot_sale_ensure_scheme($domainhosts);
    $wh_result  = child_set_webhook($bot_token, $domain_with_scheme);
    $webhook_ok = $wh_result['ok'] ?? false;

    if ($webhook_ok) {
        $pdo->prepare("UPDATE reseller_bot SET webhook_set=1 WHERE bot_token=?")->execute([$bot_token]);
    } else {
        // Log failure but do NOT block delivery
        error_log("[bot_sale_deliver] webhook FAILED for {$bot_token}: " . json_encode($wh_result));
    }

    // ---------------------------------------------------
    // 6. Mark invoice as paid + delivered (idempotent)
    // ---------------------------------------------------
    $pdo->prepare(
        "UPDATE reseller_bot_invoice
         SET payment_status='paid', delivered=1, paid_at=?
         WHERE order_id=?"
    )->execute([time(), $order_id]);

    // ---------------------------------------------------
    // 7. Compose delivery message to buyer
    // ---------------------------------------------------
    $bot_username = $rb['bot_username'] ?? $inv['bot_username'] ?? '—';
    $vol_txt      = $inv['volume_gb'] >= 1024
        ? round($inv['volume_gb'] / 1024, 1) . ' TB'
        : $inv['volume_gb'] . ' GB';

    $panel_line = !empty($panel_to_assign)
        ? "\n🌐 پنل اختصاصی: <b>{$panel_to_assign}</b>"
        : "\n⚠️ پنل: هنوز تخصیص داده نشده — با پشتیبانی تماس بگیرید";

    $expire_line = $expire_at > 0
        ? "\n⏳ مدت اعتبار: <b>{$duration_days} روز</b> (تا " . date('Y/m/d', $expire_at) . ")"
        : "\n⏳ مدت اعتبار: <b>نامحدود</b>";

    $wh_line = $webhook_ok
        ? "\n✅ Webhook تنظیم شد — ربات آماده استفاده است"
        : "\n⚠️ Webhook به‌صورت خودکار تنظیم نشد. با پشتیبانی تماس بگیرید.";

    $msg  = "🎉 <b>پنل نمایندگی شما آماده است!</b>\n\n";
    $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
    $msg .= "📦 حجم: <b>{$vol_txt}</b>\n";
    $msg .= "👥 سقف کانفیگ: <b>{$inv['config_limit']}</b>";
    $msg .= $expire_line;
    $msg .= $panel_line;
    $msg .= $wh_line;
    $msg .= "\n\n🤖 ربات شما: @{$bot_username}";
    $msg .= "\n🚀 همین الان ربات خود را در تلگرام باز کنید تا شروع به کار کند.";

    sendmessage($buyer_id, $msg, null, 'HTML');

    // Notify admin too
    global $adminnumber;
    sendmessage(
        $adminnumber,
        "✅ <b>پنل تحویل داده شد</b>\n\n"
        . "👤 خریدار: <code>{$buyer_id}</code>\n"
        . "🤖 ربات: @{$bot_username}\n"
        . "🌐 پنل: <b>" . ($panel_to_assign ?: '—') . "</b>\n"
        . "🔗 Webhook: " . ($webhook_ok ? '✅' : '❌ ناموفق') . "\n"
        . "📌 سفارش: <code>{$order_id}</code>",
        null, 'HTML'
    );

    return [
        'ok'          => true,
        'msg'         => '✅ پنل با موفقیت تحویل داده شد',
        'webhook_ok'  => $webhook_ok,
        'panel'       => $panel_to_assign,
        'bot_username'=> $bot_username,
    ];
}

// ------------------------------------------------------------------
// تابع‌های کمکی داخلی
// ------------------------------------------------------------------

function _bot_sale_get_plan(int $plan_id): ?array
{
    global $pdo;
    $s = $pdo->prepare("SELECT * FROM reseller_bot_plan WHERE id=? AND status='active'");
    $s->execute([$plan_id]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

function _bot_sale_create_invoice(string $order_id, $buyer_id, array $plan, array $pv, string $method): void
{
    global $pdo;
    $pdo->prepare(
        "INSERT INTO reseller_bot_invoice
         (order_id, buyer_id, plan_id, plan_name, volume_gb, config_limit, duration_days, price,
          panel_name, bot_token, bot_username, payment_method, payment_status, delivered, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'pending',0,?)"
    )->execute([
        $order_id, $buyer_id, $plan['id'], $plan['name'],
        $plan['volume_gb'], $plan['config_limit'], $plan['duration_days'], $plan['price'],
        $plan['panel_name'], $pv['bot_token'] ?? '', $pv['bot_username'] ?? '',
        $method, time()
    ]);

    // ثبت reseller_bot اگه هنوز نیست
    $exists = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=?");
    $exists->execute([$pv['bot_token'] ?? '']);
    if (!$exists->fetch()) {
        _bot_sale_register_reseller_bot($pv, $plan, $buyer_id);
    }
}

function _bot_sale_register_reseller_bot(array $pv, array $plan, $buyer_id): void
{
    global $pdo;
    $bot_token    = $pv['bot_token']    ?? '';
    $bot_username = $pv['bot_username'] ?? '';
    $bot_name     = $pv['bot_name']     ?? $bot_username;

    if (!$bot_token) return;

    $exists = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=?");
    $exists->execute([$bot_token]);
    if ($exists->fetch()) return; // already exists

    $duration_days = max(0, intval($plan['duration_days'] ?? 0));
    $expire_at     = $duration_days > 0 ? (time() + $duration_days * 86400) : 0;

    $pdo->prepare(
        "INSERT INTO reseller_bot
         (bot_token, bot_username, bot_name, owner_id, panel_name, allowed_inbounds,
          volume_limit, volume_used, config_limit, config_used,
          price_per_gb, price_per_month, wallet, auto_disable_days, status, webhook_set, expire_at, created_at)
         VALUES (?,?,?,?,?,NULL,?,0,?,0,0,0,0,3,'pending',0,?,?)"
    )->execute([
        $bot_token, $bot_username, $bot_name, $buyer_id,
        $plan['panel_name'] ?? '',
        $plan['volume_gb'], $plan['config_limit'],
        $expire_at,
        time()
    ]);
}


// ------------------------------------------------------------------
// _bot_sale_create_pending_order
// Creates a single reseller_bot_invoice row with approval_status='awaiting_approval'.
// No payment method is set yet — that only happens after admin approval.
// ------------------------------------------------------------------
function _bot_sale_create_pending_order($buyer_id, array $plan, array $pv): ?string
{
    global $pdo;
    $order_id = 'BP' . time() . rand(1000, 9999);

    $ok = $pdo->prepare(
        "INSERT INTO reseller_bot_invoice
         (order_id, buyer_id, plan_id, plan_name, volume_gb, config_limit, duration_days, price,
          panel_name, bot_token, bot_username, payment_method, payment_status,
          approval_status, owner_numeric_id, delivered, created_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,'','pending','awaiting_approval',?,0,?)"
    )->execute([
        $order_id, $buyer_id, $plan['id'], $plan['name'],
        $plan['volume_gb'], $plan['config_limit'], $plan['duration_days'], $plan['price'],
        $plan['panel_name'], $pv['bot_token'] ?? '', $pv['bot_username'] ?? '',
        $buyer_id, time(),
    ]);
    if (!$ok) return null;

    // ثبت reseller_bot به‌صورت pending (هیچ پنلی هنوز اختصاص نمی‌یابد)
    $exists = $pdo->prepare("SELECT id FROM reseller_bot WHERE bot_token=?");
    $exists->execute([$pv['bot_token'] ?? '']);
    if (!$exists->fetch()) {
        _bot_sale_register_reseller_bot($pv, $plan, $buyer_id);
    }

    return $order_id;
}

// ------------------------------------------------------------------
// _bot_sale_get_approved_invoice
// Fetches an invoice but ONLY if it belongs to this buyer AND has
// already been approved by an admin. Used by every payment-method
// handler so payment can never be reached without prior approval.
// ------------------------------------------------------------------
function _bot_sale_get_approved_invoice(string $order_id, $buyer_id): ?array
{
    global $pdo;
    $s = $pdo->prepare(
        "SELECT * FROM reseller_bot_invoice
         WHERE order_id=? AND buyer_id=? AND approval_status='approved' AND delivered=0"
    );
    $s->execute([$order_id, $buyer_id]);
    return $s->fetch(PDO::FETCH_ASSOC) ?: null;
}

// ------------------------------------------------------------------
// _bot_sale_payment_options_kb / _bot_sale_payment_options_text /
// _bot_sale_send_payment_options
// Shown ONLY after admin approval. Mirrors the gateway-availability
// logic that used to live inline in bot_sale_confirm_token.
// ------------------------------------------------------------------
function _bot_sale_payment_options_kb(string $order_id): ?string
{
    $setting = select('setting', '*');
    $rows    = [];

    $cart_status  = select('PaySetting', 'ValuePay', 'NamePay', 'Cartstatus', 'select')['ValuePay'] ?? 'offcard';
    $now_status   = select('PaySetting', 'ValuePay', 'NamePay', 'nowpaymentstatus', 'select')['ValuePay'] ?? 'offnowpayment';
    $aqaye_status = select('PaySetting', 'ValuePay', 'NamePay', 'statusaqayepardakht', 'select')['ValuePay'] ?? 'offaqayepardakht';
    $zarin_status = select('PaySetting', 'ValuePay', 'NamePay', 'statuszarinpal', 'select')['ValuePay'] ?? 'offzarinpal';

    $zarin_key = select('PaySetting', 'ValuePay', 'NamePay', 'merchant_id_zarinpal', 'select')['ValuePay'] ?? '';
    $aqaye_key = select('PaySetting', 'ValuePay', 'NamePay', 'merchant_id_aqayepardakht', 'select')['ValuePay'] ?? '';
    $now_key   = select('PaySetting', 'ValuePay', 'NamePay', 'apinowpayment', 'select')['ValuePay'] ?? '';

    if (!empty($setting['bot_sale_card_num']) && $cart_status !== 'offcard') {
        $rows[] = [['text' => '💳 پرداخت کارت به کارت', 'callback_data' => "bot_sale_pay_card_{$order_id}"]];
    }
    if (!empty($zarin_key) && $zarin_status !== 'offzarinpal') {
        $rows[] = [['text' => '🔐 پرداخت آنلاین (زرین‌پال)', 'callback_data' => "bot_sale_pay_zarinpal_{$order_id}"]];
    }
    if (!empty($aqaye_key) && $aqaye_status !== 'offaqayepardakht') {
        $rows[] = [['text' => '💳 پرداخت آنلاین (آقای پرداخت)', 'callback_data' => "bot_sale_pay_aqaye_{$order_id}"]];
    }
    if (!empty($now_key) && $now_status !== 'offnowpayment') {
        $rows[] = [['text' => '🔐 پرداخت آنلاین (NowPayments)', 'callback_data' => "bot_sale_pay_nowpayments_{$order_id}"]];
    }

    if (empty($rows)) return null;

    return json_encode(['inline_keyboard' => $rows]);
}

function _bot_sale_payment_options_text(array $inv): string
{
    $msg  = "✅ <b>سفارش شما تایید شد!</b>\n\n";
    $msg .= "💳 <b>انتخاب روش پرداخت</b>\n\n";
    $msg .= "📋 پلن: <b>{$inv['plan_name']}</b>\n";
    $msg .= "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n\n";
    $msg .= "روش پرداخت خود را انتخاب کنید:";
    return $msg;
}

function _bot_sale_send_payment_options($buyer_id, string $order_id): void
{
    global $pdo;
    $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
    $inv->execute([$order_id]);
    $inv = $inv->fetch(PDO::FETCH_ASSOC);
    if (!$inv) return;

    $kb = _bot_sale_payment_options_kb($order_id);
    if (!$kb) {
        sendmessage($buyer_id,
            "⚠️ سفارش شما تایید شد اما در حال حاضر هیچ روش پرداختی فعال نیست. لطفاً با پشتیبانی تماس بگیرید.\n📌 سفارش: <code>{$order_id}</code>",
            null, 'HTML');
        return;
    }
    sendmessage($buyer_id, _bot_sale_payment_options_text($inv), $kb, 'HTML');
}

// ------------------------------------------------------------------
// _bot_sale_ensure_scheme
// Guarantees the domain has https:// so webhook URLs are valid.
// ------------------------------------------------------------------
function _bot_sale_ensure_scheme(string $domain): string
{
    $domain = trim($domain);
    if (!preg_match('#^https?://#i', $domain)) {
        $domain = 'https://' . $domain;
    }
    return rtrim($domain, '/');
}

// ------------------------------------------------------------------
// مدیریت پلن‌ها — ادمین (فراخوانی از handle_reseller_admin یا index.php)
// ------------------------------------------------------------------
function handle_bot_sale_admin($from_id, $text, $datain, $user, $keyboard)
{
    global $pdo;

    if ($text === '🤖 مدیریت پلن‌های پنل') {
        $plans = $pdo->query("SELECT * FROM reseller_bot_plan ORDER BY price ASC")->fetchAll(PDO::FETCH_ASSOC);
        $msg   = "🤖 <b>پلن‌های فروش پنل نمایندگی</b>\n\n";
        if (empty($plans)) {
            $msg .= "هنوز پلنی تعریف نشده.";
        }
        $rows  = [];
        foreach ($plans as $p) {
            $status  = $p['status'] === 'active' ? '✅' : '🔴';
            $vol     = $p['volume_gb'] >= 1024
                ? round($p['volume_gb'] / 1024, 1) . 'TB'
                : $p['volume_gb'] . 'GB';
            $rows[] = [['text' => "{$status} {$p['name']} | {$vol} | " . number_format($p['price']) . "ت",
                         'callback_data' => "admin_bplan_edit_{$p['id']}"]];
        }
        $rows[] = [['text' => '➕ افزودن پلن جدید', 'callback_data' => 'admin_bplan_add']];
        $rows[] = [['text' => '🔙 بازگشت', 'callback_data' => 'backadmin']];
        sendmessage($from_id, $msg, json_encode(['inline_keyboard' => $rows]), 'HTML');
        return true;
    }

    // ---- مراحل افزودن پلن ----
    if ($user['step'] === 'admin_bplan_name') {
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([
            json_encode(['step' => 'name', 'name' => $text]), $from_id
        ]);
        sendmessage($from_id, "📦 حجم (GB) وارد کنید (مثلاً 100):", null, 'HTML');
        step('admin_bplan_volume', $from_id);
        return true;
    }
    if ($user['step'] === 'admin_bplan_volume') {
        $pv = json_decode($user['Processing_value'], true);
        $pv['volume_gb'] = max(1, intval($text));
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([json_encode($pv), $from_id]);
        sendmessage($from_id, "👥 سقف کانفیگ وارد کنید (مثلاً 50):", null, 'HTML');
        step('admin_bplan_configs', $from_id);
        return true;
    }
    if ($user['step'] === 'admin_bplan_configs') {
        $pv = json_decode($user['Processing_value'], true);
        $pv['config_limit'] = max(1, intval($text));
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([json_encode($pv), $from_id]);
        sendmessage($from_id, "⏳ مدت (روز) وارد کنید (مثلاً 30):", null, 'HTML');
        step('admin_bplan_days', $from_id);
        return true;
    }
    if ($user['step'] === 'admin_bplan_days') {
        $pv = json_decode($user['Processing_value'], true);
        $pv['duration_days'] = max(1, intval($text));
        $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([json_encode($pv), $from_id]);
        sendmessage($from_id, "💰 قیمت (تومان) وارد کنید:", null, 'HTML');
        step('admin_bplan_price', $from_id);
        return true;
    }
    if ($user['step'] === 'admin_bplan_price') {
        $pv = json_decode($user['Processing_value'], true);
        $pv['price'] = max(0, intval(str_replace(',', '', $text)));

        // دریافت لیست پنل‌ها
        $panels = $pdo->query("SELECT name_panel FROM marzban_panel WHERE status='active'")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($panels)) {
            // ثبت بدون انتخاب پنل
            $pdo->prepare(
                "INSERT INTO reseller_bot_plan (name, volume_gb, config_limit, duration_days, price, panel_name, status, created_at)
                 VALUES (?,?,?,?,?,'','active',?)"
            )->execute([$pv['name'], $pv['volume_gb'], $pv['config_limit'], $pv['duration_days'], $pv['price'], time()]);
            sendmessage($from_id, "✅ پلن ثبت شد.", null, 'HTML');
            step('home', $from_id);
        } else {
            $pdo->prepare("UPDATE user SET Processing_value=? WHERE id=?")->execute([json_encode($pv), $from_id]);
            $rows = array_map(fn($p) => [['text' => $p['name_panel'], 'callback_data' => "admin_bplan_panel_" . urlencode($p['name_panel'])]], $panels);
            $rows[] = [['text' => '⏭ بدون پنل خاص', 'callback_data' => 'admin_bplan_panel_none']];
            sendmessage($from_id, "🖥 پنل Remnawave/Marzban را انتخاب کنید:", json_encode(['inline_keyboard' => $rows]), 'HTML');
            step('home', $from_id);
        }
        return true;
    }

    return false;
}

function handle_bot_sale_admin_callbacks($from_id, $datain, $message_id, $callback_query_id)
{
    global $pdo;

    if ($datain === 'admin_bplan_add') {
        sendmessage($from_id, "📝 نام پلن را وارد کنید (مثلاً: پلن برنزی):", null, 'HTML');
        step('admin_bplan_name', $from_id);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    // انتخاب پنل برای پلن
    if (preg_match('/^admin_bplan_panel_(.+)$/', $datain, $m)) {
        $panel_name = $m[1] === 'none' ? '' : urldecode($m[1]);
        $user_row   = $pdo->prepare("SELECT Processing_value FROM user WHERE id=?");
        $user_row->execute([$from_id]);
        $pv = json_decode($user_row->fetchColumn() ?? '{}', true);

        $pdo->prepare(
            "INSERT INTO reseller_bot_plan (name, volume_gb, config_limit, duration_days, price, panel_name, status, created_at)
             VALUES (?,?,?,?,?,?,'active',?)"
        )->execute([$pv['name'], $pv['volume_gb'], $pv['config_limit'], $pv['duration_days'], $pv['price'], $panel_name, time()]);

        Editmessagetext($from_id, $message_id, "✅ پلن ثبت شد.", null);
        AnswerCallbackQuery($callback_query_id, '✅ پلن ثبت شد');
        $pdo->prepare("UPDATE user SET Processing_value='' WHERE id=?")->execute([$from_id]);
        return true;
    }

    // ویرایش / حذف پلن
    if (preg_match('/^admin_bplan_edit_(\d+)$/', $datain, $m)) {
        $plan = $pdo->prepare("SELECT * FROM reseller_bot_plan WHERE id=?");
        $plan->execute([$m[1]]);
        $plan = $plan->fetch(PDO::FETCH_ASSOC);
        if (!$plan) { AnswerCallbackQuery($callback_query_id, '❌ یافت نشد'); return true; }

        $status_lbl = $plan['status'] === 'active' ? '🔴 غیرفعال کن' : '✅ فعال کن';
        $msg = "✏️ <b>پلن: {$plan['name']}</b>\n"
             . "📦 حجم: {$plan['volume_gb']} GB | 👥 {$plan['config_limit']} کانفیگ\n"
             . "⏳ {$plan['duration_days']} روز | 💰 " . number_format($plan['price']) . " تومان";
        $kb = json_encode(['inline_keyboard' => [
            [['text' => $status_lbl, 'callback_data' => "admin_bplan_toggle_{$plan['id']}"]],
            [['text' => '🗑 حذف پلن', 'callback_data' => "admin_bplan_del_{$plan['id']}"]],
            [['text' => '🔙 بازگشت', 'callback_data' => 'admin_bplan_list']],
        ]]);
        Editmessagetext($from_id, $message_id, $msg, $kb);
        AnswerCallbackQuery($callback_query_id);
        return true;
    }

    if (preg_match('/^admin_bplan_toggle_(\d+)$/', $datain, $m)) {
        $plan = $pdo->prepare("SELECT status FROM reseller_bot_plan WHERE id=?");
        $plan->execute([$m[1]]);
        $plan = $plan->fetch(PDO::FETCH_ASSOC);
        $new  = $plan['status'] === 'active' ? 'inactive' : 'active';
        $pdo->prepare("UPDATE reseller_bot_plan SET status=? WHERE id=?")->execute([$new, $m[1]]);
        AnswerCallbackQuery($callback_query_id, $new === 'active' ? '✅ فعال شد' : '🔴 غیرفعال شد');
        return true;
    }

    if (preg_match('/^admin_bplan_del_(\d+)$/', $datain, $m)) {
        $pdo->prepare("DELETE FROM reseller_bot_plan WHERE id=?")->execute([$m[1]]);
        Editmessagetext($from_id, $message_id, "🗑 پلن حذف شد.", null);
        AnswerCallbackQuery($callback_query_id, '🗑 حذف شد');
        return true;
    }

    return false;
}
