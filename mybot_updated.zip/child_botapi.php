<?php
// child_botapi.php
// توابع API تلگرام برای زیر ربات‌ها - با توکن متفاوت از ربات مادر

function child_telegram($bot_token, $method, $datas = [])
{
    $url = "https://api.telegram.org/bot" . $bot_token . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $res = json_decode(curl_exec($ch), true);
    curl_close($ch);
    if (!($res['ok'] ?? false)) {
        error_log("child_telegram error [{$method}]: " . json_encode($res));
    }
    return $res;
}

function child_sendmessage($bot_token, $chat_id, $text, $keyboard = null, $parse_mode = 'HTML')
{
    return child_telegram($bot_token, 'sendMessage', [
        'chat_id'                  => $chat_id,
        'text'                     => $text,
        'reply_markup'             => $keyboard,
        'parse_mode'               => $parse_mode,
        'disable_web_page_preview' => true,
    ]);
}

function child_editmessage($bot_token, $chat_id, $message_id, $text, $keyboard = null, $parse_mode = 'HTML')
{
    return child_telegram($bot_token, 'editMessageText', [
        'chat_id'                  => $chat_id,
        'message_id'               => $message_id,
        'text'                     => $text,
        'reply_markup'             => $keyboard,
        'parse_mode'               => $parse_mode,
        'disable_web_page_preview' => true,
    ]);
}

function child_deletemessage($bot_token, $chat_id, $message_id)
{
    return child_telegram($bot_token, 'deleteMessage', [
        'chat_id'    => $chat_id,
        'message_id' => $message_id,
    ]);
}

function child_answer_callback($bot_token, $callback_query_id, $text = '', $show_alert = false)
{
    return child_telegram($bot_token, 'answerCallbackQuery', [
        'callback_query_id' => $callback_query_id,
        'text'              => $text,
        'show_alert'        => $show_alert,
    ]);
}

// تنظیم webhook برای زیر ربات
function child_set_webhook($bot_token, $domain, $secret = '')
{
    // Guarantee https:// is present — Telegram rejects http webhooks
    $domain = trim($domain);
    if (!preg_match('#^https?://#i', $domain)) {
        $domain = 'https://' . $domain;
    }
    $domain = rtrim($domain, '/');
    $webhook_url = $domain . '/child_bot.php?token=' . urlencode($bot_token);
    $params = ['url' => $webhook_url, 'max_connections' => 40, 'drop_pending_updates' => true];
    if ($secret) $params['secret_token'] = $secret;
    $result = child_telegram($bot_token, 'setWebhook', $params);
    if (!($result['ok'] ?? false)) {
        error_log("[child_set_webhook] FAILED for token={$bot_token} url={$webhook_url}: " . json_encode($result));
    }
    return $result;
}

// حذف webhook زیر ربات
function child_delete_webhook($bot_token)
{
    return child_telegram($bot_token, 'deleteWebhook', ['drop_pending_updates' => true]);
}

// گرفتن اطلاعات ربات از توکن
function child_get_bot_info($bot_token)
{
    $res = child_telegram($bot_token, 'getMe', []);
    if ($res['ok'] ?? false) {
        return $res['result'];
    }
    return null;
}

// ارسال پیام به همه کاربران یه زیر ربات (broadcast)
function child_broadcast($bot_token, $text, $keyboard = null, $parse_mode = 'HTML')
{
    global $pdo;
    $users = $pdo->prepare("SELECT user_id FROM child_bot_user WHERE bot_token = ? AND User_Status = 'active'");
    $users->execute([$bot_token]);
    $users = $users->fetchAll(PDO::FETCH_ASSOC);
    $sent = 0; $failed = 0;
    foreach ($users as $u) {
        $r = child_sendmessage($bot_token, $u['user_id'], $text, $keyboard, $parse_mode);
        if ($r['ok'] ?? false) $sent++; else $failed++;
        usleep(50000); // 50ms بین هر ارسال
    }
    return ['sent' => $sent, 'failed' => $failed];
}

// تابع helper برای فرمت GB (قابل استفاده در reseller.php هم)
if (!function_exists('child_fmt_gb')) {
    function child_fmt_gb($gb) {
        return $gb >= 1024 ? round($gb/1024, 2).' TB' : $gb.' GB';
    }
}
