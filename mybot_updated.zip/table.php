<?php
$randomString = bin2hex(random_bytes(3));
require_once 'config.php';
require_once 'text.php';
require_once 'functions.php';
global $connect;
//-----------------------------------------------------------------
$tableName = "user";
try {
    $result = $connect->query("SHOW TABLES LIKE 'user'");
    $table_exists = ($result->num_rows > 0);
    $tableName = "user";
    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE user (
        id varchar(500)  PRIMARY KEY,
        ref_code CHAR(32) NOT NULL UNIQUE, 
        limit_usertest int(100) NOT NULL,
        roll_Status bool NOT NULL,
        Processing_value  TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
        Processing_value_one varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
        Processing_value_tow varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
        Processing_value_four varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
        step varchar(1000) NOT NULL,
        description_blocking TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        number varchar(2000) NOT null ,
        Balance int(255) NOT null ,
        User_Status varchar(500) NOT NULL,
        pagenumber int(10) NOT NULL,
        message_count varchar(100) NOT NULL,
        last_message_time varchar(100) NOT NULL,
        affiliatescount varchar(100) NOT NULL,
        affiliates varchar(100) NOT NULL,
        verify varchar(50) NOT NULL,
        username varchar(1000) NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table User".mysqli_error($connect);
        }
    }
    else {
        addFieldToTable($tableName, 'affiliatescount', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'verify', '0',"VARCHAR(50)");
        addFieldToTable($tableName, 'affiliates', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'message_count', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'last_message_time', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'Processing_value_four', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'username', 'none',"VARCHAR(1000)");
        addFieldToTable($tableName, 'Processing_value', '0',"TEXT");
        addFieldToTable($tableName, 'Processing_value_tow', '0',"VARCHAR(1000)");
        addFieldToTable($tableName, 'Processing_value_one', '0',"VARCHAR(1000)");
        addFieldToTable($tableName, 'roll_Status','false',"bool");
        addFieldToTable($tableName, 'Processing_value_four', '0',"VARCHAR(100)");
        addFieldToTable($tableName, 'ref_code', '', "CHAR(32)");
        $result_ref = $connect->query("SELECT id FROM user WHERE ref_code IS NULL OR ref_code = ''");
        if ($result_ref && $result_ref->num_rows > 0) {
            while ($row = $result_ref->fetch_assoc()) {
                $id = $row['id'];
                
                do {
                    // Generate a secure random ref_code
                    $new_ref_code = bin2hex(random_bytes(16)); // Output: 32 hexadecimal characters

                    // Check for duplicates in the database
                    $stmt_check = $connect->prepare("SELECT id FROM user WHERE ref_code = ?");
                    $stmt_check->bind_param("s", $new_ref_code);
                    $stmt_check->execute();
                    $check_result = $stmt_check->get_result();
                    $is_duplicate = ($check_result && $check_result->num_rows > 0);
                    $stmt_check->close();

                } while ($is_duplicate); // Continue as long as the code is duplicate

                // Insert the unique code for the user
                $stmt_update = $connect->prepare("UPDATE user SET ref_code = ? WHERE id = ?");
                $stmt_update->bind_param("ss", $new_ref_code, $id);
                $stmt_update->execute();
                $stmt_update->close();
            }
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {
    $result = $connect->query("SHOW TABLES LIKE 'help'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE help (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name_os varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
        Media_os varchar(5000) NOT NULL,
        type_Media_os varchar(500) NOT NULL,
        Description_os TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table help".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {
    $result = $connect->query("SHOW TABLES LIKE 'setting'");
    $table_exists = ($result->num_rows > 0);
    $tableName = "setting";
    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE setting (
        Bot_Status varchar(200)  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        help_Status varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        roll_Status varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        get_number varchar(200)  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        iran_number varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        NotUser varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        Channel_Report varchar(600)  NULL,
        limit_usertest_all varchar(600)  NULL,
        time_usertest varchar(600)  NULL,
        val_usertest varchar(600)  NULL,
        Extra_volume varchar(600)  NULL,
        namecustome varchar(100)  NULL,
        status_verify varchar(50)  NULL,
        removedayc varchar(100)  NULL,
        copy_cart varchar(20)  NULL,
        statuscategory varchar(100)  NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table setting".mysqli_error($connect);
        }
        $active_bot_text = "1";
        $active_roll_text = "0";
        $active_phone_text = "0";
        $active_phone_iran_text = "0";
        $active_help = "0";
$connect->query("INSERT INTO setting (Bot_Status,roll_Status,get_number,limit_usertest_all,time_usertest,val_usertest,help_Status,iran_number,NotUser,namecustome,removedayc,status_verify,statuscategory,copy_cart) VALUES ('$active_bot_text','$active_roll_text','$active_phone_text','1','1','100','$active_help','$active_phone_iran_text','0','0','1','0','1','0')");
    } else {
        addFieldToTable($tableName, 'copy_cart', '0',"VARCHAR(20)");
        addFieldToTable($tableName, 'status_verify', '0',"VARCHAR(50)");
        addFieldToTable($tableName, 'statuscategory', '1',"VARCHAR(50)");
        addFieldToTable($tableName, 'namecustome', '0',"VARCHAR(200)");
        addFieldToTable($tableName, 'removedayc', '1',"VARCHAR(100)");
        addFieldToTable($tableName, 'Extra_volume', '0',"VARCHAR(200)");
        $settingsql = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM setting"));
        $active_phone_iran_text = "0";
        if(!isset($settingsql['iran_number'])){
        $stmt = $connect->prepare("UPDATE setting SET iran_number = ?");
        $stmt->bind_param("s", $active_phone_iran_text);
        $stmt->execute();
        }
        if(!isset($settingsql['NotUser'])){
        $stmt = $connect->prepare("UPDATE setting SET NotUser = ?");
        $text = "offnotuser";
        $stmt->bind_param("s", $text);
        $stmt->execute();
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}

//-----------------------------------------------------------------
try {
    $result = $connect->query("SHOW TABLES LIKE 'admin'");
    $table_exists = ($result->num_rows > 0);
    if ($table_exists) {
        // اضافه کردن ستون role اگه وجود نداشت
        $col = $connect->query("SHOW COLUMNS FROM admin LIKE 'role'");
        if ($col->num_rows == 0) {
            $connect->query("ALTER TABLE admin ADD role VARCHAR(20) NOT NULL DEFAULT 'super'");
            // ادمین اول super میشه
            $connect->query("UPDATE admin SET role = 'super' WHERE id_admin = '$adminnumber'");
            echo "admin role column added ✅</br>";
        }
        $id_admin = mysqli_query($connect, "SELECT * FROM admin");
        while ($row = mysqli_fetch_assoc($id_admin)) {
            $admin_ids[] = $row['id_admin'];
        }
        if (!in_array($adminnumber, $admin_ids)) {
            $connect->query("INSERT INTO admin (id_admin, role) VALUES ('$adminnumber', 'super')");
            echo "table admin update✅</br>";
        }
    } else {
        $result = $connect->query("CREATE TABLE admin (
        id_admin varchar(200) PRIMARY KEY NOT NULL,
        role varchar(20) NOT NULL DEFAULT 'super')");
        $connect->query("INSERT INTO admin (id_admin, role) VALUES ('$adminnumber', 'super')");
        if (!$result) {
            echo "table admin".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'channels'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result =  $connect->query("CREATE TABLE channels (
            link varchar(200) NOT NULL )");
        if (!$result) {
            echo "table channels".mysqli_error($connect);
        }
        }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//--------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'marzban_panel'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE marzban_panel (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name_panel varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        url_panel varchar(2000) NULL,
        username_panel varchar(200) NULL,
        password_panel TEXT NULL,
        status varchar(100) NULL,
        statusTest varchar(100) NULL,
        type varchar(200) NULL,
        linksubx varchar(500) NULL,
        inboundid TEXT NULL,
        MethodUsername varchar(900)  NULL,
        sublink varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        configManual varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        onholdstatus varchar(200) NULL,
        datelogin TEXT NULL,
        inbounds TEXT NULL,
        proxies TEXT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table marzban_panel".mysqli_error($connect);
        }
        }
        else{
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'datelogin'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD datelogin TEXT");
            echo "The datelogin field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'inbounds'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD inbounds TEXT");
            echo "The inbounds field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'proxies'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD proxies TEXT");
            echo "The proxies field was added ✅";
        }
         $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'statusTest'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD statusTest VARCHAR(100)");
            $connect->query("UPDATE marzban_panel SET statusTest = 'ontestshowpanel'");
            echo "The statusTest field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'status'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD status VARCHAR(100)");
            $connect->query("UPDATE marzban_panel SET status = 'activepanel'");
            echo "The status field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'onholdstatus'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD onholdstatus VARCHAR(100)");
            $connect->query("UPDATE marzban_panel SET onholdstatus = 'offonhold'");
            echo "The onholdstatus field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'sublink'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD sublink VARCHAR(200)");
            $connect->query("UPDATE marzban_panel SET sublink = 'onsublink'");
            echo "The sublink field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'configManual'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD configManual VARCHAR(200)");
            $connect->query("UPDATE marzban_panel SET configManual = 'offconfig'");
            echo "The configManual field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'MethodUsername'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD MethodUsername VARCHAR(900)");
            $connect->query("UPDATE marzban_panel SET MethodUsername = '{$textbotlang['users']['customidAndRandom']}'");
            echo "The MethodUsername field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'inboundid'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD inboundid VARCHAR(200)");
            echo "The inboundid field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'linksubx'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD linksubx VARCHAR(500)");
            echo "The linksubx field was added ✅";
        }
        $Check_filde = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'type'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE marzban_panel ADD type VARCHAR(200)");
            $connect->query("UPDATE marzban_panel SET type = 'marzban'");
            echo "The type field was added ✅";
        }
        // فیکس: اطمینان از اینکه password_panel برای JWT token کافیه
        $Check_pw = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'password_panel'");
        $pw_col = $Check_pw->fetch_assoc();
        if ($pw_col && strtoupper($pw_col['Type']) !== 'TEXT' && strtoupper($pw_col['Type']) !== 'LONGTEXT' && strtoupper($pw_col['Type']) !== 'MEDIUMTEXT') {
            $connect->query("ALTER TABLE marzban_panel MODIFY COLUMN password_panel TEXT");
            echo "The password_panel column upgraded to TEXT ✅";
        }
        // فیکس: inboundid برای UUID های طولانی
        $Check_ib = $connect->query("SHOW COLUMNS FROM marzban_panel LIKE 'inboundid'");
        $ib_col = $Check_ib->fetch_assoc();
        if ($ib_col && strtoupper($ib_col['Type']) !== 'TEXT' && strtoupper($ib_col['Type']) !== 'LONGTEXT' && strtoupper($ib_col['Type']) !== 'MEDIUMTEXT') {
            $connect->query("ALTER TABLE marzban_panel MODIFY COLUMN inboundid TEXT");
            echo "The inboundid column upgraded to TEXT ✅";
        }
        }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'product'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE product (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code_product varchar(200)  NULL,
        name_product varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        price_product varchar(2000) NULL,
        Volume_constraint varchar(2000) NULL,
        Location varchar(1000) NULL,
        Service_time varchar(200) NULL,
        Category varchar(600) NULL,
        squad_uuid TEXT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table product".mysqli_error($connect);
        }
    }
    else{
        $Check_filde = $connect->query("SHOW COLUMNS FROM product LIKE 'Location'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE product ADD Location VARCHAR(1000)");
        } 
        $Check_filde = $connect->query("SHOW COLUMNS FROM product LIKE 'Category'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE product ADD Category VARCHAR(600)");
        } 
        $Check_filde = $connect->query("SHOW COLUMNS FROM product LIKE 'code_product'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE product ADD code_product VARCHAR(200)");
        } 
        $Check_filde = $connect->query("SHOW COLUMNS FROM product LIKE 'squad_uuid'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $connect->query("ALTER TABLE product ADD squad_uuid TEXT NULL");
           echo "The squad_uuid field was added to product ✅";
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'invoice'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE invoice (
        id_invoice varchar(200) PRIMARY KEY,
        id_user varchar(200) NULL,
        username varchar(200) NULL,
        Service_location varchar(200) NULL,
        time_sell varchar(200) NULL,
        name_product varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        price_product varchar(200) NULL,
        Volume varchar(200) NULL,
        Service_time varchar(200) NULL,
        user_info TEXT NULL,
        Status varchar(200) NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table invoice".mysqli_error($connect);
        }
    }
    else{
     $Check_filde = $connect->query("SHOW COLUMNS FROM invoice LIKE 'time_sell'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE invoice ADD time_sell VARCHAR(2000)");
        }    
        $Check_filde = $connect->query("SHOW COLUMNS FROM invoice LIKE 'user_info'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE invoice ADD user_info TEXT");
        }    
        $Check_filde = $connect->query("SHOW COLUMNS FROM invoice LIKE 'Status'");
        if (mysqli_num_rows($Check_filde) != 1) {
           $result = $connect->query("ALTER TABLE invoice ADD Status VARCHAR(2000)");
        }    
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'Payment_report'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result =  $connect->query("CREATE TABLE Payment_report (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        id_user varchar(200),
        id_order varchar(500),
        time varchar(200)  NULL,
        price varchar(400) NULL,
        dec_not_confirmed varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        Payment_Method varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
        payment_Status varchar(2000) NULL,
        invoice varchar(300) NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table Payment_report".mysqli_error($connect);
        }
    }
    else{
      $Check_filde = $connect->query("SHOW COLUMNS FROM Payment_report LIKE 'invoice'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE Payment_report ADD invoice VARCHAR(300)");
            echo "The invoice field was added ✅";
        }   
        $Check_filde = $connect->query("SHOW COLUMNS FROM Payment_report LIKE 'Payment_Method'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE Payment_report ADD Payment_Method VARCHAR(1000)");
            echo "The Payment_Method field was added ✅";
        }   
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'Discount'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result =  $connect->query("CREATE TABLE Discount (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code varchar(2000) NULL,
        price varchar(200) NULL)");
        if (!$result) {
            echo "table Discount".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {

    $result = $connect->query("SHOW TABLES LIKE 'Giftcodeconsumed'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result =  $connect->query("CREATE TABLE  Giftcodeconsumed (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code varchar(2000) NULL,
        id_user varchar(200) NULL)");
        if (!$result) {
            echo "table Giftcodeconsumed".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {
    $result = $connect->query("SHOW TABLES LIKE 'textbot'");
    $table_exists = ($result->num_rows > 0);
    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE textbot (
        id_text varchar(600) PRIMARY KEY NOT NULL,
        text TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table textbot".mysqli_error($connect);
        }
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_start','{$textbotlang['users']['start']}') ");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_usertest','{$textbotlang['users']['usertest']['usertestbtn']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_Purchased_services','{$textbotlang['Admin']['Status']['title']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_support','{$textbotlang['users']['support']['title']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_help','{$textbotlang['users']['help']['title']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_bot_off','{$textbotlang['users']['botoff']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_roll','{$textbotlang['users']['RulesDescription']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_fq','{$textbotlang['users']['fqbtn']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_dec_fq','{$textbotlang['users']['fqDescription']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_account','{$textbotlang['users']['accountbtn']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_sell','{$textbotlang['users']['buybtn']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_Add_Balance','{$textbotlang['users']['add_balance']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_channel','{$textbotlang['users']['channeldosntjoin']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_Discount','{$textbotlang['users']['Discount']['titlebtn']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_Tariff_list','{$textbotlang['users']['pricelist']}')");
        $connect->query("INSERT INTO textbot (id_text,text) VALUES ('text_dec_Tariff_list','not set')");
    }
    else{
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_start','{$textbotlang['users']['start']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_usertest','{$textbotlang['users']['usertest']['usertestbtn']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_Purchased_services','{$textbotlang['Admin']['Status']['title']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_support','{$textbotlang['users']['support']['title']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_help','{$textbotlang['users']['help']['title']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_bot_off','{$textbotlang['users']['botoff']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_roll','{$textbotlang['users']['RulesDescription']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_fq','{$textbotlang['users']['fqbtn']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_dec_fq','{$textbotlang['users']['fqDescription']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_account','{$textbotlang['users']['accountbtn']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_sell','{$textbotlang['users']['buybtn']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_Add_Balance','{$textbotlang['users']['add_balance']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_channel','{$textbotlang['users']['channeldosntjoin']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_Discount','{$textbotlang['users']['Discount']['titlebtn']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_Tariff_list','{$textbotlang['users']['pricelist']}')");
        $connect->query("INSERT IGNORE INTO textbot (id_text,text) VALUES ('text_dec_Tariff_list','not set')");


    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
try {
    $result = $connect->query("SHOW TABLES LIKE 'PaySetting'");
    $table_exists = ($result->num_rows > 0);
    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE PaySetting (
        NamePay varchar(500) PRIMARY KEY NOT NULL,
        ValuePay TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table PaySetting".mysqli_error($connect);
        }
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('CartDescription','603700000000') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('Cartstatus','oncard') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('apinowpayment','0') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('nowpaymentstatus','offnowpayment') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('digistatus','offdigi') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('statusaqayepardakht','offaqayepardakht') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('merchant_id_aqayepardakht','0')");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('statuszarinpal','offzarinpal') ");
        $connect->query("INSERT INTO PaySetting (NamePay,ValuePay) VALUES ('merchant_id_zarinpal','0')");
    }
    else{
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('Cartstatus','oncard') ");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('CartDescription','603700000000') ");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('apinowpayment','0')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('nowpaymentstatus','offnowpayment')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('digistatus','offdigi')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('statusaqayepardakht','offaqayepardakht')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('merchant_id_aqayepardakht','0')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('statuszarinpal','offzarinpal')");
        $connect->query("INSERT IGNORE INTO PaySetting (NamePay,ValuePay) VALUES ('merchant_id_zarinpal','0')");



    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//----------------------- [ Discount ] --------------------- //
try {
    $result = $connect->query("SHOW TABLES LIKE 'DiscountSell'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE DiscountSell (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        codeDiscount varchar(1000)  NOT NULL,
        price varchar(200)  NOT NULL,
        limitDiscount varchar(500)  NOT NULL,
        usedDiscount varchar(500) NOT NULL,
        usefirst varchar(500) NOT NULL)");
        if (!$result) {
            echo "table DiscountSell".mysqli_error($connect);
        }
    }else{
      $Check_filde = $connect->query("SHOW COLUMNS FROM DiscountSell LIKE 'usefirst'");
        if (mysqli_num_rows($Check_filde) != 1) {
            $connect->query("ALTER TABLE DiscountSell ADD usefirst VARCHAR(500)");
            echo "The DiscountSell field was added ✅";
        }   
    }
} catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//-----------------------------------------------------------------
try {
    $result = $connect->query("SHOW TABLES LIKE 'affiliates'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE affiliates (
        description TEXT  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        status_commission varchar(200)  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        Discount varchar(200)  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        price_Discount varchar(200)  CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        id_media varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NULL,
        affiliatesstatus varchar(600)  NULL,
        affiliatespercentage varchar(600)  NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table affiliates".mysqli_error($connect);
        }
        $connect->query("INSERT INTO affiliates (description,id_media,status_commission,Discount,affiliatesstatus,affiliatespercentage) VALUES ('none','none','oncommission','onDiscountaffiliates','offaffiliates','0')");
    }
}
catch (Exception $e) {
    file_put_contents("$randomString.txt",$e->getMessage());
}
//----------------------- [ remove requests ] --------------------- //
try {
    $result = $connect->query("SHOW TABLES LIKE 'cancel_service'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE cancel_service (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        id_user varchar(500)  NOT NULL,
        username varchar(1000)  NOT NULL,
        description TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NOT NULL,
        status varchar(1000)  NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table cancel_service".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents('error_log',$e->getMessage());
}
$connect->query("ALTER TABLE `user` CHANGE `Processing_value` `Processing_value` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;");

//----------------------- [ Category ] --------------------- //
try {
    $result = $connect->query("SHOW TABLES LIKE 'category'");
    $table_exists = ($result->num_rows > 0);

    if (!$table_exists) {
        $result = $connect->query("CREATE TABLE category (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        remark varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin  NOT NULL)
        ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        if (!$result) {
            echo "table category".mysqli_error($connect);
        }
    }
} catch (Exception $e) {
    file_put_contents('error_log',$e->getMessage());
}
$connect->query("ALTER TABLE `user` CHANGE `Processing_value` `Processing_value` TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;");
//----------------------- [ Reseller Bot ] --------------------- //
try {
    // جدول زیر ربات‌های نمایندگان
    $result = $connect->query("SHOW TABLES LIKE 'reseller_bot'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_bot (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL UNIQUE,
            bot_username VARCHAR(100) NOT NULL,
            bot_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            owner_id VARCHAR(200) NOT NULL,
            panel_id INT UNSIGNED NULL,
            panel_name VARCHAR(200) NOT NULL DEFAULT '',
            allowed_inbounds TEXT NULL,
            volume_limit BIGINT NOT NULL DEFAULT 0,
            volume_used BIGINT NOT NULL DEFAULT 0,
            config_limit INT NOT NULL DEFAULT 0,
            config_used INT NOT NULL DEFAULT 0,
            price_per_gb INT NOT NULL DEFAULT 0,
            price_per_month INT NOT NULL DEFAULT 0,
            wallet INT NOT NULL DEFAULT 0,
            auto_disable_days INT NOT NULL DEFAULT 3,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            webhook_set TINYINT(1) NOT NULL DEFAULT 0,
            limited_panel TINYINT(1) NOT NULL DEFAULT 1,
            enforce_min_price TINYINT(1) NOT NULL DEFAULT 1,
            enforce_vol_cap_product TINYINT(1) NOT NULL DEFAULT 0,
            panel_vol_cap BIGINT NOT NULL DEFAULT 0,
            panel_vol_used BIGINT NOT NULL DEFAULT 0,
            panel_vol_last_sync INT NOT NULL DEFAULT 0,
            display_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
            expire_at INT NOT NULL DEFAULT 0,
            expire_warned TINYINT(1) NOT NULL DEFAULT 0,
            created_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_bot ✅<br>";
    } else {
        // ALTER برای نصب‌های قدیمی
        $bot_cols = [
            'bot_name'          => 'ALTER TABLE reseller_bot ADD bot_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT ""',
            'allowed_inbounds'  => 'ALTER TABLE reseller_bot ADD allowed_inbounds TEXT NULL',
            'config_limit'      => 'ALTER TABLE reseller_bot ADD config_limit INT NOT NULL DEFAULT 0',
            'config_used'       => 'ALTER TABLE reseller_bot ADD config_used INT NOT NULL DEFAULT 0',
            'price_per_month'   => 'ALTER TABLE reseller_bot ADD price_per_month INT NOT NULL DEFAULT 0',
            'wallet'            => 'ALTER TABLE reseller_bot ADD wallet INT NOT NULL DEFAULT 0',
            'auto_disable_days' => 'ALTER TABLE reseller_bot ADD auto_disable_days INT NOT NULL DEFAULT 3',
            'webhook_set'       => 'ALTER TABLE reseller_bot ADD webhook_set TINYINT(1) NOT NULL DEFAULT 0',
            'panel_id'          => 'ALTER TABLE reseller_bot ADD panel_id INT UNSIGNED NULL',
            'limited_panel'     => 'ALTER TABLE reseller_bot ADD limited_panel TINYINT(1) NOT NULL DEFAULT 1',
            'enforce_min_price'         => 'ALTER TABLE reseller_bot ADD enforce_min_price TINYINT(1) NOT NULL DEFAULT 1',
            'enforce_vol_cap_product'   => 'ALTER TABLE reseller_bot ADD enforce_vol_cap_product TINYINT(1) NOT NULL DEFAULT 0',
            'panel_vol_cap'             => 'ALTER TABLE reseller_bot ADD panel_vol_cap BIGINT NOT NULL DEFAULT 0',
            'panel_vol_used'            => 'ALTER TABLE reseller_bot ADD panel_vol_used BIGINT NOT NULL DEFAULT 0',
            'panel_vol_last_sync'       => 'ALTER TABLE reseller_bot ADD panel_vol_last_sync INT NOT NULL DEFAULT 0',
            'display_name'              => 'ALTER TABLE reseller_bot ADD display_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL',
            'expire_at'                 => 'ALTER TABLE reseller_bot ADD expire_at INT NOT NULL DEFAULT 0',
            'expire_warned'             => 'ALTER TABLE reseller_bot ADD expire_warned TINYINT(1) NOT NULL DEFAULT 0',
        ];
        foreach ($bot_cols as $col => $sql) {
            $chk = $connect->query("SHOW COLUMNS FROM reseller_bot LIKE '$col'");
            if ($chk->num_rows == 0) { $connect->query($sql); echo "reseller_bot.$col added ✅<br>"; }
        }
    }

    // جدول کاربران هر زیر ربات (جدا از کاربران ربات مادر)
    $result = $connect->query("SHOW TABLES LIKE 'child_bot_user'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE child_bot_user (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL,
            user_id VARCHAR(200) NOT NULL,
            username VARCHAR(200) NOT NULL DEFAULT '',
            first_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
            step VARCHAR(200) NOT NULL DEFAULT 'home',
            Processing_value TEXT NULL,
            Balance INT NOT NULL DEFAULT 0,
            User_Status VARCHAR(50) NOT NULL DEFAULT 'active',
            created_at INT NOT NULL DEFAULT 0,
            UNIQUE KEY unique_bot_user (bot_token, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        echo "table child_bot_user ✅<br>";
    }

    // جدول محصولات زیر ربات
    $result = $connect->query("SHOW TABLES LIKE 'child_bot_product'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE child_bot_product (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL,
            name VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            volume_gb INT NOT NULL,
            days INT NOT NULL,
            price INT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        echo "table child_bot_product ✅<br>";
    }

    // جدول فاکتور/کانفیگ‌های زیر ربات
    $result = $connect->query("SHOW TABLES LIKE 'child_bot_invoice'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE child_bot_invoice (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL,
            user_id VARCHAR(200) NOT NULL,
            username_config VARCHAR(200) NOT NULL,
            product_name VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            volume_gb INT NOT NULL DEFAULT 0,
            days INT NOT NULL DEFAULT 0,
            price INT NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at INT NOT NULL DEFAULT 0,
            expire_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table child_bot_invoice ✅<br>";
    }

    // جدول درخواست افزایش سقف زیر ربات به ربات مادر
    $result = $connect->query("SHOW TABLES LIKE 'child_bot_request'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE child_bot_request (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL,
            request_type VARCHAR(50) NOT NULL,
            amount INT NOT NULL DEFAULT 0,
            total_price INT NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at INT NOT NULL DEFAULT 0,
            reviewed_at INT NOT NULL DEFAULT 0,
            reviewed_by VARCHAR(200) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table child_bot_request ✅<br>";
    }

} catch (Exception $e) {
    file_put_contents('error_log', $e->getMessage());
}

//----------------------- [ Reseller ] --------------------- //
try {
    // جدول نمایندگان
    $result = $connect->query("SHOW TABLES LIKE 'reseller'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_user VARCHAR(200) NOT NULL UNIQUE,
            panel_name VARCHAR(200) NOT NULL,
            allowed_inbounds TEXT NULL,
            volume_limit BIGINT NOT NULL DEFAULT 0,
            volume_used BIGINT NOT NULL DEFAULT 0,
            config_limit INT NOT NULL DEFAULT 0,
            config_used INT NOT NULL DEFAULT 0,
            price_per_gb INT NOT NULL DEFAULT 0,
            price_per_month INT NOT NULL DEFAULT 0,
            wallet INT NOT NULL DEFAULT 0,
            auto_disable_days INT NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at INT NOT NULL DEFAULT 0,
            notes TEXT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller ✅<br>";
    }

    // جدول درخواست‌های حجم نماینده
    $result = $connect->query("SHOW TABLES LIKE 'reseller_request'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_request (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_user VARCHAR(200) NOT NULL,
            volume_gb INT NOT NULL DEFAULT 0,
            config_count INT NOT NULL DEFAULT 0,
            total_price INT NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at INT NOT NULL DEFAULT 0,
            reviewed_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_request ✅<br>";
    }

    // جدول محصولات نماینده (قیمت‌گذاری مستقل)
    $result = $connect->query("SHOW TABLES LIKE 'reseller_product'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_product (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_reseller VARCHAR(200) NOT NULL,
            name VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            volume_gb INT NOT NULL,
            days INT NOT NULL,
            price INT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_bin");
        echo "table reseller_product ✅<br>";
    }

    // جدول فاکتور/گزارش فروش نماینده
    $result = $connect->query("SHOW TABLES LIKE 'reseller_invoice'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_invoice (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            id_reseller VARCHAR(200) NOT NULL,
            username VARCHAR(200) NOT NULL,
            product_name VARCHAR(300) NOT NULL,
            volume_gb INT NOT NULL DEFAULT 0,
            days INT NOT NULL DEFAULT 0,
            price INT NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at INT NOT NULL DEFAULT 0,
            expire_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_invoice ✅<br>";
    }

    // ALTER برای نصب‌های قدیمی
    $reseller_cols = [
        'allowed_inbounds' => 'ALTER TABLE reseller ADD allowed_inbounds TEXT NULL',
        'config_limit'     => 'ALTER TABLE reseller ADD config_limit INT NOT NULL DEFAULT 0',
        'config_used'      => 'ALTER TABLE reseller ADD config_used INT NOT NULL DEFAULT 0',
        'price_per_month'  => 'ALTER TABLE reseller ADD price_per_month INT NOT NULL DEFAULT 0',
        'wallet'           => 'ALTER TABLE reseller ADD wallet INT NOT NULL DEFAULT 0',
        'auto_disable_days'=> 'ALTER TABLE reseller ADD auto_disable_days INT NOT NULL DEFAULT 0',
        'notes'            => 'ALTER TABLE reseller ADD notes TEXT NULL',
        // NEW — added for provisioning system
        'panel_name'       => "ALTER TABLE reseller ADD panel_name VARCHAR(200) NOT NULL DEFAULT ''",
        'price_per_gb'     => 'ALTER TABLE reseller ADD price_per_gb INT NOT NULL DEFAULT 0',
        'volume_used'      => 'ALTER TABLE reseller ADD volume_used BIGINT NOT NULL DEFAULT 0',
        'max_volume_gb'    => 'ALTER TABLE reseller ADD max_volume_gb BIGINT NOT NULL DEFAULT 0',
        'max_configs'      => 'ALTER TABLE reseller ADD max_configs INT NOT NULL DEFAULT 0',
        'current_configs'  => 'ALTER TABLE reseller ADD current_configs INT NOT NULL DEFAULT 0',
        'balance'          => 'ALTER TABLE reseller ADD balance BIGINT NOT NULL DEFAULT 0',
        'total_sold'       => 'ALTER TABLE reseller ADD total_sold INT NOT NULL DEFAULT 0',
        'bot_token'        => "ALTER TABLE reseller ADD bot_token VARCHAR(100) NOT NULL DEFAULT ''",
        'reseller_token'   => "ALTER TABLE reseller ADD reseller_token VARCHAR(64) NULL",
    ];
    foreach ($reseller_cols as $col => $sql) {
        $chk = $connect->query("SHOW COLUMNS FROM reseller LIKE '$col'");
        if ($chk->num_rows == 0) { $connect->query($sql); echo "reseller.$col added ✅<br>"; }
    }

    // تنظیمات نمایندگی در setting
    $cols = [
        'reseller_status' => 'off',
        'reseller_apply_text' => '',
        // NEW — global pricing for "کانفیگ نمایندگی" (volume/day based, admin-controlled, applies to ALL resellers)
        'reseller_cfg_price_per_gb'  => '0',
        'reseller_cfg_price_per_day' => '0',
        'reseller_cfg_min_gb'        => '1',
        'reseller_cfg_min_days'      => '1',
    ];
    foreach ($cols as $col => $def) {
        $chk = $connect->query("SHOW COLUMNS FROM setting LIKE '$col'");
        if ($chk->num_rows == 0) {
            $connect->query("ALTER TABLE setting ADD $col VARCHAR(500) DEFAULT '$def'");
            echo "setting.$col added ✅<br>";
        }
    }
    // Intro/description texts can be long — use TEXT, not VARCHAR(500)
    $text_cols = ['reseller_panel_intro_text', 'reseller_cfg_intro_text'];
    foreach ($text_cols as $col) {
        $chk = $connect->query("SHOW COLUMNS FROM setting LIKE '$col'");
        if ($chk->num_rows == 0) {
            $connect->query("ALTER TABLE setting ADD $col TEXT NULL");
            echo "setting.$col added ✅<br>";
        }
    }

    // جدول سفارش «کانفیگ نمایندگی» (حجم/روز آزاد، با نرخ سراسری + تایید مدیر)
    $result = $connect->query("SHOW TABLES LIKE 'reseller_cfg_order'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_cfg_order (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            order_id VARCHAR(100) NOT NULL UNIQUE,
            id_user VARCHAR(200) NOT NULL,
            volume_gb INT NOT NULL DEFAULT 0,
            days INT NOT NULL DEFAULT 0,
            price INT NOT NULL DEFAULT 0,
            approval_status VARCHAR(20) NOT NULL DEFAULT 'awaiting_approval',
            payment_method VARCHAR(50) NOT NULL DEFAULT '',
            payment_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            zp_authority VARCHAR(100) NOT NULL DEFAULT '',
            delivered TINYINT(1) NOT NULL DEFAULT 0,
            created_at INT NOT NULL DEFAULT 0,
            reviewed_at INT NOT NULL DEFAULT 0,
            reviewed_by VARCHAR(200) NOT NULL DEFAULT '',
            paid_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_cfg_order ✅<br>";
    }

} catch (Exception $e) {
    file_put_contents('error_log', $e->getMessage());
}
try {

    // جدول تایید/رد شخص برای «درخواست پنل نمایندگی» — قبل از انتخاب پلن
    $result = $connect->query("SHOW TABLES LIKE 'reseller_bot_approval'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_bot_approval (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(200) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at INT NOT NULL DEFAULT 0,
            reviewed_at INT NOT NULL DEFAULT 0,
            reviewed_by VARCHAR(200) NOT NULL DEFAULT '',
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_bot_approval ✅<br>";
    }

    // جدول پلن‌های فروش پنل نمایندگی (تعریف شده توسط ادمین)
    $result = $connect->query("SHOW TABLES LIKE 'reseller_bot_plan'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_bot_plan (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            volume_gb BIGINT NOT NULL DEFAULT 0,
            config_limit INT NOT NULL DEFAULT 0,
            duration_days INT NOT NULL DEFAULT 30,
            price INT NOT NULL DEFAULT 0,
            panel_name VARCHAR(200) NOT NULL DEFAULT '',
            allowed_inbounds TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "table reseller_bot_plan ✅<br>";
    }

    // جدول فاکتور خرید پنل نمایندگی (هر خرید پنل)
    $result = $connect->query("SHOW TABLES LIKE 'reseller_bot_invoice'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_bot_invoice (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            order_id VARCHAR(100) NOT NULL UNIQUE,
            buyer_id VARCHAR(200) NOT NULL,
            plan_id INT UNSIGNED NOT NULL,
            plan_name VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
            volume_gb BIGINT NOT NULL DEFAULT 0,
            config_limit INT NOT NULL DEFAULT 0,
            duration_days INT NOT NULL DEFAULT 30,
            price INT NOT NULL DEFAULT 0,
            panel_name VARCHAR(200) NOT NULL DEFAULT '',
            bot_token VARCHAR(100) NOT NULL DEFAULT '',
            bot_username VARCHAR(100) NOT NULL DEFAULT '',
            payment_method VARCHAR(50) NOT NULL DEFAULT '',
            payment_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            zp_authority VARCHAR(100) NOT NULL DEFAULT '',
            delivered TINYINT(1) NOT NULL DEFAULT 0,
            created_at INT NOT NULL DEFAULT 0,
            paid_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // ALTER for existing installations
        $inv_cols = [
            'zp_authority'     => "ALTER TABLE reseller_bot_invoice ADD zp_authority VARCHAR(100) NOT NULL DEFAULT ''",
            'paid_at'          => "ALTER TABLE reseller_bot_invoice ADD paid_at INT NOT NULL DEFAULT 0",
            // NEW — admin approval gate (must approve BEFORE payment methods are shown)
            'approval_status'  => "ALTER TABLE reseller_bot_invoice ADD approval_status VARCHAR(20) NOT NULL DEFAULT 'awaiting_approval'",
            'owner_numeric_id' => "ALTER TABLE reseller_bot_invoice ADD owner_numeric_id VARCHAR(100) NOT NULL DEFAULT ''",
            'reviewed_at'      => "ALTER TABLE reseller_bot_invoice ADD reviewed_at INT NOT NULL DEFAULT 0",
            'reviewed_by'      => "ALTER TABLE reseller_bot_invoice ADD reviewed_by VARCHAR(200) NOT NULL DEFAULT ''",
        ];
        foreach ($inv_cols as $col => $sql) {
            $chk = $connect->query("SHOW COLUMNS FROM reseller_bot_invoice LIKE '$col'");
            if ($chk && $chk->num_rows == 0) {
                $connect->query($sql);
                echo "reseller_bot_invoice.$col added ✅<br>";
            }
        }
        echo "table reseller_bot_invoice ✅<br>";
    } else {
        // Existing installs: make sure approval-gate columns exist too
        $inv_cols_existing = [
            'approval_status'  => "ALTER TABLE reseller_bot_invoice ADD approval_status VARCHAR(20) NOT NULL DEFAULT 'awaiting_approval'",
            'owner_numeric_id' => "ALTER TABLE reseller_bot_invoice ADD owner_numeric_id VARCHAR(100) NOT NULL DEFAULT ''",
            'reviewed_at'      => "ALTER TABLE reseller_bot_invoice ADD reviewed_at INT NOT NULL DEFAULT 0",
            'reviewed_by'      => "ALTER TABLE reseller_bot_invoice ADD reviewed_by VARCHAR(200) NOT NULL DEFAULT ''",
        ];
        foreach ($inv_cols_existing as $col => $sql) {
            $chk = $connect->query("SHOW COLUMNS FROM reseller_bot_invoice LIKE '$col'");
            if ($chk && $chk->num_rows == 0) {
                $connect->query($sql);
                echo "reseller_bot_invoice.$col added ✅<br>";
            }
        }
        // Back-fill: invoices that already reached a payment step are implicitly approved
        $connect->query("UPDATE reseller_bot_invoice SET approval_status='approved' WHERE approval_status='' OR approval_status IS NULL");
    }

    // تنظیمات فروش پنل در setting
    $bot_sale_cols = [
        'bot_sale_status'   => 'off',
        'bot_sale_card_num' => '',
        'bot_sale_card_name'=> '',
    ];
    foreach ($bot_sale_cols as $col => $def) {
        $chk = $connect->query("SHOW COLUMNS FROM setting LIKE '$col'");
        if ($chk->num_rows == 0) {
            $def_esc = $connect->real_escape_string($def);
            $connect->query("ALTER TABLE setting ADD $col VARCHAR(500) DEFAULT '$def_esc'");
            echo "setting.$col added ✅<br>";
        }
    }

} catch (Exception $e) {
    file_put_contents('error_log', $e->getMessage());
}

// فاز ۳ — آپدیت جداول
try {
    // آپدیت setting برای دکمه‌های ادمین فاز ۳
    $setting_cols = [
        'bot_sale_status'    => "VARCHAR(10) DEFAULT 'off'",
        'bot_sale_card_num'  => "VARCHAR(20) DEFAULT ''",
        'bot_sale_card_name' => "VARCHAR(100) DEFAULT ''",
    ];
    foreach ($setting_cols as $col => $def) {
        $chk = $connect->query("SHOW COLUMNS FROM setting LIKE '$col'");
        if ($chk && $chk->num_rows == 0) {
            $connect->query("ALTER TABLE setting ADD $col $def");
            echo "setting.$col added ✅<br>";
        }
    }

    // آپدیت child_bot_request - اضافه کردن reviewed_at اگه نبود
    $chk = $connect->query("SHOW COLUMNS FROM child_bot_request LIKE 'reviewed_at'");
    if ($chk && $chk->num_rows == 0) {
        $connect->query("ALTER TABLE child_bot_request ADD reviewed_at INT NOT NULL DEFAULT 0");
        echo "child_bot_request.reviewed_at added ✅<br>";
    }

    // آپدیت reseller_bot - اضافه کردن price_per_month اگه نبود
    $chk = $connect->query("SHOW COLUMNS FROM reseller_bot LIKE 'price_per_month'");
    if ($chk && $chk->num_rows == 0) {
        $connect->query("ALTER TABLE reseller_bot ADD price_per_month INT NOT NULL DEFAULT 0");
        echo "reseller_bot.price_per_month added ✅<br>";
    }
} catch (Exception $e) {
    file_put_contents('error_log', "[table phase3] " . $e->getMessage() . PHP_EOL, FILE_APPEND);
}

// جدول pool پنل‌های نمایندگی — ادمین از قبل پنل‌ها رو اضافه میکنه
try {
    $result = $connect->query("SHOW TABLES LIKE 'reseller_panel_pool'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_panel_pool (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name_panel VARCHAR(200) NOT NULL,
            description VARCHAR(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
            assigned_to VARCHAR(200) DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'available',
            created_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='available|assigned|disabled'");
        echo 'table reseller_panel_pool ✅<br>';
    }

    // آپدیت reseller_bot - اضافه کردن panel_pool_id
    $chk = $connect->query("SHOW COLUMNS FROM reseller_bot LIKE 'panel_pool_id'");
    if ($chk && $chk->num_rows == 0) {
        $connect->query("ALTER TABLE reseller_bot ADD panel_pool_id INT UNSIGNED NULL");
        echo 'reseller_bot.panel_pool_id added ✅<br>';
    }

    // آپدیت reseller_bot_plan - اضافه کردن auto_assign_panel
    $chk = $connect->query("SHOW COLUMNS FROM reseller_bot_plan LIKE 'auto_assign_panel'");
    if ($chk && $chk->num_rows == 0) {
        $connect->query("ALTER TABLE reseller_bot_plan ADD auto_assign_panel TINYINT(1) NOT NULL DEFAULT 0");
        echo 'reseller_bot_plan.auto_assign_panel added ✅<br>';
    }
} catch (Exception $e) {
    file_put_contents('error_log', "[panel_pool] " . $e->getMessage() . PHP_EOL, FILE_APPEND);
}

// جدول pool توکن‌های زیر ربات — ادمین از قبل ربات‌های BotFather را اضافه می‌کند
// تا هنگام خرید «پنل نمایندگی»، توکن + آیدی عددی مدیر به‌صورت کاملاً خودکار
// (بدون نیاز به وارد کردن توکن توسط خریدار) به سفارش متصل شود.
try {
    $result = $connect->query("SHOW TABLES LIKE 'reseller_bot_token_pool'");
    if ($result->num_rows == 0) {
        $connect->query("CREATE TABLE reseller_bot_token_pool (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            bot_token VARCHAR(100) NOT NULL UNIQUE,
            bot_username VARCHAR(200) NOT NULL DEFAULT '',
            bot_name VARCHAR(200) NOT NULL DEFAULT '',
            owner_admin_id VARCHAR(100) NOT NULL DEFAULT '',
            assigned_to VARCHAR(200) DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'available',
            created_at INT NOT NULL DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='available|assigned|disabled'");
        echo 'table reseller_bot_token_pool ✅<br>';
    }
} catch (Exception $e) {
    file_put_contents('error_log', "[bot_token_pool] " . $e->getMessage() . PHP_EOL, FILE_APPEND);
}

