<?php
// child_bot.php
// webhook handler مشترک برای همه زیر ربات‌ها
// URL: https://domain.com/bot/child_bot.php?token=BOT_TOKEN_HERE

// ----------------------------------------------------------------
// بارگذاری فایل‌های اصلی
// ----------------------------------------------------------------
require_once 'config.php';
require_once 'functions.php';
require_once 'panels.php';
require_once 'remnawave.php';
require_once 'child_botapi.php';
require_once 'jdf.php';

// ----------------------------------------------------------------
// تشخیص توکن زیر ربات از URL
// ----------------------------------------------------------------
$bot_token = $_GET['token'] ?? '';
if (empty($bot_token)) {
    http_response_code(403);
    die('No token');
}

// بررسی وجود ستون display_name (برای نصب‌های قدیمی که هنوز migrate نشدن)
try {
    $col_chk = $pdo->query("SHOW COLUMNS FROM reseller_bot LIKE 'display_name'");
    if ($col_chk && $col_chk->rowCount() === 0) {
        $pdo->exec("ALTER TABLE reseller_bot ADD display_name VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL");
    }
} catch (Exception $e) { /* اگه ستون از قبل بود یا دسترسی نبود، نادیده بگیر */ }

// بررسی وجود زیر ربات در دیتابیس
$bot_info = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token = ?");
$bot_info->execute([$bot_token]);
$bot_info = $bot_info->fetch(PDO::FETCH_ASSOC);

if (!$bot_info || $bot_info['status'] === 'deleted') {
    http_response_code(403);
    die('Bot not found or deleted');
}

// بلاک بودن = هیچ چیزی پردازش نمیشه
if ($bot_info['status'] === 'blocked') {
    die('Bot is blocked');
}

// ----------------------------------------------------------------
// پارس کردن آپدیت تلگرام
// ----------------------------------------------------------------
$update = json_decode(file_get_contents("php://input"), true);
if (!$update) die('No update');

$from_id         = $update['message']['from']['id']                            ?? $update['callback_query']['from']['id']                            ?? 0;
$text            = $update['message']['text']                                  ?? '';
$message_id      = $update['message']['message_id']                            ?? $update['callback_query']['message']['message_id']                  ?? 0;
$datain          = $update['callback_query']['data']                           ?? '';
$username        = $update['message']['from']['username']                      ?? $update['callback_query']['from']['username']                       ?? '';
$first_name      = $update['message']['from']['first_name']                    ?? $update['callback_query']['from']['first_name']                     ?? '';
$callback_query_id = $update['callback_query']['id']                           ?? 0;

if (!$from_id) die('No from_id');

// ----------------------------------------------------------------
// ثبت/آپدیت کاربر در child_bot_user
// ----------------------------------------------------------------
$user = $pdo->prepare("SELECT * FROM child_bot_user WHERE bot_token = ? AND user_id = ?");
$user->execute([$bot_token, $from_id]);
$user = $user->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $pdo->prepare("INSERT INTO child_bot_user (bot_token, user_id, username, first_name, step, Processing_value, Balance, User_Status, created_at) VALUES (?, ?, ?, ?, 'home', '', 0, 'active', ?)")
        ->execute([$bot_token, $from_id, $username, $first_name, time()]);
    $user = $pdo->prepare("SELECT * FROM child_bot_user WHERE bot_token = ? AND user_id = ?");
    $user->execute([$bot_token, $from_id]);
    $user = $user->fetch(PDO::FETCH_ASSOC);
} else {
    // آپدیت username اگه عوض شده
    if ($user['username'] !== $username || $user['first_name'] !== $first_name) {
        $pdo->prepare("UPDATE child_bot_user SET username=?, first_name=? WHERE bot_token=? AND user_id=?")
            ->execute([$username, $first_name, $bot_token, $from_id]);
    }
}

// تابع کمکی: ارسال پیام به ادمین‌های ربات مادر
function notify_mother_admins($text, $keyboard = null) {
    global $pdo, $APIKEY;
    $admins = $pdo->query("SELECT id_admin FROM admin WHERE role='super'")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($admins as $aid) {
        $params = ['chat_id' => $aid, 'text' => $text, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true];
        if ($keyboard) $params['reply_markup'] = $keyboard;
        $url = "https://api.telegram.org/bot{$APIKEY}/sendMessage";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_exec($ch); curl_close($ch);
    }
}

// تابع کمکی: آپدیت step
function child_step($bot_token, $user_id, $step) {
    global $pdo;
    $pdo->prepare("UPDATE child_bot_user SET step=? WHERE bot_token=? AND user_id=?")
        ->execute([$step, $bot_token, $user_id]);
}

// تابع کمکی: ذخیره Processing_value
function child_save_pv($bot_token, $user_id, $value) {
    global $pdo;
    $pdo->prepare("UPDATE child_bot_user SET Processing_value=? WHERE bot_token=? AND user_id=?")
        ->execute([$value, $bot_token, $user_id]);
}

// تابع کمکی: format گیگ
function child_fmt_gb($gb) {
    return $gb >= 1024 ? round($gb/1024,2).' TB' : $gb.' GB';
}

// تابع کمکی: decode کردن squad UUIDs
// فرمت: main_squad_uuid|test_squad_uuid
function child_decode_squad_selection($raw) {
    if (!$raw || $raw === '[]') {
        return ['main' => '', 'test' => ''];
    }
    $parts = explode('|', $raw);
    return [
        'main' => $parts[0] ?? '',
        'test' => $parts[1] ?? '',
    ];
}

// تابع کمکی: خواندن Processing_value از child_bot_user
function child_get_pv($bot_token, $user_id) {
    global $pdo;
    $result = $pdo->prepare("SELECT Processing_value FROM child_bot_user WHERE bot_token=? AND user_id=?");
    $result->execute([$bot_token, $user_id]);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    return $row['Processing_value'] ?? '{}';
}

// ================================================================
// چک لحظه‌ای مصرف واقعی پنل قبل از ساخت کانفیگ جدید
// (مستقل از کرون sync — همون لحظه از پنل می‌پرسه)
//
// خروجی:
//   ['ok' => true]                                  → مجاز به ساخت
//   ['ok' => false, 'msg' => '...']                 → ممنوع (سقف پر/خطا)
// ================================================================
function child_check_panel_volume_live($ManagePanel, $bot_token, $panel_name, $cap_gb, $extra_gb = 0) {
    global $pdo;

    // اگه سقفی تعریف نشده، محدودیتی نیست
    $cap_gb = (float)$cap_gb;
    if ($cap_gb <= 0) {
        return ['ok' => true];
    }

    $bw = $ManagePanel->GetPanelBandwidth($panel_name);
    if (!empty($bw['error'])) {
        // اگه نتونستیم از پنل بپرسیم، برای جلوگیری از مسدود شدن کامل فروش،
        // بر اساس آخرین مقدار sync‌شده (کرون) تصمیم می‌گیریم — نه باز کردن کامل.
        error_log("[child_check_panel_volume_live] GetPanelBandwidth error for {$panel_name}: " . ($bw['error'] ?? ''));
        $bi = $pdo->prepare("SELECT panel_vol_used FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $last_used = (float)($bi->fetchColumn() ?: 0);
        if (($last_used + $extra_gb) > $cap_gb) {
            return ['ok' => false, 'msg' => '⚠️ امکان بررسی لحظه‌ای مصرف پنل نبود و طبق آخرین وضعیت ثبت‌شده، ظرفیت تکمیل است.'];
        }
        return ['ok' => true];
    }

    $total_gb = $bw['total_gb'] ?? round(($bw['total_bytes'] ?? 0) / 1073741824, 3);

    // مقدار تازه رو همینجا در DB هم به‌روز می‌کنیم تا کرون و نمایش‌ها هم همگام بمونن
    $pdo->prepare("UPDATE reseller_bot SET panel_vol_used=?, panel_vol_last_sync=? WHERE bot_token=?")
        ->execute([$total_gb, time(), $bot_token]);

    if (($total_gb + $extra_gb) > $cap_gb) {
        $remain = max(0, $cap_gb - $total_gb);
        return [
            'ok'  => false,
            'msg' => "⛔ سقف مصرف واقعی پنل پر است.\n📊 مصرف فعلی: " . number_format($total_gb, 2) . " GB از " . number_format($cap_gb, 2) . " GB\n🔋 باقیمانده: " . number_format($remain, 2) . " GB",
        ];
    }

    return ['ok' => true];
}

function child_is_allowed_owner_callback($datain) {
    if ($datain === 'cp_close' || $datain === 'cp_cancel' || $datain === 'cp_prod_add') {
        return true;
    }
    if (preg_match('/^cp_prod_(toggle|del)_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cp_build_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cp_cfg_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cp_cfg_(en|dis|renew|del)_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cp_vol_pay_(\d+)_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cp_cfg_req_(\d+)$/', $datain)) {
        return true;
    }
    if (preg_match('/^cb_child_squad_main_/', $datain)) {
        return true;
    }
    if (preg_match('/^cb_child_squad_test_/', $datain)) {
        return true;
    }
    if ($datain === 'cb_owner_back_panel' || $datain === 'cb_owner_noop') {
        return true;
    }
    if ($datain === 'ontestshowpanel' || $datain === 'offtestshowpanel') {
        return true;
    }
    return false;
}

// OwnerID این زیر ربات
$owner_id = $bot_info['owner_id'];
$is_owner = ($from_id == $owner_id);
// نسخه محدود: اگه limited_panel=0 باشه، همه منوها باز هستن
$is_limited_panel = (int)($bot_info['limited_panel'] ?? 1);


// ManagePanel یک بار ساخته میشه
$ManagePanel = new ManagePanel();

// ----------------------------------------------------------------
// کیبوردها
// ----------------------------------------------------------------
$kb_main_user = json_encode(['keyboard' => [
    [['text' => '🛒 خرید اشتراک'], ['text' => '📋 سرویس‌های من']],
    [['text' => '💰 موجودی کیف پول'], ['text' => '📞 پشتیبانی']],
], 'resize_keyboard' => true]);

$kb_main_owner = json_encode(['keyboard' => [
    [['text' => '📦 محصولات'], ['text' => '⚙️ مدیریت کانفیگ']],
    [['text' => '📋 سفارش‌ها'], ['text' => '👥 مشتریان']],
    [['text' => '📊 آمار و گزارش'], ['text' => '🔧 مدیریت پنل']],
    [['text' => '💰 کیف پول']],
], 'resize_keyboard' => true]);

$kb_owner_config = json_encode(['keyboard' => [
    [['text' => '⚙️ ساخت کانفیگ'], ['text' => '👥 کانفیگ‌های ساخته شده']],
    [['text' => '📈 درخواست افزایش سقف']],
    [['text' => '🔙 بازگشت']],
], 'resize_keyboard' => true]);

$kb_owner_panel = json_encode(['keyboard' => [
    [['text' => '🟢 وضعیت نمایش پنل'], ['text' => '🔌 وضعیت اتصال پنل']],
    [['text' => '🧪 وضعیت اکانت تست'], ['text' => '⚙️ تنظیم پروتوکول و اینباند']],
    [['text' => '✏️ نام پنل'], ['text' => '🔤 روش ساخت نام کاربری']],
    [['text' => '📤 ارسال کانفیگ'], ['text' => '🔗 ارسال لینک سابسکرایبشن']],
    [['text' => '🔙 بازگشت']],
], 'resize_keyboard' => true]);

$kb_back = json_encode(['keyboard' => [[['text' => '🔙 بازگشت']]], 'resize_keyboard' => true]);

$my_keyboard = $is_owner ? $kb_main_owner : $kb_main_user;

// ----------------------------------------------------------------
// /start
// ----------------------------------------------------------------
if ($text === '/start') {
    // بارگذاری مجدد وضعیت ربات از DB (برای اطمینان از دریافت آخرین وضعیت)
    $fresh_bot = $pdo->prepare("SELECT status, panel_name FROM reseller_bot WHERE bot_token = ?");
    $fresh_bot->execute([$bot_token]);
    $fresh_bot = $fresh_bot->fetch(PDO::FETCH_ASSOC);
    if ($fresh_bot) {
        $bot_info['status']     = $fresh_bot['status'];
        $bot_info['panel_name'] = $fresh_bot['panel_name'];
    }
    if ($bot_info['status'] === 'pending') {
        child_sendmessage($bot_token, $from_id, "⏳ این ربات هنوز فعال نشده.\nپس از تایید مدیر، دوباره /start را بزنید.", null, 'HTML');
        die();
    }
    $welcome = $is_owner
        ? "🤝 خوش آمدید، <b>{$first_name}</b>!\n\nشما به عنوان <b>مدیر</b> این ربات وارد شده‌اید.\nاز منوی زیر استفاده کنید:"
        : "👋 خوش آمدید به <b>{$bot_info['bot_name']}</b>!\n\nبرای خرید اشتراک از منوی زیر استفاده کنید:";
    child_sendmessage($bot_token, $from_id, $welcome, $my_keyboard, 'HTML');
    child_step($bot_token, $from_id, 'home');
    die();
}

// ----------------------------------------------------------------
// بازگشت
// ----------------------------------------------------------------
if ($text === '🔙 بازگشت') {
    child_sendmessage($bot_token, $from_id, "🏠 منوی اصلی:", $my_keyboard, 'HTML');
    child_step($bot_token, $from_id, 'home');
    die();
}

// ================================================================
// بخش OWNER (نماینده = مدیر زیر ربات)
// ================================================================
if ($is_owner) {
    $owner_allowed_texts = [
        '📦 محصولات', '📦 مدیریت محصولات',
        '⚙️ مدیریت کانفیگ', '⚙️ ساخت کانفیگ', '👥 کانفیگ‌های ساخته شده',
        '📋 سفارش‌ها', '👥 مشتریان',
        '📊 آمار و گزارش', '🔧 مدیریت پنل',
        '📈 درخواست افزایش سقف', '📦 درخواست حجم', '🔢 درخواست کانفیگ',
        '💰 کیف پول', '➕ افزودن محصول', '🔙 بازگشت',
        // زیرمنوی «🔧 مدیریت پنل» — این آیتم‌ها قبلاً اینجا نبودن و باعث می‌شد
        // با وجود فعال بودن دکمه مادر، خود گزینه‌ها در حالت limited_panel بلاک بشن
        '🟢 وضعیت نمایش پنل', '🔌 وضعیت اتصال پنل', '🧪 وضعیت اکانت تست',
        '⚙️ تنظیم پروتوکول و اینباند', '✏️ نام پنل', '🔤 روش ساخت نام کاربری',
        '📤 ارسال کانفیگ', '🔗 ارسال لینک سابسکرایبشن', '🔔 ارسال پیام همگانی',
    ];
    $active_owner_step = $user['step'] ?? '';
    $owner_step_is_allowed = in_array($active_owner_step, ['cp_add_prod_name', 'cp_add_prod_gb', 'cp_add_prod_days', 'cp_add_prod_price', 'cp_req_gb', 'cp_req_cfg', 'cp_edit_displayname'], true);

    if ($is_limited_panel && $text !== '' && $text !== '/start' && !in_array($text, $owner_allowed_texts, true) && !$owner_step_is_allowed) {
        child_sendmessage($bot_token, $from_id, "⚠️ این بخش در نسخه محدود در دسترس نیست.", $kb_main_owner, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    if ($text === '📦 محصولات' || $text === '📦 مدیریت محصولات') {
        $products = $pdo->prepare("SELECT * FROM child_bot_product WHERE bot_token=? ORDER BY id");
        $products->execute([$bot_token]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);

        $add_btn = json_encode(['keyboard' => [
            [['text' => '➕ افزودن محصول']],
            [['text' => '🔙 بازگشت']],
        ], 'resize_keyboard' => true]);

        if (empty($products)) {
            child_sendmessage($bot_token, $from_id, "📦 هیچ محصولی تعریف نشده.\nاز دکمه ➕ افزودن محصول استفاده کنید.", $add_btn, 'HTML');
        } else {
            $msg = "📦 <b>محصولات شما:</b>\n\n";
            $btns = [];
            foreach ($products as $p) {
                $st = $p['status'] === 'active' ? '✅' : '⏸';
                $msg .= "{$st} <b>{$p['name']}</b> — {$p['volume_gb']} GB / {$p['days']} روز — " . number_format($p['price']) . " تومان\n";
                $btns[] = [
                    ['text' => "{$st} {$p['name']}", 'callback_data' => "cp_prod_info_{$p['id']}"],
                    ['text' => ($p['status']==='active'?'⏸':'✅'), 'callback_data' => "cp_prod_toggle_{$p['id']}"],
                    ['text' => '🗑', 'callback_data' => "cp_prod_del_{$p['id']}"],
                ];
            }
            $btns[] = [['text' => '➕ افزودن محصول', 'callback_data' => 'cp_prod_add']];
            child_sendmessage($bot_token, $from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
        }
        die();
    }

    if ($text === '⚙️ مدیریت کانفیگ') {
        child_sendmessage($bot_token, $from_id, "⚙️ <b>مدیریت کانفیگ</b>\n\nاز گزینه‌های زیر استفاده کنید:", $kb_owner_config, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    if ($text === '📋 سفارش‌ها') {
        $configs = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE bot_token=? ORDER BY created_at DESC LIMIT 30");
        $configs->execute([$bot_token]);
        $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($configs)) {
            child_sendmessage($bot_token, $from_id, "📋 هیچ سفارش یا کانفیگی ثبت نشده.", $kb_main_owner, 'HTML'); die();
        }
        $btns = [];
        foreach ($configs as $c) {
            $exp = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
            $icons = ['active'=>'✅','disabled'=>'🔴','expired'=>'⏰','removed'=>'🗑'];
            $icon = $icons[$c['status']] ?? '❓';
            $btns[] = [['text' => "{$icon} {$c['username_config']} | {$exp}", 'callback_data' => "cp_cfg_{$c['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "📋 <b>سفارش‌ها و کانفیگ‌ها:</b>", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    if ($text === '👥 مشتریان') {
        $customers = $pdo->prepare("SELECT DISTINCT user_id FROM child_bot_invoice WHERE bot_token=? AND user_id>0 ORDER BY user_id");
        $customers->execute([$bot_token]);
        $customers = $customers->fetchAll(PDO::FETCH_ASSOC);
        if (empty($customers)) {
            child_sendmessage($bot_token, $from_id, "👥 مشتری‌ای ثبت نشده.", $kb_main_owner, 'HTML'); die();
        }
        $msg = "👥 <b>مشتریان:</b>\n\n";
        foreach ($customers as $c) {
            $msg .= "• <code>{$c['user_id']}</code>\n";
        }
        child_sendmessage($bot_token, $from_id, $msg, $kb_main_owner, 'HTML');
        die();
    }

    if ($text === '🔧 مدیریت پنل') {
        $remain_gb = max(0, $bot_info['volume_limit'] - $bot_info['volume_used']);
        $remain_cfg = $bot_info['config_limit'] > 0 ? max(0, $bot_info['config_limit'] - $bot_info['config_used']) : 'نامحدود';
        $msg = "🔧 <b>مدیریت پنل</b>\n\n"
            . "🌐 پنل: <b>{$bot_info['panel_name']}</b>\n"
            . "🔋 حجم باقی: <b>" . child_fmt_gb($remain_gb) . "</b>\n"
            . "🔢 کانفیگ باقی: <b>{$remain_cfg}</b>";
        child_sendmessage($bot_token, $from_id, $msg, $kb_owner_panel, 'HTML');
        die();
    }

    // ---- مدیریت پنل: وضعیت نمایش پنل ----
    if ($text === '🟢 وضعیت نمایش پنل') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_sendmessage($bot_token, $from_id, "❌ پنل تنظیم نشده.", $kb_owner_panel, 'HTML'); die(); }
        $status = $panel['status'] ?? '—';
        $msg = "🟢 <b>وضعیت نمایش پنل</b>\n\n" .
               "📌 نام پنل: <b>{$panel['name_panel']}</b>\n" .
               "📡 وضعیت پنل: <b>{$status}</b>\n" .
               "🧪 نمایش اکانت تست: <b>" . ($panel['statusTest'] ?? '—') . "</b>";
        child_sendmessage($bot_token, $from_id, $msg, $kb_owner_panel, 'HTML');
        die();
    }

    // ---- مدیریت پنل: وضعیت اتصال پنل (ping URL) ----
    if ($text === '🔌 وضعیت اتصال پنل') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_sendmessage($bot_token, $from_id, "❌ پنل تنظیم نشده.", $kb_owner_panel, 'HTML'); die(); }
        $url = $panel['url_panel'] ?? '';
        $ok = false; $code = 0; $err = '';
        if ($url) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $err = curl_error($ch);
            curl_close($ch);
            $ok = $code >= 200 && $code < 400;
        }
        $msg = "🔌 <b>وضعیت اتصال پنل</b>\n\n" .
               " اتصال: <b>" . ($ok ? 'متصل' : 'ناموفق') . "</b>";
        if (!$ok) $msg .= "\n⚠️ HTTP: {$code} {$err}";
        child_sendmessage($bot_token, $from_id, $msg, $kb_owner_panel, 'HTML');
        die();
    }

    // ---- مدیریت پنل: وضعیت اکانت تست (فعال/غیرفعال) ----
    if ($text === '🧪 وضعیت اکانت تست') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_sendmessage($bot_token, $from_id, "❌ پنل تنظیم نشده.", $kb_owner_panel, 'HTML'); die(); }
        $test = $panel['statusTest'] ?? 'offtestshowpanel';
        $btn_text = $test === 'ontestshowpanel' ? '🟢 فعال (برای غیرفعال کردن بزن)' : '🔴 غیرفعال (برای فعال کردن بزن)';
        $msg = "🧪 <b>وضعیت اکانت تست</b>\n\n" . "📌 پنل: <b>{$panel['name_panel']}</b>\n\nبرای تغییر وضعیت روی دکمه زیر بزن:";
        child_sendmessage($bot_token, $from_id, $msg, json_encode(['inline_keyboard' => [
            [['text' => $btn_text, 'callback_data' => $test]],
        ]]), 'HTML');
        die();
    }

    // ---- مدیریت پنل: تنظیم اسکوادها (اصلی و تست) ----
    if ($text === '⚙️ تنظیم پروتوکول و اینباند') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_sendmessage($bot_token, $from_id, "❌ پنل تنظیم نشده.", $kb_owner_panel, 'HTML'); die(); }
        
        // فقط برای remnawave
        if (($panel['type'] ?? '') !== 'remnawave') {
            child_sendmessage($bot_token, $from_id, "⚠️ انتخاب اسکواد فقط برای پنل‌های remnawave در دسترس است.", $kb_owner_panel, 'HTML');
            die();
        }
        
        // دریافت لیست اسکوادها از API
        $squads = get_squads_remna($panel['name_panel']);
        if (!isset($squads['internalSquads']) || !is_array($squads['internalSquads'])) {
            child_sendmessage($bot_token, $from_id, "❌ خطا در دریافت اسکوادها: " . json_encode($squads), $kb_owner_panel, 'HTML');
            die();
        }
        
        // ذخیره لیست اسکوادها برای استفاده در مراحل بعدی (دقیقا مثل ربات اصلی)
        $squad_list = [];
        foreach ($squads['internalSquads'] as $sq) {
            $squad_list[] = ['uuid' => $sq['uuid'], 'name' => $sq['name']];
        }
        // ذخیره داده‌ها برای بازیابی در مراحل بعدی
        $pv_data = json_decode(child_get_pv($bot_token, $from_id), true) ?? [];
        $pv_data['child_remna_squads'] = $squad_list;
        $pv_data['child_remna_panel_name'] = $panel['name_panel'];
        child_save_pv($bot_token, $from_id, json_encode($pv_data));
        
        // نمایش لیست اسکوادهای اصلی (خریدی)
        $buttons = [];
        foreach ($squad_list as $sq) {
            $buttons[] = [['text' => "🔵 {$sq['name']}", 
                          'callback_data' => "cb_child_squad_main_" . $sq['uuid']]];
        }
        $buttons[] = [['text' => '🔙 بازگشت', 'callback_data' => 'cb_owner_back_panel']];
        
        $msg = "🔵 <b>اسکواد اصلی (خریدی)</b> رو انتخاب کن:\n\nکاربران خریدار به این اسکواد وصل میشن";
        $msg_response = child_sendmessage($bot_token, $from_id, $msg, json_encode(['inline_keyboard' => $buttons]), 'HTML');
        child_step($bot_token, $from_id, 'child_select_main_squad');
        // ذخیره message_id برای حذف بعدی
        $pv_data['child_squad_msg_id'] = $msg_response['result']['message_id'] ?? $message_id;
        child_save_pv($bot_token, $from_id, json_encode($pv_data));
        die();
    }

    // ---- مدیریت پنل: نام نمایشی (مخصوص همین زیر ربات، مستقل از نام واقعی پنل) ----
    if ($text === '✏️ نام پنل') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_sendmessage($bot_token, $from_id, "❌ پنل تنظیم نشده.", $kb_owner_panel, 'HTML'); die(); }
        $display = $bot_info['display_name'] ?: $panel['name_panel'];
        $msg = "✏️ <b>نام نمایشی فعلی:</b> <code>{$display}</code>\n\n"
             . "این همون نامیه که توی پیام تحویل کانفیگ و لیست سرویس‌ها به مشتری نشون داده میشه.\n"
             . "⚠️ توجه: این نام فقط مخصوص این ربات هست و تغییرش روی پنل اصلی یا ربات‌های دیگه‌ای که از همین پنل استفاده می‌کنن اثر نمی‌ذاره.\n\n"
             . "برای تغییر، نام جدید رو ارسال کن:";
        child_sendmessage($bot_token, $from_id, $msg, $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_edit_displayname');
        die();
    }

    if ($user['step'] === 'cp_edit_displayname') {
        if (mb_strlen($text) < 2 || mb_strlen($text) > 60) {
            child_sendmessage($bot_token, $from_id, "❌ نام باید ۲ تا ۶۰ کاراکتر باشد.", $kb_back, 'HTML'); die();
        }
        $pdo->prepare("UPDATE reseller_bot SET display_name=? WHERE bot_token=?")->execute([$text, $bot_token]);
        child_sendmessage($bot_token, $from_id, "✅ نام نمایشی به «{$text}» تغییر کرد.", $kb_owner_panel, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    // ---- مدیریت پنل: روش ساخت نام کاربری ----
    if ($text === '🔤 روش ساخت نام کاربری') {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        $method = $panel['MethodUsername'] ?? ($panel['configManual'] ?? '—');
        child_sendmessage($bot_token, $from_id, "🔤 <b>روش ساخت نام کاربری:</b>\n\n<code>" . ($method ?: '—') . "</code>", $kb_owner_panel, 'HTML');
        die();
    }

    // ---- ارسال کانفیگ / نمایش کانفیگ‌ها (مثل منوی کانفیگ‌ها) ----
    if ($text === '📤 ارسال کانفیگ' || $text === '🔗 ارسال لینک سابسکرایبشن') {
        // reuse existing handlers: show configs list
        $configs = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE bot_token=? ORDER BY created_at DESC LIMIT 20");
        $configs->execute([$bot_token]);
        $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($configs)) { child_sendmessage($bot_token, $from_id, "📋 هیچ کانفیگی ساخته نشده.", $kb_owner_panel, 'HTML'); die(); }
        $btns = [];
        foreach ($configs as $c) {
            $exp = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
            $btns[] = [['text' => "{$c['username_config']} | {$exp}", 'callback_data' => "cp_cfg_{$c['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "📤 <b>کانفیگ‌های ساخته شده:</b>", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    // ---- آمار و گزارش ----
    if ($text === '📊 آمار و گزارش') {
        $total_cfgs  = $pdo->prepare("SELECT COUNT(*) FROM child_bot_invoice WHERE bot_token=?"); $total_cfgs->execute([$bot_token]); $total_cfgs=$total_cfgs->fetchColumn();
        $active_cfgs = $pdo->prepare("SELECT COUNT(*) FROM child_bot_invoice WHERE bot_token=? AND status='active'"); $active_cfgs->execute([$bot_token]); $active_cfgs=$active_cfgs->fetchColumn();
        $total_users = $pdo->prepare("SELECT COUNT(*) FROM child_bot_user WHERE bot_token=?"); $total_users->execute([$bot_token]); $total_users=$total_users->fetchColumn();
        $total_income= $pdo->prepare("SELECT SUM(price) FROM child_bot_invoice WHERE bot_token=?"); $total_income->execute([$bot_token]); $total_income=$total_income->fetchColumn()??0;

        $remain_gb   = max(0, $bot_info['volume_limit'] - $bot_info['volume_used']);
        $remain_cfg  = $bot_info['config_limit'] > 0 ? max(0, $bot_info['config_limit'] - $bot_info['config_used']) : 'نامحدود';

        $msg  = "📊 <b>آمار ربات " . htmlspecialchars($bot_info['bot_name']) . "</b>\n\n";
        $msg .= "👥 کل کاربران: <b>{$total_users}</b>\n";
        $msg .= "📦 کل کانفیگ: <b>{$total_cfgs}</b> | ✅ فعال: <b>{$active_cfgs}</b>\n";
        $msg .= "💰 درآمد کل: <b>" . number_format($total_income) . " تومان</b>\n\n";
        $msg .= "━━━━━━━━━━━━━━\n";
        $msg .= "🔋 حجم باقی: <b>" . child_fmt_gb($remain_gb) . "</b> از <b>" . child_fmt_gb($bot_info['volume_limit']) . "</b>\n";
        $msg .= "🔢 کانفیگ باقی: <b>{$remain_cfg}</b>\n";
        $msg .= "💳 کیف پول: <b>" . number_format($bot_info['wallet']) . " تومان</b>\n";
        $msg .= "📌 پنل: <b>{$bot_info['panel_name']}</b>\n";
        $msg .= "⏰ Grace period: <b>{$bot_info['auto_disable_days']} روز</b>";

        // نمایش سقف مصرف پنل
        $pvc_cap_s  = $bot_info['panel_vol_cap']  ?? 0;
        $pvc_used_s = $bot_info['panel_vol_used'] ?? 0;
        $pvc_sync_s = $bot_info['panel_vol_last_sync'] ?? 0;
        if ($pvc_cap_s > 0) {
            $pvc_pct_s   = round(($pvc_used_s / $pvc_cap_s) * 100, 1);
            $pvc_remain_s = max(0, $pvc_cap_s - $pvc_used_s);
            $msg .= "\n\n📊 <b>مصرف واقعی پنل:</b>\n"
                  . "   مصرف: <b>" . number_format($pvc_used_s, 2) . " GB</b> از <b>" . number_format($pvc_cap_s, 2) . " GB</b> ({$pvc_pct_s}%)\n"
                  . "   باقیمانده: <b>" . number_format($pvc_remain_s, 2) . " GB</b>\n"
                  . "   آخرین بروزرسانی: " . ($pvc_sync_s ? jdate('Y/m/d H:i', $pvc_sync_s) : '—');
        }

        child_sendmessage($bot_token, $from_id, $msg, $kb_main_owner, 'HTML');
        die();
    }

    // ---- کیف پول ----
    if ($text === '💰 کیف پول') {
        $msg = "💰 <b>کیف پول</b>\n\nموجودی: <b>" . number_format($bot_info['wallet']) . " تومان</b>\n\nبرای شارژ کیف پول با ادمین اصلی تماس بگیرید یا از طریق ربات مادر اقدام کنید.";
        child_sendmessage($bot_token, $from_id, $msg, $kb_main_owner, 'HTML');
        die();
    }

    // ================================================================
    // ---- مدیریت محصولات ----
    // ================================================================
    if ($text === '📦 مدیریت محصولات') {
        $products = $pdo->prepare("SELECT * FROM child_bot_product WHERE bot_token=? ORDER BY id");
        $products->execute([$bot_token]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);

        $add_btn = json_encode(['keyboard' => [
            [['text' => '➕ افزودن محصول']],
            [['text' => '🔙 بازگشت']],
        ], 'resize_keyboard' => true]);

        if (empty($products)) {
            child_sendmessage($bot_token, $from_id, "📦 هیچ محصولی تعریف نشده.\nاز دکمه ➕ افزودن محصول استفاده کنید.", $add_btn, 'HTML');
        } else {
            $msg = "📦 <b>محصولات شما:</b>\n\n";
            $btns = [];
            foreach ($products as $p) {
                $st = $p['status'] === 'active' ? '✅' : '⏸';
                $msg .= "{$st} <b>{$p['name']}</b> — {$p['volume_gb']} GB / {$p['days']} روز — " . number_format($p['price']) . " تومان\n";
                $btns[] = [
                    ['text' => "{$st} {$p['name']}", 'callback_data' => "cp_prod_info_{$p['id']}"],
                    ['text' => ($p['status']==='active'?'⏸':'✅'), 'callback_data' => "cp_prod_toggle_{$p['id']}"],
                    ['text' => '🗑', 'callback_data' => "cp_prod_del_{$p['id']}"],
                ];
            }
            $btns[] = [['text' => '➕ افزودن محصول', 'callback_data' => 'cp_prod_add']];
            child_sendmessage($bot_token, $from_id, $msg, json_encode(['inline_keyboard' => $btns]), 'HTML');
        }
        die();
    }

    if ($text === '➕ افزودن محصول') {
        child_sendmessage($bot_token, $from_id, "📝 نام محصول را وارد کنید:", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_add_prod_name');
        die();
    }

    if ($user['step'] === 'cp_add_prod_name') {
        if (mb_strlen($text) < 2 || mb_strlen($text) > 60) {
            child_sendmessage($bot_token, $from_id, "❌ نام باید ۲ تا ۶۰ کاراکتر باشد.", $kb_back, 'HTML'); die();
        }
        child_save_pv($bot_token, $from_id, json_encode(['pname' => $text]));
        child_sendmessage($bot_token, $from_id, "📦 حجم (گیگابایت) را وارد کنید:", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_add_prod_gb');
        die();
    }

    if ($user['step'] === 'cp_add_prod_gb') {
        if (!ctype_digit($text) || intval($text) <= 0) {
            child_sendmessage($bot_token, $from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); die();
        }
        $gb_in = intval($text);
        // اگه ادمین محدودیت حجم محصول رو فعال کرده:
        // 1. حجم محصول نمی‌تونه از سقف کل ربات (volume_limit) بیشتر باشه
        // 2. حجم محصول نمی‌تونه از حجم باقیمانده واقعی پنل (panel_vol_cap - panel_vol_used) بیشتر باشه
        if (!empty($bot_info['enforce_vol_cap_product'])) {
            if ($gb_in > $bot_info['volume_limit']) {
                child_sendmessage($bot_token, $from_id,
                    "❌ حجم محصول نمی‌تواند بیشتر از سقف تعیین‌شده ربات شما باشد.\n📦 سقف ربات: <b>" . child_fmt_gb($bot_info['volume_limit']) . "</b>",
                    $kb_back, 'HTML');
                die();
            }
            // چک سقف واقعی پنل
            $pvc_cap  = $bot_info['panel_vol_cap']  ?? 0;
            $pvc_used = $bot_info['panel_vol_used']  ?? 0;
            if ($pvc_cap > 0) {
                $pvc_remain = max(0, $pvc_cap - $pvc_used);
                if ($gb_in > $pvc_remain) {
                    child_sendmessage($bot_token, $from_id,
                        "❌ حجم محصول از ظرفیت باقیمانده پنل بیشتر است.\n"
                        . "📊 مصرف پنل: <b>" . number_format($pvc_used, 1) . " GB</b> از <b>" . number_format($pvc_cap, 1) . " GB</b>\n"
                        . "🔋 باقیمانده: <b>" . number_format($pvc_remain, 1) . " GB</b>",
                        $kb_back, 'HTML');
                    die();
                }
            }
        }
        $d = json_decode($user['Processing_value'], true);
        $d['pgb'] = $gb_in;
        child_save_pv($bot_token, $from_id, json_encode($d));
        child_sendmessage($bot_token, $from_id, "📅 مدت زمان (روز) را وارد کنید:", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_add_prod_days');
        die();
    }

    if ($user['step'] === 'cp_add_prod_days') {
        if (!ctype_digit($text) || intval($text) <= 0) {
            child_sendmessage($bot_token, $from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); die();
        }
        $d = json_decode($user['Processing_value'], true);
        $d['pdays'] = intval($text);
        child_save_pv($bot_token, $from_id, json_encode($d));
        // حداقل قیمت بر اساس تعرفه ادمین — فقط اگه فعال باشه
        $min_price_enforced = !isset($bot_info['enforce_min_price']) || $bot_info['enforce_min_price'];
        if ($min_price_enforced) {
            $min_price = ($bot_info['price_per_gb'] * $d['pgb'])
                       + ($bot_info['price_per_month'] * max(1, ceil($d['pdays']/30)));
            child_sendmessage($bot_token, $from_id,
                "💰 قیمت (تومان) را وارد کنید:\n\n⚠️ حداقل قیمت مجاز: <b>" . number_format($min_price) . " تومان</b>",
                $kb_back, 'HTML');
        } else {
            child_sendmessage($bot_token, $from_id, "💰 قیمت (تومان) را وارد کنید:", $kb_back, 'HTML');
        }
        child_step($bot_token, $from_id, 'cp_add_prod_price');
        die();
    }

    if ($user['step'] === 'cp_add_prod_price') {
        if (!ctype_digit($text) || intval($text) < 0) {
            child_sendmessage($bot_token, $from_id, "❌ عدد معتبر وارد کنید.", $kb_back, 'HTML'); die();
        }
        $d = json_decode($user['Processing_value'], true);
        $price = intval($text);
        $min_price_enforced = !isset($bot_info['enforce_min_price']) || $bot_info['enforce_min_price'];
        if ($min_price_enforced) {
            $min_price = ($bot_info['price_per_gb'] * $d['pgb'])
                       + ($bot_info['price_per_month'] * max(1, ceil($d['pdays']/30)));
            if ($price < $min_price) {
                child_sendmessage($bot_token, $from_id,
                    "❌ قیمت کمتر از حداقل مجاز است.\nحداقل: <b>" . number_format($min_price) . " تومان</b>",
                    $kb_back, 'HTML');
                die();
            }
        }
        $pdo->prepare("INSERT INTO child_bot_product (bot_token, name, volume_gb, days, price, status, created_at) VALUES (?,?,?,?,?,'active',?)")
            ->execute([$bot_token, $d['pname'], $d['pgb'], $d['pdays'], $price, time()]);
        child_sendmessage($bot_token, $from_id,
            "✅ محصول <b>" . htmlspecialchars($d['pname']) . "</b> ثبت شد.\n📦 {$d['pgb']} GB / {$d['pdays']} روز — " . number_format($price) . " تومان",
            $kb_main_owner, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    // ================================================================
    // ---- ساخت کانفیگ توسط نماینده ----
    // ================================================================
    if ($text === '⚙️ ساخت کانفیگ') {
        // چک سقف
        // بارگذاری تازه از DB — سقف‌ها باید آپ‌تودیت باشن
        $bi_fresh = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi_fresh->execute([$bot_token]);
        $bi_fresh = $bi_fresh->fetch(PDO::FETCH_ASSOC);
        if ($bi_fresh['config_limit'] > 0 && $bi_fresh['config_used'] >= $bi_fresh['config_limit']) {
            child_sendmessage($bot_token, $from_id,
                "⚠️ به سقف کانفیگ رسیده‌اید ({$bi_fresh['config_limit']} عدد).\n📈 از گزینه «درخواست افزایش سقف» استفاده کنید.",
                $kb_main_owner, 'HTML'); die();
        }
        $remain_gb = $bi_fresh['volume_limit'] - $bi_fresh['volume_used'];
        if ($remain_gb <= 0) {
            child_sendmessage($bot_token, $from_id,
                "⚠️ حجم باقیمانده کافی نیست.\n📈 از گزینه «درخواست افزایش سقف» استفاده کنید.",
                $kb_main_owner, 'HTML'); die();
        }
        // چک سقف واقعی پنل — اگه مصرف پنل به cap رسیده باشه، ساخت ممنوع
        $pvc_cap_build  = $bi_fresh['panel_vol_cap']  ?? 0;
        $pvc_used_build = $bi_fresh['panel_vol_used']  ?? 0;
        if ($pvc_cap_build > 0 && $pvc_used_build >= $pvc_cap_build) {
            child_sendmessage($bot_token, $from_id,
                "🚨 <b>سقف حجم پنل پر شده است.</b>\n\n"
                . "📊 مصرف پنل: <b>" . number_format($pvc_used_build, 1) . " GB</b> از <b>" . number_format($pvc_cap_build, 1) . " GB</b>\n"
                . "⛔ ساخت کانفیگ جدید تا افزایش سقف ممکن نیست.\n"
                . "با ادمین اصلی تماس بگیرید.",
                $kb_main_owner, 'HTML'); die();
        }

        $products = $pdo->prepare("SELECT * FROM child_bot_product WHERE bot_token=? AND status='active' ORDER BY id");
        $products->execute([$bot_token]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);

        if (empty($products)) {
            child_sendmessage($bot_token, $from_id, "❌ ابتدا محصول تعریف کنید.", $kb_main_owner, 'HTML'); die();
        }

        $btns = [];
        foreach ($products as $p) {
            $warning = $p['volume_gb'] > $remain_gb ? ' ⚠️کم' : '';
            $btns[] = [['text' => "📦 {$p['name']} | {$p['volume_gb']}GB / {$p['days']}روز{$warning}", 'callback_data' => "cp_build_{$p['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "⚙️ <b>ساخت کانفیگ</b>\nمحصول را انتخاب کنید:", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    // ================================================================
    // ---- کانفیگ‌های ساخته شده ----
    // ================================================================
    if ($text === '👥 کانفیگ‌های ساخته شده') {
        $configs = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE bot_token=? ORDER BY created_at DESC LIMIT 30");
        $configs->execute([$bot_token]);
        $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($configs)) {
            child_sendmessage($bot_token, $from_id, "📋 هیچ کانفیگی ساخته نشده.", $kb_main_owner, 'HTML'); die();
        }
        $btns = [];
        foreach ($configs as $c) {
            $exp = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
            $icons = ['active'=>'✅','disabled'=>'🔴','expired'=>'⏰','removed'=>'🗑'];
            $icon = $icons[$c['status']] ?? '❓';
            $btns[] = [['text' => "{$icon} {$c['username_config']} | {$exp}", 'callback_data' => "cp_cfg_{$c['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "👥 <b>کانفیگ‌ها:</b>", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    // ================================================================
    // ---- درخواست افزایش سقف به ربات مادر ----
    // ================================================================
    if ($text === '📈 درخواست افزایش سقف') {
        $btns = json_encode(['keyboard' => [
            [['text' => '📦 درخواست حجم'], ['text' => '🔢 درخواست کانفیگ']],
            [['text' => '🔙 بازگشت']],
        ], 'resize_keyboard' => true]);
        child_sendmessage($bot_token, $from_id,
            "📈 <b>درخواست افزایش سقف</b>\n\n💵 قیمت/گیگ: <b>" . number_format($bot_info['price_per_gb']) . " تومان</b>\n📅 قیمت/ماه: <b>" . number_format($bot_info['price_per_month']) . " تومان</b>\n💳 کیف پول شما: <b>" . number_format($bot_info['wallet']) . " تومان</b>",
            $btns, 'HTML');
        die();
    }

    if ($text === '📦 درخواست حجم') {
        child_sendmessage($bot_token, $from_id, "📦 چند گیگابایت می‌خواهید اضافه کنید؟", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_req_gb');
        die();
    }

    if ($user['step'] === 'cp_req_gb') {
        if (!ctype_digit($text) || intval($text) <= 0) {
            child_sendmessage($bot_token, $from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); die();
        }
        $gb = intval($text);
        $total = $gb * $bot_info['price_per_gb'];
        $kb_confirm = json_encode(['inline_keyboard' => [[
            ['text' => '💳 پرداخت از کیف پول', 'callback_data' => "cp_vol_pay_{$gb}_{$total}"],
            ['text' => '❌ انصراف', 'callback_data' => 'cp_cancel'],
        ]]]);
        child_sendmessage($bot_token, $from_id,
            "📦 <b>تأیید درخواست</b>\n\n📦 حجم: <b>" . child_fmt_gb($gb) . "</b>\n💰 هزینه: <b>" . number_format($total) . " تومان</b>\n💳 موجودی: <b>" . number_format($bot_info['wallet']) . " تومان</b>",
            $kb_confirm, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    if ($text === '🔢 درخواست کانفیگ') {
        child_sendmessage($bot_token, $from_id, "🔢 چند کانفیگ اضافه می‌خواهید؟", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_req_cfg');
        die();
    }

    if ($user['step'] === 'cp_req_cfg') {
        if (!ctype_digit($text) || intval($text) <= 0) {
            child_sendmessage($bot_token, $from_id, "❌ عدد صحیح مثبت وارد کنید.", $kb_back, 'HTML'); die();
        }
        $count = intval($text);
        $kb_confirm = json_encode(['inline_keyboard' => [[
            ['text' => '✅ ارسال درخواست', 'callback_data' => "cp_cfg_req_{$count}"],
            ['text' => '❌ انصراف', 'callback_data' => 'cp_cancel'],
        ]]]);
        child_sendmessage($bot_token, $from_id,
            "🔢 درخواست <b>{$count} کانفیگ</b> اضافی\nبه ربات مادر ارسال می‌شود.",
            $kb_confirm, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

    // ---- ارسال پیام همگانی ----
    if ($text === '🔔 ارسال پیام همگانی') {
        child_sendmessage($bot_token, $from_id, "📢 متن پیام همگانی را بفرستید:", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_broadcast');
        die();
    }

    if ($user['step'] === 'cp_broadcast') {
        $result = child_broadcast($bot_token, $text);
        child_sendmessage($bot_token, $from_id,
            "✅ پیام ارسال شد.\n✅ موفق: {$result['sent']}\n❌ ناموفق: {$result['failed']}",
            $kb_main_owner, 'HTML');
        child_step($bot_token, $from_id, 'home');
        die();
    }

} // end is_owner

// ================================================================
// بخش کاربر عادی (مشتری زیر ربات)
// ================================================================
if (!$is_owner) {

    // ---- خرید اشتراک ----
    if ($text === '🛒 خرید اشتراک') {
        if ($bot_info['status'] !== 'active') {
            child_sendmessage($bot_token, $from_id, "⚠️ این ربات در حال حاضر غیرفعال است.", null, 'HTML'); die();
        }
        $products = $pdo->prepare("SELECT * FROM child_bot_product WHERE bot_token=? AND status='active' ORDER BY id");
        $products->execute([$bot_token]);
        $products = $products->fetchAll(PDO::FETCH_ASSOC);
        if (empty($products)) {
            child_sendmessage($bot_token, $from_id, "⚠️ در حال حاضر محصولی موجود نیست.", $kb_main_user, 'HTML'); die();
        }
        $btns = [];
        foreach ($products as $p) {
            $btns[] = [['text' => "📦 {$p['name']} | {$p['volume_gb']}GB / {$p['days']} روز | " . number_format($p['price']) . " تومان", 'callback_data' => "cu_buy_{$p['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "🛒 <b>محصولات موجود:</b>\nمحصول مورد نظر را انتخاب کنید:", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    // ---- سرویس‌های من ----
    if ($text === '📋 سرویس‌های من') {
        $configs = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE bot_token=? AND user_id=? ORDER BY created_at DESC");
        $configs->execute([$bot_token, $from_id]);
        $configs = $configs->fetchAll(PDO::FETCH_ASSOC);
        if (empty($configs)) {
            child_sendmessage($bot_token, $from_id, "📋 شما هیچ سرویس فعالی ندارید.", $kb_main_user, 'HTML'); die();
        }
        $btns = [];
        foreach ($configs as $c) {
            $exp = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
            $icons = ['active'=>'✅','disabled'=>'🔴','expired'=>'⏰','removed'=>'🗑'];
            $icon = $icons[$c['status']] ?? '❓';
            $btns[] = [['text' => "{$icon} {$c['product_name']} | {$exp}", 'callback_data' => "cu_cfg_{$c['id']}"]];
        }
        child_sendmessage($bot_token, $from_id, "📋 <b>سرویس‌های شما:</b>", json_encode(['inline_keyboard' => $btns]), 'HTML');
        die();
    }

    // ---- موجودی کیف پول ----
    if ($text === '💰 موجودی کیف پول') {
        child_sendmessage($bot_token, $from_id,
            "💰 موجودی کیف پول: <b>" . number_format($user['Balance']) . " تومان</b>",
            $kb_main_user, 'HTML');
        die();
    }

    // ---- پشتیبانی ----
    if ($text === '📞 پشتیبانی') {
        child_sendmessage($bot_token, $from_id,
            "📞 برای پشتیبانی با مدیر ربات در تماس باشید.",
            $kb_main_user, 'HTML');
        die();
    }

} // end !is_owner

// ================================================================
// Callbacks (inline keyboard)
// ================================================================
if ($datain) {

    if ($is_owner && $is_limited_panel && !child_is_allowed_owner_callback($datain)) {
        child_answer_callback($bot_token, $callback_query_id, '⚠️ این عملیات در این نسخه محدود در دسترس نیست.', true);
        die();
    }

    // ---- toggle وضعیت اکانت تست ----
    if ($is_owner && ($datain === 'ontestshowpanel' || $datain === 'offtestshowpanel')) {
        $panel = select('marzban_panel', '*', 'name_panel', $bot_info['panel_name'], 'select');
        if (!$panel) { child_answer_callback($bot_token, $callback_query_id, '❌ پنل تنظیم نشده.', true); die(); }
        $new_status = $datain === 'ontestshowpanel' ? 'offtestshowpanel' : 'ontestshowpanel';
        $pdo->prepare("UPDATE marzban_panel SET statusTest=? WHERE name_panel=?")
            ->execute([$new_status, $panel['name_panel']]);
        $btn_text = $new_status === 'ontestshowpanel' ? '🟢 فعال (برای غیرفعال کردن بزن)' : '🔴 غیرفعال (برای فعال کردن بزن)';
        child_editmessage($bot_token, $from_id, $message_id,
            "🧪 <b>وضعیت اکانت تست</b>\n\n" . "📌 پنل: <b>{$panel['name_panel']}</b>\n\nبرای تغییر وضعیت روی دکمه زیر بزن:",
            json_encode(['inline_keyboard' => [[['text' => $btn_text, 'callback_data' => $new_status]]]]));
        child_answer_callback($bot_token, $callback_query_id, $new_status === 'ontestshowpanel' ? '✅ اکانت تست فعال شد' : '🔴 اکانت تست غیرفعال شد');
        die();
    }

    // ---- toggle محصول ----
    if (preg_match('/^cp_prod_toggle_(\d+)$/', $datain, $m)) {
        $pid = $m[1];
        $p = $pdo->prepare("SELECT * FROM child_bot_product WHERE id=? AND bot_token=?");
        $p->execute([$pid, $bot_token]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) { child_answer_callback($bot_token, $callback_query_id, '❌ پیدا نشد'); die(); }
        $new = $p['status'] === 'active' ? 'inactive' : 'active';
        $pdo->prepare("UPDATE child_bot_product SET status=? WHERE id=?")->execute([$new, $pid]);
        child_answer_callback($bot_token, $callback_query_id, $new === 'active' ? '✅ فعال شد' : '⏸ غیرفعال شد', true);
        die();
    }

    // ---- حذف محصول ----
    if (preg_match('/^cp_prod_del_(\d+)$/', $datain, $m)) {
        $pdo->prepare("DELETE FROM child_bot_product WHERE id=? AND bot_token=?")->execute([$m[1], $bot_token]);
        child_editmessage($bot_token, $from_id, $message_id, "🗑 محصول حذف شد.", json_encode(['inline_keyboard' => []]));
        die();
    }

    // ---- افزودن محصول از inline ----
    if ($datain === 'cp_prod_add') {
        child_sendmessage($bot_token, $from_id, "📝 نام محصول را وارد کنید:", $kb_back, 'HTML');
        child_step($bot_token, $from_id, 'cp_add_prod_name');
        die();
    }

    // ================================================================
    // ---- ساخت کانفیگ (owner) ----
    // ================================================================
    if (preg_match('/^cp_build_(\d+)$/', $datain, $m) && $is_owner) {
        $pid = $m[1];

        // بارگذاری دوباره bot_info (ممکنه تغییر کرده باشه)
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $p = $pdo->prepare("SELECT * FROM child_bot_product WHERE id=? AND bot_token=? AND status='active'");
        $p->execute([$pid, $bot_token]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) { child_answer_callback($bot_token, $callback_query_id, '❌ محصول پیدا نشد'); die(); }

        // چک سقف‌ها (چک اولیه برای پیام بهتر به کاربر؛ تضمین واقعی در رزرو atomic زیر است)
        if ($bi['config_limit'] > 0 && $bi['config_used'] >= $bi['config_limit']) {
            child_answer_callback($bot_token, $callback_query_id, '⚠️ سقف کانفیگ پر شده', true); die();
        }
        $remain_gb = $bi['volume_limit'] - $bi['volume_used'];
        if ($p['volume_gb'] > $remain_gb) {
            child_answer_callback($bot_token, $callback_query_id, '⚠️ حجم کافی ندارید', true); die();
        }

        // چک سقف مصرف واقعی پنل — لحظه‌ای از خود پنل (نه فقط مقدار کش‌شده)
        $pvc_check = child_check_panel_volume_live($ManagePanel, $bot_token, $bi['panel_name'], $bi['panel_vol_cap'] ?? 0, $p['volume_gb']);
        if (!$pvc_check['ok']) {
            child_editmessage($bot_token, $from_id, $message_id,
                $pvc_check['msg'] . "\n\nبرای افزایش سقف با ادمین اصلی تماس بگیرید.",
                json_encode(['inline_keyboard' => []]));
            die();
        }

        // چک کیف پول
        $cost = ($p['volume_gb'] * $bi['price_per_gb'])
              + ($bi['price_per_month'] * max(1, ceil($p['days']/30)));
        if ($bi['wallet'] < $cost) {
            child_editmessage($bot_token, $from_id, $message_id,
                "❌ موجودی کیف پول کافی نیست.\nهزینه: <b>" . number_format($cost) . " تومان</b>\nموجودی: <b>" . number_format($bi['wallet']) . " تومان</b>",
                json_encode(['inline_keyboard' => []]));
            die();
        }

        // ---- رزرو atomic سقف حجم/کانفیگ/کیف‌پول قبل از ساخت در پنل ----
        // این UPDATE با شرط در همان کوئری انجام می‌شود تا در صورت درخواست‌های
        // هم‌زمان (مثلاً چند کلیک سریع)، فقط یکی از آن‌ها موفق به رزرو شود و
        // مجموع مصرف هرگز از سقف رد نشود (جلوگیری از race condition).
        $reserve = $pdo->prepare(
            "UPDATE reseller_bot
             SET volume_used = volume_used + ?, config_used = config_used + 1, wallet = wallet - ?
             WHERE bot_token = ?
               AND (volume_limit - volume_used) >= ?
               AND (config_limit = 0 OR config_used < config_limit)
               AND wallet >= ?"
        );
        $reserve->execute([$p['volume_gb'], $cost, $bot_token, $p['volume_gb'], $cost]);
        if ($reserve->rowCount() === 0) {
            // یعنی بین چک اولیه و الان، سقف توسط درخواست دیگری پر شده
            child_answer_callback($bot_token, $callback_query_id, '⚠️ سقف یا موجودی به پایان رسید، لطفاً دوباره تلاش کنید', true);
            die();
        }

        // ساخت username منحصر به فرد
        $uname = 'cb_' . substr(md5($bot_token), 0, 4) . '_' . substr(md5(uniqid()), 0, 6);
        $expire_at  = time() + ($p['days'] * 86400);
        $data_limit = $p['volume_gb'] * 1073741824;

        $datac = ['expire' => $expire_at, 'data_limit' => $data_limit];

        // Squad برای remnawave
        $panel_info = select("marzban_panel", "*", "name_panel", $bi['panel_name'], "select");
        if (($panel_info['type'] ?? '') === 'remnawave') {
            // از allowed_inbounds برای child_bot بگیر (فرمت: main_squad_uuid|test_squad_uuid)
            $squad_selection = child_decode_squad_selection($bi['allowed_inbounds'] ?? '');
            if (!empty($squad_selection['main'])) {
                $datac['squad_uuid'] = $squad_selection['main'];
            }
        }

        $result = $ManagePanel->createUser($bi['panel_name'], $uname, $datac);
        if (!isset($result['username'])) {
            // ساخت در پنل شکست خورد — رزرو را برمی‌گردانیم
            $pdo->prepare(
                "UPDATE reseller_bot SET volume_used = volume_used - ?, config_used = GREATEST(0, config_used - 1), wallet = wallet + ? WHERE bot_token = ?"
            )->execute([$p['volume_gb'], $cost, $bot_token]);
            child_editmessage($bot_token, $from_id, $message_id,
                "❌ خطا در ساخت کانفیگ:\n<code>" . json_encode($result['msg'] ?? 'unknown') . "</code>",
                json_encode(['inline_keyboard' => []]));
            die();
        }

        // ذخیره در child_bot_invoice
        $pdo->prepare("INSERT INTO child_bot_invoice (bot_token, user_id, username_config, product_name, volume_gb, days, price, status, created_at, expire_at) VALUES (?,?,?,?,?,?,?,'active',?,?)")
            ->execute([$bot_token, $from_id, $uname, $p['name'], $p['volume_gb'], $p['days'], $p['price'], time(), $expire_at]);

        // لینک سابسکریپشن
        $udata   = $ManagePanel->DataUser($bi['panel_name'], $uname);
        $sub_url = $udata['subscription_url'] ?? ($udata['links'][0] ?? 'N/A');
        $disp_name = $bi['display_name'] ?: $bi['panel_name'];

        child_editmessage($bot_token, $from_id, $message_id,
            "✅ <b>کانفیگ ساخته شد!</b>\n\n"
            . "🌐 لوکیشن: <b>{$disp_name}</b>\n"
            . "👤 یوزرنیم: <code>{$uname}</code>\n"
            . "📦 حجم: <b>{$p['volume_gb']} GB</b> | ⏱ <b>{$p['days']} روز</b>\n"
            . "💰 هزینه: <b>" . number_format($cost) . " تومان</b>\n\n"
            . "🔗 لینک اشتراک:\n<code>{$sub_url}</code>",
            json_encode(['inline_keyboard' => []]));
        die();
    }

    // ================================================================
    // ---- مشاهده و مدیریت کانفیگ (owner) ----
    // ================================================================
    if (preg_match('/^cp_cfg_(\d+)$/', $datain, $m) && $is_owner) {
        $cid = $m[1];
        $c = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE id=? AND bot_token=?");
        $c->execute([$cid, $bot_token]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) { child_answer_callback($bot_token, $callback_query_id, '❌ پیدا نشد'); die(); }

        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $du = $ManagePanel->DataUser($bi['panel_name'], $c['username_config']);
        $used = isset($du['used_traffic']) ? round($du['used_traffic']/1073741824, 2).' GB' : '—';
        $limit = child_fmt_gb($c['volume_gb']);
        $exp  = $c['expire_at'] > 0 ? jdate('Y/m/d H:i', $c['expire_at']) : '—';
        $st   = ['active'=>'✅ فعال','disabled'=>'🔴 غیرفعال','expired'=>'⏰ منقضی'][$du['status']??$c['status']] ?? '—';
        $sub  = $du['subscription_url'] ?? ($du['links'][0] ?? 'N/A');

        $msg = "📌 <b>{$c['username_config']}</b>\n\n"
             . "📦 مصرف: {$used} از {$limit}\n"
             . "📅 انقضا: {$exp}\n"
             . "⚡ وضعیت: {$st}\n"
             . "🔗 لینک:\n<code>{$sub}</code>";

        $btns = [
            [
                ['text' => '✅ فعال', 'callback_data' => "cp_cfg_en_{$cid}"],
                ['text' => '🔴 غیرفعال', 'callback_data' => "cp_cfg_dis_{$cid}"],
            ],
            [
                ['text' => '⏰ تمدید +۳۰ روز', 'callback_data' => "cp_cfg_renew_{$cid}"],
                ['text' => '🗑 حذف', 'callback_data' => "cp_cfg_del_{$cid}"],
            ],
            [['text' => '🔙 بستن', 'callback_data' => 'cp_close']],
        ];
        child_editmessage($bot_token, $from_id, $message_id, $msg, json_encode(['inline_keyboard' => $btns]));
        die();
    }

    // ---- فعال/غیرفعال/تمدید/حذف کانفیگ ----
    if (preg_match('/^cp_cfg_(en|dis|renew|del)_(\d+)$/', $datain, $m) && $is_owner) {
        $action = $m[1]; $cid = $m[2];
        $c = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE id=? AND bot_token=?");
        $c->execute([$cid, $bot_token]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) { child_answer_callback($bot_token, $callback_query_id, '❌ پیدا نشد'); die(); }

        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        if ($action === 'en') {
            $ManagePanel->Enableuser($bi['panel_name'], $c['username_config']);
            $pdo->prepare("UPDATE child_bot_invoice SET status='active' WHERE id=?")->execute([$cid]);
            child_answer_callback($bot_token, $callback_query_id, '✅ فعال شد', true);
        } elseif ($action === 'dis') {
            $ManagePanel->Disableuser($bi['panel_name'], $c['username_config']);
            $pdo->prepare("UPDATE child_bot_invoice SET status='disabled' WHERE id=?")->execute([$cid]);
            child_answer_callback($bot_token, $callback_query_id, '🔴 غیرفعال شد', true);
        } elseif ($action === 'renew') {
            $cost_m = $bi['price_per_month'];
            if ($bi['wallet'] < $cost_m) {
                child_answer_callback($bot_token, $callback_query_id, '❌ موجودی کافی نیست', true); die();
            }
            $new_exp = max(time(), $c['expire_at']) + 2592000;
            $ManagePanel->Modifyuser($c['username_config'], $bi['panel_name'], ['expire' => $new_exp]);
            $pdo->prepare("UPDATE child_bot_invoice SET expire_at=?, days=days+30, status='active' WHERE id=?")->execute([$new_exp, $cid]);
            $pdo->prepare("UPDATE reseller_bot SET wallet=wallet-? WHERE bot_token=?")->execute([$cost_m, $bot_token]);
            child_answer_callback($bot_token, $callback_query_id, '✅ ۳۰ روز تمدید شد', true);
        } elseif ($action === 'del') {
            $du = $ManagePanel->DataUser($bi['panel_name'], $c['username_config']);
            if (isset($du['status'])) $ManagePanel->RemoveUser($bi['panel_name'], $c['username_config']);
            $pdo->prepare("UPDATE child_bot_invoice SET status='removed' WHERE id=?")->execute([$cid]);
            $pdo->prepare("UPDATE reseller_bot SET config_used=GREATEST(0,config_used-1) WHERE bot_token=?")->execute([$bot_token]);
            child_editmessage($bot_token, $from_id, $message_id, "🗑 کانفیگ حذف شد.", json_encode(['inline_keyboard' => []]));
            die();
        }
        die();
    }

    // ---- Owner callbacks: Select main squad (child_select_main_squad step) ----
    if (preg_match('/^cb_child_squad_main_(.+)$/', $datain, $m) && $is_owner && $user['step'] === 'child_select_main_squad') {
        $main_squad_uuid = $m[1];
        
        // بگیر داده‌های موجود
        $pv = json_decode(child_get_pv($bot_token, $from_id), true) ?? [];
        
        // ذخیره اسکواد اصلی (مثل ربات اصلی: savedata("save", "remna_main_squad", ...))
        $pv['child_remna_main_squad'] = $main_squad_uuid;
        child_save_pv($bot_token, $from_id, json_encode($pv));
        
        // پاسخ به callback
        child_answer_callback($bot_token, $callback_query_id);
        
        // حذف پیام قبلی
        if (isset($pv['child_squad_msg_id']) && !empty($pv['child_squad_msg_id'])) {
            child_deletemessage($bot_token, $from_id, $pv['child_squad_msg_id']);
        }
        
        // اکنون اسکواد تست رو بپرس
        $squad_list = $pv['child_remna_squads'] ?? [];
        
        $buttons = [];
        foreach ($squad_list as $sq) {
            $buttons[] = [['text' => "🟢 {$sq['name']}", 'callback_data' => "cb_child_squad_test_" . $sq['uuid']]];
        }
        $buttons[] = [['text' => "🔴 بدون اسکواد تست (همون خرید)", 'callback_data' => "cb_child_squad_test_same"]];
        $buttons[] = [['text' => '🔙 بازگشت', 'callback_data' => 'cb_owner_back_panel']];
        
        $msg = "🟢 <b>اسکواد تست</b> رو انتخاب کن:\n\nکاربران اکانت تست به این اسکواد وصل میشن";
        $msg_response = child_sendmessage($bot_token, $from_id, $msg, json_encode(['inline_keyboard' => $buttons]), 'HTML');
        child_step($bot_token, $from_id, 'child_select_test_squad');
        
        // ذخیره message_id جدید
        $pv['child_squad_msg_id'] = $msg_response['result']['message_id'] ?? $message_id;
        child_save_pv($bot_token, $from_id, json_encode($pv));
        die();
    }
    
    // ---- Owner callbacks: Select test squad (child_select_test_squad step) ----
    if (preg_match('/^cb_child_squad_test_(.+)$/', $datain, $m) && $is_owner && $user['step'] === 'child_select_test_squad') {
        $test_squad_uuid = $m[1];
        
        // بگیر داده‌های موجود
        $pv = json_decode(child_get_pv($bot_token, $from_id), true) ?? [];
        $main_squad_uuid = $pv['child_remna_main_squad'] ?? '';
        $squad_list = $pv['child_remna_squads'] ?? [];
        
        // اگه "same" انتخاب شد، test رو برابر main کن
        if ($test_squad_uuid === 'same') {
            $test_squad_uuid = $main_squad_uuid;
        }
        
        // پاسخ به callback
        child_answer_callback($bot_token, $callback_query_id);
        
        // حذف پیام قبلی (مثل ربات اصلی)
        if (isset($pv['child_squad_msg_id']) && !empty($pv['child_squad_msg_id'])) {
            child_deletemessage($bot_token, $from_id, $pv['child_squad_msg_id']);
        }
        
        // ذخیره در allowed_inbounds: main_uuid|test_uuid
        $squad_selection = $main_squad_uuid . '|' . $test_squad_uuid;
        $pdo->prepare("UPDATE reseller_bot SET allowed_inbounds=? WHERE bot_token=?")
            ->execute([$squad_selection, $bot_token]);
        
        // نمایش خلاصه
        $main_name = $main_squad_uuid;
        $test_name = $test_squad_uuid;
        foreach ($squad_list as $sq) {
            if ($sq['uuid'] === $main_squad_uuid) $main_name = $sq['name'];
            if ($sq['uuid'] === $test_squad_uuid) $test_name = $sq['name'];
        }
        
        $msg = "✅ <b>تنظیمات اسکواد ذخیره شد:</b>\n\n🔵 خریدی: <b>{$main_name}</b>\n🟢 تست: <b>{$test_name}</b>";
        child_sendmessage($bot_token, $from_id, $msg, $kb_owner_panel, 'HTML');
        child_step($bot_token, $from_id, 'home');
        child_answer_callback($bot_token, $callback_query_id);
        die();
    }

    if ($datain === 'cb_owner_back_panel' && $is_owner) {
        child_answer_callback($bot_token, $callback_query_id);
        child_sendmessage($bot_token, $from_id, "🔧 <b>مدیریت پنل</b>", $kb_owner_panel, 'HTML');
        die();
    }

    if ($datain === 'cb_owner_noop' && $is_owner) {
        child_answer_callback($bot_token, $callback_query_id, '⚠️ عملیاتی برای انجام وجود ندارد', true);
        die();
    }

    // ================================================================
    // ---- پرداخت کیف پول برای حجم ----
    // ================================================================
    if (preg_match('/^cp_vol_pay_(\d+)_(\d+)$/', $datain, $m) && $is_owner) {
        $gb = intval($m[1]); $total = intval($m[2]);
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        if ($bi['wallet'] < $total) {
            child_editmessage($bot_token, $from_id, $message_id,
                "❌ موجودی کافی نیست.\nموجودی: <b>" . number_format($bi['wallet']) . " تومان</b>",
                json_encode(['inline_keyboard' => []]));
            die();
        }
        // کسر از کیف پول و ثبت درخواست
        $pdo->prepare("INSERT INTO child_bot_request (bot_token, request_type, amount, total_price, status, created_at) VALUES (?, 'volume', ?, ?, 'pending', ?)")
            ->execute([$bot_token, $gb, $total, time()]);
        $req_id = $pdo->lastInsertId();
        $pdo->prepare("UPDATE reseller_bot SET wallet=wallet-? WHERE bot_token=?")->execute([$total, $bot_token]);

        child_editmessage($bot_token, $from_id, $message_id,
            "✅ مبلغ از کیف پول کسر شد.\n\n⏳ درخواست <b>" . child_fmt_gb($gb) . "</b> به ادمین اصلی ارسال شد.",
            json_encode(['inline_keyboard' => []]));

        // اطلاع به ادمین‌های ربات مادر
        $msg_admin = "📨 <b>درخواست افزایش سقف حجم</b>\n\n"
                   . "🤖 ربات: @{$bi['bot_username']}\n"
                   . "👤 نماینده: <code>{$bi['owner_id']}</code>\n"
                   . "📦 حجم: <b>" . child_fmt_gb($gb) . "</b>\n"
                   . "💰 مبلغ پرداختی: <b>" . number_format($total) . " تومان</b>";
        $kb_admin = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید', 'callback_data' => "cbreq_approve_{$req_id}"],
            ['text' => '❌ رد + برگشت', 'callback_data' => "cbreq_reject_{$req_id}"],
        ]]]);
        notify_mother_admins($msg_admin, $kb_admin);
        die();
    }

    // ---- درخواست کانفیگ اضافه ----
    if (preg_match('/^cp_cfg_req_(\d+)$/', $datain, $m) && $is_owner) {
        $count = intval($m[1]);
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $pdo->prepare("INSERT INTO child_bot_request (bot_token, request_type, amount, total_price, status, created_at) VALUES (?, 'config', ?, 0, 'pending', ?)")
            ->execute([$bot_token, $count, time()]);
        $req_id = $pdo->lastInsertId();

        child_editmessage($bot_token, $from_id, $message_id,
            "✅ درخواست <b>{$count} کانفیگ</b> به ادمین ارسال شد.\n⏳ منتظر تایید باشید.",
            json_encode(['inline_keyboard' => []]));

        $msg_admin = "📨 <b>درخواست افزایش سقف کانفیگ</b>\n\n🤖 ربات: @{$bi['bot_username']}\n👤 نماینده: <code>{$bi['owner_id']}</code>\n🔢 تعداد: <b>{$count} کانفیگ</b>";
        $kb_admin  = json_encode(['inline_keyboard' => [[
            ['text' => '✅ تایید', 'callback_data' => "cbreq_approve_{$req_id}"],
            ['text' => '❌ رد', 'callback_data' => "cbreq_reject_{$req_id}"],
        ]]]);
        notify_mother_admins($msg_admin, $kb_admin);
        die();
    }

    // ================================================================
    // ---- مشاهده کانفیگ توسط مشتری ----
    // ================================================================
    if (preg_match('/^cu_cfg_(\d+)$/', $datain, $m) && !$is_owner) {
        $cid = $m[1];
        $c = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE id=? AND bot_token=? AND user_id=?");
        $c->execute([$cid, $bot_token, $from_id]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) { child_answer_callback($bot_token, $callback_query_id, '❌ پیدا نشد'); die(); }

        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $du  = $ManagePanel->DataUser($bi['panel_name'], $c['username_config']);
        $used = isset($du['used_traffic']) ? round($du['used_traffic']/1073741824, 2).' GB' : '—';
        $exp = $c['expire_at'] > 0 ? jdate('Y/m/d', $c['expire_at']) : '—';
        $st  = ['active'=>'✅ فعال','disabled'=>'🔴 غیرفعال','expired'=>'⏰ منقضی'][$du['status']??$c['status']] ?? '—';
        $sub = $du['subscription_url'] ?? ($du['links'][0] ?? 'N/A');
        $disp_name = $bi['display_name'] ?: $bi['panel_name'];

        child_editmessage($bot_token, $from_id, $message_id,
            "📌 <b>{$c['product_name']}</b>\n🌐 لوکیشن: <b>{$disp_name}</b>\n\n📦 مصرف: {$used} از " . child_fmt_gb($c['volume_gb']) . "\n📅 انقضا: {$exp}\n⚡ وضعیت: {$st}\n\n🔗 لینک اشتراک:\n<code>{$sub}</code>",
            json_encode(['inline_keyboard' => [
                [['text' => '🔄 تمدید +۳۰ روز', 'callback_data' => "cu_cfg_renew_{$cid}" ]],
                [['text' => '🔙 بستن', 'callback_data' => 'cp_close']],
            ]]));
        die();
    }

    // ---- تمدید اشتراک توسط مشتری ----
    if (preg_match('/^cu_cfg_renew_(\d+)$/', $datain, $m) && !$is_owner) {
        $cid = $m[1];
        $c = $pdo->prepare("SELECT * FROM child_bot_invoice WHERE id=? AND bot_token=? AND user_id=?");
        $c->execute([$cid, $bot_token, $from_id]);
        $c = $c->fetch(PDO::FETCH_ASSOC);
        if (!$c) { child_answer_callback($bot_token, $callback_query_id, '❌ پیدا نشد', true); die(); }

        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $cost = $bi['price_per_month'];
        $fresh_user = $pdo->prepare("SELECT * FROM child_bot_user WHERE bot_token=? AND user_id=?");
        $fresh_user->execute([$bot_token, $from_id]);
        $fresh_user = $fresh_user->fetch(PDO::FETCH_ASSOC);

        if (($fresh_user['Balance'] ?? 0) < $cost) {
            child_answer_callback($bot_token, $callback_query_id, '❌ موجودی کافی نیست', true); die();
        }

        $new_expire = max(time(), $c['expire_at']) + 2592000;
        $ManagePanel->Modifyuser($c['username_config'], $bi['panel_name'], ['expire' => $new_expire]);

        $pdo->prepare("UPDATE child_bot_user SET Balance=Balance-? WHERE bot_token=? AND user_id=?")
            ->execute([$cost, $bot_token, $from_id]);
        $pdo->prepare("UPDATE child_bot_invoice SET expire_at=?, days=days+30, status='active' WHERE id=?")
            ->execute([$new_expire, $cid]);
        $pdo->prepare("UPDATE reseller_bot SET wallet=wallet-? WHERE bot_token=?")
            ->execute([$cost, $bot_token]);

        child_editmessage($bot_token, $from_id, $message_id,
            "✅ <b>اشتراک با موفقیت تمدید شد</b>\n\n📅 انقضا: " . jdate('Y/m/d H:i', $new_expire) . "\n💰 هزینه: <b>" . number_format($cost) . " تومان</b>",
            json_encode(['inline_keyboard' => []]));
        die();
    }

    // ---- خرید توسط مشتری ----
    if (preg_match('/^cu_buy_(\d+)$/', $datain, $m) && !$is_owner) {
        $pid = $m[1];
        $p = $pdo->prepare("SELECT * FROM child_bot_product WHERE id=? AND bot_token=? AND status='active'");
        $p->execute([$pid, $bot_token]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) { child_answer_callback($bot_token, $callback_query_id, '❌ محصول پیدا نشد'); die(); }

        // چک کیف پول مشتری
        if ($user['Balance'] >= $p['price']) {
            // پرداخت از کیف پول
            child_save_pv($bot_token, $from_id, json_encode(['buy_pid' => $pid, 'buy_method' => 'wallet']));
            $kb_confirm = json_encode(['inline_keyboard' => [[
                ['text' => '✅ پرداخت از کیف پول', 'callback_data' => "cu_confirm_{$pid}"],
                ['text' => '❌ انصراف', 'callback_data' => 'cp_cancel'],
            ]]]);
            child_editmessage($bot_token, $from_id, $message_id,
                "🛒 <b>{$p['name']}</b>\n\n📦 {$p['volume_gb']} GB / {$p['days']} روز\n💰 قیمت: <b>" . number_format($p['price']) . " تومان</b>\n💳 موجودی کیف پول: <b>" . number_format($user['Balance']) . " تومان</b>",
                $kb_confirm);
        } else {
            // موجودی کافی نیست - باید شارژ کنه
            child_editmessage($bot_token, $from_id, $message_id,
                "❌ موجودی کافی نیست.\n\n💰 قیمت: <b>" . number_format($p['price']) . " تومان</b>\n💳 موجودی شما: <b>" . number_format($user['Balance']) . " تومان</b>\n\nبرای شارژ کیف پول با مدیر در تماس باشید.",
                json_encode(['inline_keyboard' => []]));
        }
        die();
    }

    // ---- تأیید خرید توسط مشتری ----
    if (preg_match('/^cu_confirm_(\d+)$/', $datain, $m) && !$is_owner) {
        $pid = $m[1];
        $bi = $pdo->prepare("SELECT * FROM reseller_bot WHERE bot_token=?");
        $bi->execute([$bot_token]);
        $bi = $bi->fetch(PDO::FETCH_ASSOC);

        $p = $pdo->prepare("SELECT * FROM child_bot_product WHERE id=? AND bot_token=? AND status='active'");
        $p->execute([$pid, $bot_token]);
        $p = $p->fetch(PDO::FETCH_ASSOC);
        if (!$p) { child_answer_callback($bot_token, $callback_query_id, '❌ محصول یافت نشد'); die(); }

        // چک دوباره موجودی
        $fresh_user = $pdo->prepare("SELECT * FROM child_bot_user WHERE bot_token=? AND user_id=?");
        $fresh_user->execute([$bot_token, $from_id]);
        $fresh_user = $fresh_user->fetch(PDO::FETCH_ASSOC);
        if ($fresh_user['Balance'] < $p['price']) {
            child_answer_callback($bot_token, $callback_query_id, '❌ موجودی کافی نیست', true); die();
        }

        // چک سقف‌های نماینده (چک اولیه برای پیام بهتر؛ تضمین واقعی در رزرو atomic زیر است)
        if ($bi['config_limit'] > 0 && $bi['config_used'] >= $bi['config_limit']) {
            child_editmessage($bot_token, $from_id, $message_id, "⚠️ در حال حاضر ظرفیت تکمیل است.", json_encode(['inline_keyboard' => []])); die();
        }
        $remain_gb = $bi['volume_limit'] - $bi['volume_used'];
        if ($p['volume_gb'] > $remain_gb) {
            child_editmessage($bot_token, $from_id, $message_id, "⚠️ در حال حاضر این محصول موجود نیست.", json_encode(['inline_keyboard' => []])); die();
        }
        // چک سقف مصرف واقعی پنل — لحظه‌ای از خود پنل (نه فقط مقدار کش‌شده)
        $pvc_check = child_check_panel_volume_live($ManagePanel, $bot_token, $bi['panel_name'], $bi['panel_vol_cap'] ?? 0, $p['volume_gb']);
        if (!$pvc_check['ok']) {
            child_editmessage($bot_token, $from_id, $message_id, "⚠️ در حال حاضر ظرفیت پنل تکمیل است.", json_encode(['inline_keyboard' => []])); die();
        }

        // هزینه نماینده
        $cost = ($p['volume_gb'] * $bi['price_per_gb'])
              + ($bi['price_per_month'] * max(1, ceil($p['days']/30)));

        // ---- رزرو atomic موجودی مشتری قبل از ساخت در پنل ----
        // جلوگیری از race condition: اگه مشتری چند درخواست هم‌زمان بفرسته،
        // فقط یکی موفق به کسر موجودی می‌شود.
        $reserve_user = $pdo->prepare(
            "UPDATE child_bot_user SET Balance = Balance - ? WHERE bot_token = ? AND user_id = ? AND Balance >= ?"
        );
        $reserve_user->execute([$p['price'], $bot_token, $from_id, $p['price']]);
        if ($reserve_user->rowCount() === 0) {
            child_answer_callback($bot_token, $callback_query_id, '❌ موجودی کافی نیست', true); die();
        }

        // ---- رزرو atomic سقف حجم/کانفیگ نماینده ----
        // اگه رزرو سقف نماینده شکست بخورد (مثلاً بین این درخواست و یک درخواست
        // هم‌زمان دیگر، سقف پر شده)، موجودی مشتری که بالا کسر شد را برمی‌گردانیم.
        $reserve_bot = $pdo->prepare(
            "UPDATE reseller_bot
             SET volume_used = volume_used + ?, config_used = config_used + 1
             WHERE bot_token = ?
               AND (volume_limit - volume_used) >= ?
               AND (config_limit = 0 OR config_used < config_limit)"
        );
        $reserve_bot->execute([$p['volume_gb'], $bot_token, $p['volume_gb']]);
        if ($reserve_bot->rowCount() === 0) {
            // برگشت موجودی مشتری
            $pdo->prepare("UPDATE child_bot_user SET Balance = Balance + ? WHERE bot_token = ? AND user_id = ?")
                ->execute([$p['price'], $bot_token, $from_id]);
            child_editmessage($bot_token, $from_id, $message_id, "⚠️ ظرفیت به پایان رسید، لطفاً دوباره تلاش کنید.", json_encode(['inline_keyboard' => []])); die();
        }

        // ساخت config
        $uname = 'u_' . substr(md5($bot_token.$from_id), 0, 4) . '_' . substr(md5(uniqid()), 0, 6);
        $expire_at  = time() + ($p['days'] * 86400);
        $data_limit = $p['volume_gb'] * 1073741824;
        $datac = ['expire' => $expire_at, 'data_limit' => $data_limit];

        $panel_info = select("marzban_panel", "*", "name_panel", $bi['panel_name'], "select");
        if (($panel_info['type'] ?? '') === 'remnawave') {
            // از allowed_inbounds برای child_bot بگیر (فرمت: main_squad_uuid|test_squad_uuid)
            $squad_selection = child_decode_squad_selection($bi['allowed_inbounds'] ?? '');
            if (!empty($squad_selection['main'])) {
                $datac['squad_uuid'] = $squad_selection['main'];
            }
        }

        $result = $ManagePanel->createUser($bi['panel_name'], $uname, $datac);
        if (!isset($result['username'])) {
            // ساخت در پنل شکست خورد — هر دو رزرو را برمی‌گردانیم
            $pdo->prepare("UPDATE child_bot_user SET Balance = Balance + ? WHERE bot_token = ? AND user_id = ?")
                ->execute([$p['price'], $bot_token, $from_id]);
            $pdo->prepare("UPDATE reseller_bot SET volume_used = volume_used - ?, config_used = GREATEST(0, config_used - 1) WHERE bot_token = ?")
                ->execute([$p['volume_gb'], $bot_token]);
            child_editmessage($bot_token, $from_id, $message_id, "❌ خطا در ساخت کانفیگ. لطفاً دوباره تلاش کنید.", json_encode(['inline_keyboard' => []])); die();
        }

        // کسر کیف پول نماینده بابت هزینه (موجودی مشتری و سقف‌ها قبلاً رزرو شدند)
        $pdo->prepare("UPDATE reseller_bot SET wallet = wallet - ? WHERE bot_token = ?")->execute([$cost, $bot_token]);

        // ذخیره فاکتور
        $pdo->prepare("INSERT INTO child_bot_invoice (bot_token, user_id, username_config, product_name, volume_gb, days, price, status, created_at, expire_at) VALUES (?,?,?,?,?,?,?,'active',?,?)")
            ->execute([$bot_token, $from_id, $uname, $p['name'], $p['volume_gb'], $p['days'], $p['price'], time(), $expire_at]);

        $udata   = $ManagePanel->DataUser($bi['panel_name'], $uname);
        $sub_url = $udata['subscription_url'] ?? ($udata['links'][0] ?? 'N/A');
        $disp_name = $bi['display_name'] ?: $bi['panel_name'];

        child_editmessage($bot_token, $from_id, $message_id,
            "✅ <b>خرید موفق!</b>\n\n🌐 لوکیشن: <b>{$disp_name}</b>\n📦 <b>{$p['name']}</b>\n{$p['volume_gb']} GB / {$p['days']} روز\n\n🔗 لینک اشتراک:\n<code>{$sub_url}</code>",
            json_encode(['inline_keyboard' => []]));

        // اطلاع به نماینده (owner)
        child_sendmessage($bot_token, $owner_id,
            "🛒 <b>فروش جدید!</b>\n👤 کاربر: <code>{$from_id}</code>\n📦 {$p['name']} | {$p['volume_gb']}GB | " . number_format($p['price']) . " تومان",
            null, 'HTML');
        die();
    }

    if ($datain === 'cp_close' || $datain === 'cp_cancel') {
        child_editmessage($bot_token, $from_id, $message_id, "❌ بسته شد.", json_encode(['inline_keyboard' => []]));
        die();
    }
}
