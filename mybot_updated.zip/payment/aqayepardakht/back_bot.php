<?php
// payment/aqayepardakht/back_bot.php
// callback آقای پرداخت برای خرید پنل نمایندگی
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles . '/config.php';
require_once $Pathfiles . '/botapi.php';
require_once $Pathfiles . '/functions.php';
require_once $Pathfiles . '/reseller_bot_sale.php';

$invoice_id = htmlspecialchars($_POST['invoice_id'] ?? '', ENT_QUOTES, 'UTF-8');
$transid    = htmlspecialchars($_POST['transid']    ?? '', ENT_QUOTES, 'UTF-8');

$inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
$inv->execute([$invoice_id]);
$inv = $inv->fetch(PDO::FETCH_ASSOC);

$payment_status     = 'پرداخت ناموفق';
$dec_payment_status = '';

if ($inv && $inv['payment_status'] !== 'paid') {
    $pin  = select("PaySetting", "ValuePay", "NamePay", "merchant_id_aqayepardakht", "select")['ValuePay'];
    $data = json_encode(['pin' => $pin, 'amount' => $inv['price'], 'transid' => $transid]);
    $ch   = curl_init('https://panel.aqayepardakht.ir/api/v2/verify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    $result = json_decode(curl_exec($ch), true);
    curl_close($ch);

    if (($result['code'] ?? '') == '1') {
        $pdo->prepare("UPDATE Payment_report SET payment_Status='paid' WHERE id_order=?")
            ->execute([$invoice_id]);
        $deliver = bot_sale_deliver_panel($invoice_id, null);
        $payment_status     = $deliver['ok'] ? '✅ پرداخت موفق' : '⚠️ پرداخت موفق اما خطا در تحویل';
        $dec_payment_status = $deliver['msg'];

        global $adminnumber;
        sendmessage($adminnumber,
            "✅ <b>پرداخت آنلاین پنل (آقای پرداخت)</b>\n\n"
            . "👤 خریدار: <code>{$inv['buyer_id']}</code>\n"
            . "📋 پلن: <b>{$inv['plan_name']}</b>\n"
            . "💰 مبلغ: <b>" . number_format($inv['price']) . " تومان</b>\n"
            . "📌 سفارش: <code>{$invoice_id}</code>",
            null, 'HTML');
    } else {
        $payment_status = 'پرداخت ناموفق (کد: ' . ($result['code'] ?? '?') . ')';
    }
} elseif ($inv && $inv['payment_status'] === 'paid') {
    $payment_status = 'این سفارش قبلاً پرداخت شده';
}

$bot_link = "https://t.me/{$usernamebot}";
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>نتیجه پرداخت</title>
    <style>
        body { font-family:Tahoma,Arial,sans-serif; background:#f2f2f2; margin:0; padding:20px; display:flex; justify-content:center; align-items:center; min-height:100vh; }
        .box { background:#fff; border-radius:10px; box-shadow:0 2px 12px rgba(0,0,0,.12); padding:40px; text-align:center; max-width:380px; width:100%; }
        h1 { color:#333; font-size:1.4em; }
        p  { color:#666; }
        .btn { display:inline-block; margin-top:16px; padding:12px 24px; background:#0088cc; color:#fff; text-decoration:none; border-radius:8px; }
    </style>
</head>
<body>
<div class="box">
    <h1><?= htmlspecialchars($payment_status) ?></h1>
    <?php if ($invoice_id): ?>
    <p>شناسه سفارش: <strong><?= htmlspecialchars($invoice_id) ?></strong></p>
    <p>مبلغ: <strong><?= number_format((int)($inv['price'] ?? 0)) ?> تومان</strong></p>
    <?php endif; ?>
    <p><?= htmlspecialchars($dec_payment_status) ?></p>
    <a class="btn" href="<?= htmlspecialchars($bot_link) ?>">بازگشت به ربات</a>
</div>
</body>
</html>
