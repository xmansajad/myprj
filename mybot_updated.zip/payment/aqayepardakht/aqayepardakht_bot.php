<?php
// payment/aqayepardakht/aqayepardakht_bot.php
// آغاز پرداخت آقای پرداخت برای خرید پنل نمایندگی
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles . '/config.php';
require_once $Pathfiles . '/functions.php';

$amount   = (int) htmlspecialchars($_GET['price']    ?? 0, ENT_QUOTES, 'UTF-8');
$order_id = htmlspecialchars($_GET['order_id'] ?? '', ENT_QUOTES, 'UTF-8');

if (!$amount || !$order_id) { die('پارامترهای نامعتبر'); }

$inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
$inv->execute([$order_id]);
$inv = $inv->fetch(PDO::FETCH_ASSOC);
if (!$inv || $inv['payment_status'] === 'paid') { die('سفارش نامعتبر'); }
if ($inv['price'] != $amount) { die('مبلغ نامعتبر'); }

$pin      = select("PaySetting", "ValuePay", "NamePay", "merchant_id_aqayepardakht", "select")['ValuePay'];
$callback = "https://{$domainhosts}/payment/aqayepardakht/back_bot.php";

$pdo->prepare("UPDATE reseller_bot_invoice SET payment_status='waiting' WHERE order_id=?")
    ->execute([$order_id]);

// ذخیره در Payment_report برای ردیابی
$pdo->prepare(
    "INSERT IGNORE INTO Payment_report (id_user, id_order, time, price, payment_Status, Payment_Method, invoice)
     VALUES (?, ?, NOW(), ?, 'waiting', 'aqayepardakht_bot', ?)"
)->execute([$inv['buyer_id'], $order_id, $amount, $order_id]);

$data = json_encode([
    'pin'         => $pin,
    'amount'      => $amount,
    'callback'    => $callback,
    'invoice_id'  => $order_id,
    'description' => "خرید پنل نمایندگی — {$inv['plan_name']}",
]);
$ch = curl_init('https://panel.aqayepardakht.ir/api/v2/create');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $data,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
]);
$result = json_decode(curl_exec($ch), true);
curl_close($ch);

if (!empty($result['transid'])) {
    header('Location: https://panel.aqayepardakht.ir/startpay/' . $result['transid']);
    exit;
}
echo 'خطا در اتصال به درگاه. لطفاً دوباره امتحان کنید.';
