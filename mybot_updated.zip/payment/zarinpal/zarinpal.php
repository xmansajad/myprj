<?php
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles.'/config.php';
require_once $Pathfiles.'/functions.php';
require_once $Pathfiles.'/text.php';

$amount     = htmlspecialchars($_GET['price'],    ENT_QUOTES, 'UTF-8');
$invoice_id = htmlspecialchars($_GET['order_id'], ENT_QUOTES, 'UTF-8');

$merchant_id = select("PaySetting", "ValuePay", "NamePay", "merchant_id_zarinpal", "select")['ValuePay'];
$checkprice  = select("Payment_report", "price", "id_order", $invoice_id, "select")['price'];

if ($checkprice != $amount) {
    echo $textbotlang['users']['moeny']['invalidprice'];
    return;
}

// زرین‌پال ریال می‌خواد (تومان * 10)
$amount_rial = (int)$amount * 10;

$data = json_encode([
    'merchant_id'  => $merchant_id,
    'amount'       => $amount_rial,
    'description'  => 'افزایش موجودی کیف پول',
    'callback_url' => "https://" . $domainhosts . "/payment/zarinpal/back.php",
    'metadata'     => ['order_id' => $invoice_id],
]);

$ch = curl_init('https://api.zarinpal.com/pg/v4/payment/request.json');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json']);
$result = curl_exec($ch);
curl_close($ch);

$result = json_decode($result, true);

if (isset($result['data']['code']) && $result['data']['code'] == 100) {
    $authority = $result['data']['authority'];
    // authority رو ذخیره می‌کنیم تا در back.php بتونیم سفارش رو پیدا کنیم
    update("Payment_report", "invoice", $authority, "id_order", $invoice_id);
    header('Location: https://www.zarinpal.com/pg/StartPay/' . $authority);
    exit;
} else {
    $code = $result['errors']['code'] ?? '';
    $errors = [
        '-1'  => 'اطلاعات ارسال شده ناقص است',
        '-2'  => 'IP یا مرچنت کد پذیرنده صحیح نیست',
        '-3'  => 'با توجه به محدودیت‌های شاپرک امکان پرداخت با این مبلغ میسر نیست',
        '-4'  => 'سطح تأیید پذیرنده پایین‌تر از سطح نقره‌ای است',
        '-11' => 'درخواست مورد نظر یافت نشد',
        '-22' => 'تراکنش ناموفق است',
        '-33' => 'مبلغ تراکنش با مبلغ پرداخت شده مطابقت ندارد',
        '-40' => 'اجازه دسترسی به این متد وجود ندارد',
    ];
    echo $errors[(string)$code] ?? "خطای ناشناخته (کد: $code)";
}
