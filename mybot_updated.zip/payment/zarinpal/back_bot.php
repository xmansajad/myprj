<?php
// payment/zarinpal/back_bot.php
// callback زرین‌پال برای خرید پنل نمایندگی
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles . '/config.php';
require_once $Pathfiles . '/botapi.php';
require_once $Pathfiles . '/functions.php';
require_once $Pathfiles . '/reseller_bot_sale.php';

$authority = htmlspecialchars($_GET['Authority'] ?? '', ENT_QUOTES, 'UTF-8');
$status    = htmlspecialchars($_GET['Status']    ?? '', ENT_QUOTES, 'UTF-8');

// پیدا کردن order از طریق authority (در Payment_report ذخیره شده)
$pr = $pdo->prepare("SELECT * FROM Payment_report WHERE invoice=? AND Payment_Method='zarinpal_bot'");
$pr->execute([$authority]);
$pr = $pr->fetch(PDO::FETCH_ASSOC);

$payment_status     = 'پرداخت ناموفق';
$dec_payment_status = '';
$order_id           = $pr['id_order'] ?? '';
$price              = $pr['price']    ?? 0;

if ($status === 'OK' && $pr) {
    $merchant_id = select("PaySetting", "ValuePay", "NamePay", "merchant_id_zarinpal", "select")['ValuePay'];
    $amount_rial = (int)$price * 10;

    $data = json_encode([
        'merchant_id' => $merchant_id,
        'amount'      => $amount_rial,
        'authority'   => $authority,
    ]);

    $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
    ]);
    $result = json_decode(curl_exec($ch), true);
    curl_close($ch);

    $code = $result['data']['code'] ?? -1;
    if ($code == 100 || $code == 101) {
        // جلوگیری از تحویل دوگانه
        if ($pr['payment_Status'] !== 'paid') {
            $pdo->prepare("UPDATE Payment_report SET payment_Status='paid' WHERE invoice=?")
                ->execute([$authority]);

            // تحویل پنل
            $deliver = bot_sale_deliver_panel($order_id, null);
            $payment_status     = $deliver['ok'] ? '✅ پرداخت موفق' : '⚠️ پرداخت موفق اما خطا در تحویل';
            $dec_payment_status = $deliver['msg'];

            // گزارش به ادمین
            global $adminnumber;
            $inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
            $inv->execute([$order_id]);
            $inv = $inv->fetch(PDO::FETCH_ASSOC);
            if ($inv) {
                sendmessage($adminnumber,
                    "✅ <b>پرداخت آنلاین پنل نمایندگی</b>\n\n"
                    . "👤 خریدار: <code>{$inv['buyer_id']}</code>\n"
                    . "📋 پلن: <b>{$inv['plan_name']}</b>\n"
                    . "💰 مبلغ: <b>" . number_format($price) . " تومان</b>\n"
                    . "📌 سفارش: <code>{$order_id}</code>\n"
                    . "🤖 ربات: @{$inv['bot_username']}",
                    null, 'HTML');
            }
        } else {
            $payment_status = 'پرداخت قبلاً ثبت شده';
        }
    } else {
        $payment_status = 'پرداخت ناموفق (کد: ' . $code . ')';
    }
}

$bot_link = "https://t.me/{$usernamebot}";
?>
<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
    <meta charset="UTF-8">
    <title>نتیجه پرداخت</title>
    <style>
        body { font-family: Tahoma, Arial, sans-serif; background:#f2f2f2; margin:0; padding:20px; display:flex; justify-content:center; align-items:center; min-height:100vh; }
        .box { background:#fff; border-radius:10px; box-shadow:0 2px 12px rgba(0,0,0,.12); padding:40px; text-align:center; max-width:380px; width:100%; }
        h1 { color:#333; font-size:1.4em; }
        p  { color:#666; }
        .btn { display:inline-block; margin-top:16px; padding:12px 24px; background:#0088cc; color:#fff; text-decoration:none; border-radius:8px; font-size:.95em; }
    </style>
</head>
<body>
<div class="box">
    <h1><?= htmlspecialchars($payment_status) ?></h1>
    <?php if ($order_id): ?>
    <p>شناسه سفارش: <strong><?= htmlspecialchars($order_id) ?></strong></p>
    <p>مبلغ: <strong><?= number_format((int)$price) ?> تومان</strong></p>
    <?php endif; ?>
    <p><?= htmlspecialchars($dec_payment_status) ?></p>
    <a class="btn" href="<?= htmlspecialchars($bot_link) ?>">بازگشت به ربات</a>
</div>
</body>
</html>
