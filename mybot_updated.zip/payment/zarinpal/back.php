<?php
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles.'/config.php';
require_once $Pathfiles.'/jdf.php';
require_once $Pathfiles.'/botapi.php';
require_once $Pathfiles.'/functions.php';
require_once $Pathfiles.'/panels.php';
require_once $Pathfiles.'/text.php';

$authority = htmlspecialchars($_GET['Authority'] ?? '', ENT_QUOTES, 'UTF-8');
$status    = htmlspecialchars($_GET['Status']    ?? '', ENT_QUOTES, 'UTF-8');

$ManagePanel = new ManagePanel();

if ($status !== 'OK') {
    $payment_status     = $textbotlang['users']['moeny']['payment_failed'];
    $dec_payment_status = "";
    $invoice_id = '';
    $price = '';
} else {
    $merchant_id    = select("PaySetting", "ValuePay", "NamePay", "merchant_id_zarinpal", "select")['ValuePay'];
    // authority رو در فیلد invoice ذخیره کردیم
    $Payment_report = select("Payment_report", "*", "invoice", $authority, "select");

    if (!$Payment_report) {
        die('تراکنش یافت نشد.');
    }

    $invoice_id  = $Payment_report['id_order'];
    $price       = $Payment_report['price'];
    $amount_rial = (int)$price * 10;

    $data = json_encode([
        'merchant_id' => $merchant_id,
        'amount'      => $amount_rial,
        'authority'   => $authority,
    ]);

    $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json']);
    $result = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($result, true);
    $code   = $result['data']['code'] ?? -1;

    if ($code == 100 || $code == 101) {
        $setting = select("setting", "*");
        $payment_status     = $textbotlang['users']['moeny']['payment_success'];
        $dec_payment_status = $textbotlang['users']['moeny']['payment_success_dec'];
        $Balance_id = select("user", "*", "id", $Payment_report['id_user'], "select");

        if ($Payment_report['payment_Status'] != "paid") {
            DirectPayment($Payment_report['id_order']);
            update("user", "Processing_value",     "0", "id", $Balance_id['id']);
            update("user", "Processing_value_one", "0", "id", $Balance_id['id']);
            update("user", "Processing_value_tow", "0", "id", $Balance_id['id']);
            update("Payment_report", "payment_Status", "paid", "id_order", $Payment_report['id_order']);
            if (strlen($setting['Channel_Report']) > 0) {
                sendmessage($setting['Channel_Report'],
                    sprintf($textbotlang['Admin']['Report']['zarinpal'], $Payment_report['id_user'], $price),
                    null, 'HTML');
            }
        }
    } else {
        $payment_status     = $textbotlang['users']['moeny']['payment_failed'];
        $dec_payment_status = "";
    }
}
?>
<html>
<head>
    <title><?php echo $textbotlang['users']['moeny']['invoice_title']; ?></title>
    <style>
        @font-face {
            font-family: 'vazir';
            src: url('/Vazir.eot');
            src: local('☺'), url('../fonts/Vazir.woff') format('woff'), url('../fonts/Vazir.ttf') format('truetype');
        }
        body {
            font-family: vazir;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            direction: rtl;
        }
        .confirmation-box {
            background-color: #ffffff;
            border-radius: 8px;
            width: 25%;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
        }
        h1 { color: #333333; margin-bottom: 20px; }
        p  { color: #666666; margin-bottom: 10px; }
        .btn {
            display: block;
            margin: 10px 0;
            padding: 10px 20px;
            background-color: #49b200;
            color: #fff;
            text-decoration: none;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<div class="confirmation-box">
    <h1><?php echo $payment_status ?></h1>
    <?php if ($invoice_id): ?>
    <p><?php echo $textbotlang['users']['moeny']['transaction_number']; ?><span><?php echo $invoice_id ?></span></p>
    <p><?php echo $textbotlang['users']['moeny']['payment_amount']; ?> <span><?php echo $price; ?></span><?php echo $textbotlang['users']['moeny']['currency']; ?></p>
    <p><?php echo $textbotlang['users']['moeny']['date_label']; ?> <span><?php echo jdate('Y/m/d') ?></span></p>
    <?php endif; ?>
    <p><?php echo $dec_payment_status ?></p>
    <a class="btn" href="https://t.me/<?php echo $usernamebot ?>"><?php echo $textbotlang['users']['moeny']['back_to_bot']; ?></a>
</div>
</body>
</html>
