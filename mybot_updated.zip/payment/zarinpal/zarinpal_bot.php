<?php
// payment/zarinpal/zarinpal_bot.php
// آغاز پرداخت زرین‌پال برای خرید پنل نمایندگی
ini_set('error_log', 'error_log');
$Pathfiles = dirname(dirname(__DIR__));
require_once $Pathfiles . '/config.php';
require_once $Pathfiles . '/functions.php';

$amount   = (int) htmlspecialchars($_GET['price']    ?? 0, ENT_QUOTES, 'UTF-8');
$order_id = htmlspecialchars($_GET['order_id'] ?? '', ENT_QUOTES, 'UTF-8');

if (!$amount || !$order_id) { die('پارامترهای نامعتبر'); }

// بررسی سفارش
$inv = $pdo->prepare("SELECT * FROM reseller_bot_invoice WHERE order_id=?");
$inv->execute([$order_id]);
$inv = $inv->fetch(PDO::FETCH_ASSOC);

if (!$inv || $inv['payment_status'] === 'paid') {
    die('سفارش یافت نشد یا قبلاً پرداخت شده.');
}
if ($inv['price'] != $amount) { die('مبلغ نامعتبر'); }

$merchant_id = select("PaySetting", "ValuePay", "NamePay", "merchant_id_zarinpal", "select")['ValuePay'];
$amount_rial = $amount * 10;

$data = json_encode([
    'merchant_id'  => $merchant_id,
    'amount'       => $amount_rial,
    'description'  => "خرید پنل نمایندگی — {$inv['plan_name']}",
    'callback_url' => "https://{$domainhosts}/payment/zarinpal/back_bot.php",
    'metadata'     => ['order_id' => $order_id],
]);

$ch = curl_init('https://api.zarinpal.com/pg/v4/payment/request.json');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $data,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Accept: application/json'],
]);
$result    = json_decode(curl_exec($ch), true);
curl_close($ch);

if (isset($result['data']['code']) && $result['data']['code'] == 100) {
    $authority = $result['data']['authority'];
    // Store authority in reseller_bot_invoice (zp_authority column — see table.php ALTER)
    $pdo->prepare(
        "UPDATE reseller_bot_invoice SET payment_status='waiting', zp_authority=? WHERE order_id=?"
    )->execute([$authority, $order_id]);

    // Also store in Payment_report for back_bot.php lookup (invoice = authority)
    $pdo->prepare(
        "INSERT IGNORE INTO Payment_report (id_user, id_order, time, price, payment_Status, Payment_Method, invoice)
         VALUES (?, ?, NOW(), ?, 'waiting', 'zarinpal_bot', ?)"
    )->execute([$inv['buyer_id'], $order_id, $amount, $authority]);

    header('Location: https://www.zarinpal.com/pg/StartPay/' . $authority);
    exit;
}

$code = $result['errors']['code'] ?? 'ناشناخته';
echo "خطا در اتصال به درگاه (کد: {$code}). لطفاً دوباره امتحان کنید.";
